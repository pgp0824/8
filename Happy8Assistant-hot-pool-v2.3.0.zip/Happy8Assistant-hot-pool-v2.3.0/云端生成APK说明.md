# 云端生成 APK（无需安装 Android Studio）

工程已内置 GitHub Actions：`.github/workflows/build-apk.yml`。

## 操作步骤

1. 把本工程上传到 GitHub 仓库根目录，保留 `.github` 文件夹。
2. 打开仓库顶部 **Actions**。
3. 选择左侧 **构建乐彩助手 APK**。
4. 点击 **Run workflow**，分支选择 `main`，再次点击绿色按钮。
5. 等待黄色圆点变成绿色对勾。
6. 打开成功记录，在页面底部 **Artifacts** 下载 **乐彩助手-APK**。
7. 解压后得到 `乐彩助手-v2.0.0-debug.apk`，点击安装。

## 用手机替换旧版源码 ZIP

若仓库采用“上传源码 ZIP + 自动解压构建”的方式：

1. 删除仓库中旧的 `Happy8Assistant-source-with-cloud-build.zip`。
2. 上传新版同名 ZIP，文件名不要带 `(1)`。
3. 不要删除 `.github/workflows/build-apk.yml`。
4. 上传完成后进入 Actions 重新运行构建。

## 覆盖安装

版本号已升级为 2.0.0。若新旧 APK 使用同一调试签名，可直接更新并保留本地记录；若提示签名冲突，需要先卸载旧版，再安装新版，卸载会清空旧版本地数据。

## 安装提示

这是你自己仓库构建的调试 APK。安卓可能提示“未知来源应用”，确认文件来自自己的绿色对勾构建记录后，再允许浏览器或文件管理器安装。
