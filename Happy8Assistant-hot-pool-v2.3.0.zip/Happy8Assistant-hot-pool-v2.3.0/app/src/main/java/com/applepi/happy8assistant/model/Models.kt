package com.applepi.happy8assistant.model

enum class LotteryGame(
    val label: String,
    val shortLabel: String,
    val sourceLabel: String
) {
    HAPPY8("快乐8", "快乐8", "中国福利彩票官网"),
    DOUBLE_COLOR_BALL("双色球", "双色球", "中国福利彩票官网"),
    SUPER_LOTTO("超级大乐透", "大乐透", "中国体育彩票官网"),
    FC3D("福彩3D", "福彩3D", "中国福利彩票官网"),
    PL3("排列三", "排列三", "中国体育彩票官网")
}

enum class TicketMode(val label: String) {
    SINGLE("单式"),
    COMPOUND("复式"),
    DANTUO("胆拖")
}

enum class DanTuoPart(val label: String) {
    BANKER("选择胆码"),
    DRAG("选择拖码")
}

enum class DigitPlay(val label: String) {
    DIRECT("直选"),
    GROUP3("组选3"),
    GROUP6("组选6")
}

data class DrawResult(
    val game: LotteryGame,
    val issue: String,
    val date: String,
    val primaryNumbers: List<Int>,
    val secondaryNumbers: List<Int> = emptyList(),
    val source: String = game.sourceLabel,
    val jackpot: Long? = null
) {
    /** 快乐8兼容旧代码：保留实际摇出顺序。 */
    val numbers: List<Int> get() = primaryNumbers
}

data class SavedTicket(
    val id: String,
    val game: LotteryGame,
    val issue: String,
    val playCount: Int = 0,
    val mode: TicketMode = TicketMode.SINGLE,
    val primaryNumbers: List<Int> = emptyList(),
    val secondaryNumbers: List<Int> = emptyList(),
    val primaryBankers: List<Int> = emptyList(),
    val primaryDrags: List<Int> = emptyList(),
    val secondaryBankers: List<Int> = emptyList(),
    val secondaryDrags: List<Int> = emptyList(),
    val digitPlay: DigitPlay? = null,
    val digits: List<Int> = emptyList(),
    val multiplier: Int = 1,
    val createdAt: Long = System.currentTimeMillis()
) {
    // 兼容快乐8旧字段的语义。
    val numbers: List<Int> get() = primaryNumbers
    val bankers: List<Int> get() = primaryBankers
    val drags: List<Int> get() = primaryDrags
}


data class GeneratedPick(
    val primaryNumbers: List<Int> = emptyList(),
    val secondaryNumbers: List<Int> = emptyList(),
    val primaryBankers: List<Int> = emptyList(),
    val primaryDrags: List<Int> = emptyList(),
    val digits: List<Int> = emptyList()
)

data class PrizeResult(
    val checked: Boolean,
    val isWinner: Boolean,
    val fixedPrize: Double = 0.0,
    val dynamicWinningLines: Long = 0,
    val winningLines: Long = 0,
    val totalLines: Long = 0,
    val bestHitCount: Int = 0,
    val hitNumbers: List<Int> = emptyList(),
    val prizeLevel: String? = null,
    val description: String = "待开奖"
)
