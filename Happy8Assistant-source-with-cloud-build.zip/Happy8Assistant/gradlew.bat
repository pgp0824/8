@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_URL=https://github.com/gradle/gradle/raw/refs/tags/v8.13.0/gradle/wrapper/gradle-wrapper.jar"
set "WRAPPER_SHA256=81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f"

if exist "%WRAPPER_JAR%" goto verify

where gradle >NUL 2>&1
if errorlevel 1 goto download
gradle --version 2>NUL | findstr /C:"Gradle 8.13" >NUL
if errorlevel 1 goto download
echo 未找到 Wrapper JAR，使用本机已安装的 Gradle 8.13。
gradle %*
exit /b %ERRORLEVEL%

:download
echo Gradle Wrapper JAR 缺失，下载并校验官方 Gradle 8.13 Wrapper……
if not exist "%APP_HOME%gradle\wrapper" mkdir "%APP_HOME%gradle\wrapper"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%.tmp';" ^
  "$hash=(Get-FileHash -Algorithm SHA256 '%WRAPPER_JAR%.tmp').Hash.ToLowerInvariant();" ^
  "if($hash -ne '%WRAPPER_SHA256%'){Remove-Item -Force '%WRAPPER_JAR%.tmp'; throw 'Gradle Wrapper SHA-256 校验失败'};" ^
  "Move-Item -Force '%WRAPPER_JAR%.tmp' '%WRAPPER_JAR%'"
if errorlevel 1 exit /b 1

:verify
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$hash=(Get-FileHash -Algorithm SHA256 '%WRAPPER_JAR%').Hash.ToLowerInvariant();" ^
  "if($hash -ne '%WRAPPER_SHA256%'){throw ('Gradle Wrapper 校验失败。实际：'+$hash)}"
if errorlevel 1 exit /b 1

java %JAVA_OPTS% %GRADLE_OPTS% -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
