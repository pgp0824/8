package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.TicketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TicketImportParserTest {
    @Test
    fun importsMultipleHappy8LinesAndInfersSingleOrCompound() {
        val tickets = TicketImportParser.parse(
            game = LotteryGame.HAPPY8,
            issue = "2026210",
            rawText = """
                04 10 29 40 42
                02，17，32，44，53，73
            """.trimIndent(),
            happy8PlayCount = 5,
            digitPlay = DigitPlay.DIRECT,
            multiplier = 1
        )

        assertEquals(2, tickets.size)
        assertEquals(TicketMode.SINGLE, tickets[0].mode)
        assertEquals(TicketMode.COMPOUND, tickets[1].mode)
        assertEquals(listOf(2, 17, 32, 44, 53, 73), tickets[1].primaryNumbers)
    }

    @Test
    fun importsHappy8DantuoText() {
        val ticket = TicketImportParser.parse(
            game = LotteryGame.HAPPY8,
            issue = "2026210",
            rawText = "选5 胆 01 02 拖 03 04 05 06",
            happy8PlayCount = 5,
            digitPlay = DigitPlay.DIRECT,
            multiplier = 2
        ).single()

        assertEquals(TicketMode.DANTUO, ticket.mode)
        assertEquals(listOf(1, 2), ticket.primaryBankers)
        assertEquals(listOf(3, 4, 5, 6), ticket.primaryDrags)
        assertEquals(2, ticket.multiplier)
    }

    @Test
    fun importsDoubleColorBallAndSuperLottoWithAreaSeparators() {
        val ssq = TicketImportParser.parse(
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026099",
            rawText = "红球 01 02 03 04 05 06 + 蓝球 07",
            happy8PlayCount = 5,
            digitPlay = DigitPlay.DIRECT,
            multiplier = 1
        ).single()
        assertEquals(listOf(1, 2, 3, 4, 5, 6), ssq.primaryNumbers)
        assertEquals(listOf(7), ssq.secondaryNumbers)

        val dlt = TicketImportParser.parse(
            game = LotteryGame.SUPER_LOTTO,
            issue = "26099",
            rawText = "前区 01 02 03 04 05 | 后区 06 07",
            happy8PlayCount = 5,
            digitPlay = DigitPlay.DIRECT,
            multiplier = 3
        ).single()
        assertEquals(listOf(1, 2, 3, 4, 5), dlt.primaryNumbers)
        assertEquals(listOf(6, 7), dlt.secondaryNumbers)
    }

    @Test
    fun importsDigitLotteryAndReadsPlayLabel() {
        val ticket = TicketImportParser.parse(
            game = LotteryGame.FC3D,
            issue = "2026210",
            rawText = "组选3 122",
            happy8PlayCount = 5,
            digitPlay = DigitPlay.DIRECT,
            multiplier = 1
        ).single()

        assertEquals(DigitPlay.GROUP3, ticket.digitPlay)
        assertEquals(listOf(1, 2, 2), ticket.digits)
    }

    @Test
    fun rejectsDuplicateNumbersInsideOneTicket() {
        val error = runCatching {
            TicketImportParser.parse(
                game = LotteryGame.HAPPY8,
                issue = "2026210",
                rawText = "01 02 02 04 05",
                happy8PlayCount = 5,
                digitPlay = DigitPlay.DIRECT,
                multiplier = 1
            )
        }.exceptionOrNull()

        assertTrue(error?.message.orEmpty().contains("重复号码"))
    }
}
