package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrizeCalculatorTest {
    private val happy8Draw = DrawResult(
        game = LotteryGame.HAPPY8,
        issue = "2026001",
        date = "2026-01-01",
        primaryNumbers = (1..20).toList()
    )

    @Test
    fun happy8SingleSelectFiveThreeHitsPaysThreeYuan() {
        val ticket = SavedTicket(
            id = "h1",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.SINGLE,
            primaryNumbers = listOf(1, 2, 3, 70, 71)
        )
        val result = PrizeCalculator.calculate(ticket, happy8Draw)
        assertTrue(result.isWinner)
        assertEquals(3.0, result.fixedPrize, 0.001)
    }

    @Test
    fun happy8CompoundAndDantuoCalculateEveryCombination() {
        val compound = SavedTicket(
            id = "h2",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.COMPOUND,
            primaryNumbers = listOf(1, 2, 3, 4, 5, 70)
        )
        val compoundResult = PrizeCalculator.calculate(compound, happy8Draw)
        assertEquals(6, compoundResult.totalLines)
        assertEquals(1100.0, compoundResult.fixedPrize, 0.001)
        assertEquals(6, compoundResult.winningLines)

        val dantuo = SavedTicket(
            id = "h3",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.DANTUO,
            primaryBankers = listOf(1, 2),
            primaryDrags = listOf(3, 4, 5, 70)
        )
        val dantuoResult = PrizeCalculator.calculate(dantuo, happy8Draw)
        assertEquals(4, dantuoResult.totalLines)
        assertEquals(1060.0, dantuoResult.fixedPrize, 0.001)
    }

    @Test
    fun doubleColorBallCompoundCountsEachRedBlueCombination() {
        val draw = DrawResult(
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6),
            secondaryNumbers = listOf(7)
        )
        val ticket = SavedTicket(
            id = "s1",
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = draw.issue,
            mode = TicketMode.COMPOUND,
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6, 9),
            secondaryNumbers = listOf(7, 8)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertEquals(14, result.totalLines)
        assertEquals(14, result.winningLines)
        assertEquals(2, result.dynamicWinningLines)
        assertEquals(19_200.0, result.fixedPrize, 0.001)
    }

    @Test
    fun superLottoUsesNewSevenLevelRuleFromIssue26014() {
        val draw = DrawResult(
            game = LotteryGame.SUPER_LOTTO,
            issue = "26014",
            date = "2026-02-02",
            primaryNumbers = listOf(1, 2, 3, 4, 5),
            secondaryNumbers = listOf(1, 2),
            jackpot = 700_000_000L
        )
        val ticket = SavedTicket(
            id = "d1",
            game = LotteryGame.SUPER_LOTTO,
            issue = draw.issue,
            primaryNumbers = listOf(1, 2, 3, 4, 20),
            secondaryNumbers = listOf(1, 9)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertTrue(result.isWinner)
        assertEquals("四等奖", result.prizeLevel)
        assertEquals(300.0, result.fixedPrize, 0.001)
    }

    @Test
    fun digitLotteriesSupportDirectGroup3AndGroup6() {
        val fc3dDraw = DrawResult(
            game = LotteryGame.FC3D,
            issue = "2026001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 2)
        )
        val group3 = SavedTicket(
            id = "f1",
            game = LotteryGame.FC3D,
            issue = fc3dDraw.issue,
            digitPlay = DigitPlay.GROUP3,
            digits = listOf(2, 1, 2)
        )
        assertEquals(346.0, PrizeCalculator.calculate(group3, fc3dDraw).fixedPrize, 0.001)

        val pl3Draw = DrawResult(
            game = LotteryGame.PL3,
            issue = "26001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 3)
        )
        val group6 = SavedTicket(
            id = "p1",
            game = LotteryGame.PL3,
            issue = pl3Draw.issue,
            digitPlay = DigitPlay.GROUP6,
            digits = listOf(3, 1, 2)
        )
        assertEquals(173.0, PrizeCalculator.calculate(group6, pl3Draw).fixedPrize, 0.001)

        val wrongDirect = group6.copy(digitPlay = DigitPlay.DIRECT)
        assertFalse(PrizeCalculator.calculate(wrongDirect, pl3Draw).isWinner)
    }

    @Test
    fun hotColdMethodUsesExactlyTwoNumbersFromTopTenHotPoolAndRandomizes() {
        val rotatingPool = (2..80).filter { it != 21 }
        val draws = (0 until 15).map { index ->
            val rotating = List(18) { offset ->
                rotatingPool[(index * 18 + offset * 3) % rotatingPool.size]
            }
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026100 - index).toString(),
                date = "",
                primaryNumbers = (listOf(1, 21) + rotating).distinct().take(20)
            )
        }
        val frequency = (1..80).associateWith { number ->
            draws.count { number in it.primaryNumbers }
        }
        val lastSeen = (1..80).associateWith { number ->
            draws.indexOfFirst { number in it.primaryNumbers }.let { if (it < 0) 99 else it }
        }
        val hotPool = (1..80).sortedWith(
            compareByDescending<Int> { frequency.getValue(it) }
                .thenBy { lastSeen.getValue(it) }
                .thenBy { it }
        ).take(10).toSet()
        val generated = List(20) { NumberGenerator.hotColdNumbers(draws, 6) }
        generated.forEach { numbers ->
            assertEquals(6, numbers.size)
            assertEquals(2, numbers.count { it in hotPool })
        }
        assertTrue(generated.map { it.joinToString(",") }.distinct().size > 1)
    }

    @Test
    fun consecutiveMethodUsesTwoMostActiveZonesAndRandomizesPairs() {
        val filler = listOf(2, 5, 8, 12, 15, 18, 32, 35, 38, 42, 45, 48, 62, 65, 68, 72)
        val draws = (0 until 15).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026200 - index).toString(),
                date = "",
                primaryNumbers = (listOf(21, 22, 51, 52) + filler).take(20)
            )
        }
        val generated = List(20) { NumberGenerator.consecutiveNumbers(draws, 6) }
        generated.forEach { numbers ->
            assertEquals(6, numbers.size)
            assertTrue(numbers.zipWithNext().any { (a, b) -> a in 21..29 && b == a + 1 })
            assertTrue(numbers.zipWithNext().any { (a, b) -> a in 51..59 && b == a + 1 })
        }
        assertTrue(generated.map { it.joinToString(",") }.distinct().size > 1)
    }

    @Test
    fun multiplierChangesCostAndFixedPrizeWithoutChangingBaseLineCount() {
        val ticket = SavedTicket(
            id = "m1",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.SINGLE,
            primaryNumbers = listOf(1, 2, 3, 70, 71),
            multiplier = 5
        )
        val result = PrizeCalculator.calculate(ticket, happy8Draw)
        assertEquals(1, result.totalLines)
        assertEquals(10, LotteryMath.ticketCost(ticket))
        assertEquals(15.0, result.fixedPrize, 0.001)
        assertTrue(result.description.contains("5倍"))
    }


    @Test
    fun happy8MultiplierAboveLimitIsClampedTo15Everywhere() {
        val ticket = SavedTicket(
            id = "m2",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.SINGLE,
            primaryNumbers = listOf(1, 2, 3, 70, 71),
            multiplier = 99
        )
        val result = PrizeCalculator.calculate(ticket, happy8Draw)

        assertEquals(15, LotteryGame.HAPPY8.normalizeMultiplier(99))
        assertEquals(30, LotteryMath.ticketCost(ticket))
        assertEquals(45.0, result.fixedPrize, 0.001)
        assertTrue(result.description.contains("15倍"))
        assertEquals(120, LotteryMath.costForLines(LotteryGame.HAPPY8, 4, 99))
        assertEquals(180, LotteryMath.costForLines(LotteryGame.HAPPY8, 6, 99))
    }

    @Test
    fun nonHappy8GamesKeep99Multiplier() {
        val ticket = SavedTicket(
            id = "m3",
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026001",
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6),
            secondaryNumbers = listOf(1),
            multiplier = 99
        )

        assertEquals(99, LotteryGame.DOUBLE_COLOR_BALL.normalizeMultiplier(99))
        assertEquals(198, LotteryMath.ticketCost(ticket))
    }

    @Test
    fun compoundLimitsStayWithinTenThousandLines() {
        assertEquals(7, LotteryMath.defaultCompoundNumberCount(5))
        assertEquals(18, LotteryMath.maxCompoundNumberCount(5))
        assertEquals(8568, LotteryMath.combinations(18, 5))
        assertTrue(LotteryMath.combinations(19, 5) > 10_000)
    }

    @Test
    fun softBalancedMethodGeneratesFiveUniqueValidPicksForEveryGameAndPlay() {
        val happySingle = NumberGenerator.softBalancedPicks(
            LotteryGame.HAPPY8, 5, TicketMode.SINGLE, 5, 0, DigitPlay.DIRECT, 5
        )
        assertEquals(5, happySingle.size)
        assertEquals(5, happySingle.map { it.primaryNumbers }.distinct().size)
        assertTrue(happySingle.all { it.primaryNumbers.size == 5 })

        val happyCompound = NumberGenerator.softBalancedPicks(
            LotteryGame.HAPPY8, 5, TicketMode.COMPOUND, 6, 0, DigitPlay.DIRECT, 5
        )
        assertTrue(happyCompound.all { it.primaryNumbers.size == 6 })

        val happyDantuo = NumberGenerator.softBalancedPicks(
            LotteryGame.HAPPY8, 5, TicketMode.DANTUO, 5, 0, DigitPlay.DIRECT, 5
        )
        assertTrue(happyDantuo.all {
            it.primaryBankers.isNotEmpty() &&
                it.primaryBankers.toSet().intersect(it.primaryDrags.toSet()).isEmpty() &&
                it.primaryBankers.size + it.primaryDrags.size > 5
        })

        val ssq = NumberGenerator.softBalancedPicks(
            LotteryGame.DOUBLE_COLOR_BALL, 0, TicketMode.COMPOUND, 7, 2, DigitPlay.DIRECT, 5
        )
        assertTrue(ssq.all { it.primaryNumbers.size == 7 && it.secondaryNumbers.size == 2 })

        val lotto = NumberGenerator.softBalancedPicks(
            LotteryGame.SUPER_LOTTO, 0, TicketMode.COMPOUND, 6, 3, DigitPlay.DIRECT, 5
        )
        assertTrue(lotto.all { it.primaryNumbers.size == 6 && it.secondaryNumbers.size == 3 })

        DigitPlay.entries.forEach { play ->
            val digits = NumberGenerator.softBalancedPicks(
                LotteryGame.FC3D, 0, TicketMode.SINGLE, 3, 0, play, 5
            )
            assertEquals(5, digits.size)
            assertTrue(digits.all { pick ->
                when (play) {
                    DigitPlay.DIRECT -> pick.digits.size == 3
                    DigitPlay.GROUP3 -> pick.digits.size == 3 && pick.digits.distinct().size == 2
                    DigitPlay.GROUP6 -> pick.digits.size == 3 && pick.digits.distinct().size == 3
                }
            })
        }
    }

    @Test
    fun triangleMethodProducesFreshRandomSelectionsInsideItsRule() {
        val draw = listOf(5, 12, 20, 28, 36, 44, 52, 60, 68, 76)
        val generated = List(20) { NumberGenerator.triangleNumbers(draw, 5, true) }
        assertTrue(generated.all { it.size == 5 && it.distinct().size == 5 })
        assertTrue(generated.map { it.joinToString(",") }.distinct().size > 1)
    }


    @Test
    fun hotNumberPoolKeepsAllWhenAtMost15() {
        val draws = (1..28).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026000 + index).toString(),
                date = "",
                primaryNumbers = (1..10).toList()
            )
        }

        assertEquals((1..10).toList(), NumberGenerator.hotNumberPool(draws))
    }

    @Test
    fun hotNumberPoolCapsAt15AndUsesStableTieBreak() {
        val draws = (1..28).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026000 + index).toString(),
                date = "",
                primaryNumbers = (1..20).toList()
            )
        }

        assertEquals((1..15).toList(), NumberGenerator.hotNumberPool(draws))
    }

    @Test
    fun hotPoolNumbersOnlyDrawsFromPool() {
        val draws = (1..28).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026000 + index).toString(),
                date = "",
                primaryNumbers = (1..12).toList()
            )
        }
        val pool = NumberGenerator.hotNumberPool(draws).toSet()

        repeat(20) {
            val pick = NumberGenerator.hotPoolNumbers(draws, 6)
            assertEquals(6, pick.size)
            assertEquals(6, pick.distinct().size)
            assertTrue(pick.all { it in pool })
        }
    }


    @Test
    fun hotPoolTicketPairCreatesTwoDisjointCompoundGroups() {
        val draws = (1..28).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026000 + index).toString(),
                date = "",
                primaryNumbers = (1..15).toList()
            )
        }

        repeat(20) {
            val (select3, select5) = NumberGenerator.hotPoolTicketPair(draws)
            assertEquals(4, select3.size)
            assertEquals(6, select5.size)
            assertTrue(select3.toSet().intersect(select5.toSet()).isEmpty())
            assertEquals(10, (select3 + select5).distinct().size)
        }
    }

}
