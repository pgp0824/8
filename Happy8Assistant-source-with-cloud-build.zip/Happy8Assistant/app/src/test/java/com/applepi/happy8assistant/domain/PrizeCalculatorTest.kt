package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrizeCalculatorTest {
    private val happy8Draw = DrawResult(
        game = LotteryGame.HAPPY8,
        issue = "2026001",
        date = "2026-01-01",
        primaryNumbers = (1..20).toList()
    )

    @Test
    fun happy8SingleSelectFiveThreeHitsPaysThreeYuan() {
        val ticket = SavedTicket(
            id = "h1",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.SINGLE,
            primaryNumbers = listOf(1, 2, 3, 70, 71)
        )
        val result = PrizeCalculator.calculate(ticket, happy8Draw)
        assertTrue(result.isWinner)
        assertEquals(3.0, result.fixedPrize, 0.001)
    }

    @Test
    fun happy8CompoundAndDantuoCalculateEveryCombination() {
        val compound = SavedTicket(
            id = "h2",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.COMPOUND,
            primaryNumbers = listOf(1, 2, 3, 4, 5, 70)
        )
        val compoundResult = PrizeCalculator.calculate(compound, happy8Draw)
        assertEquals(6, compoundResult.totalLines)
        assertEquals(1100.0, compoundResult.fixedPrize, 0.001)
        assertEquals(6, compoundResult.winningLines)

        val dantuo = SavedTicket(
            id = "h3",
            game = LotteryGame.HAPPY8,
            issue = happy8Draw.issue,
            playCount = 5,
            mode = TicketMode.DANTUO,
            primaryBankers = listOf(1, 2),
            primaryDrags = listOf(3, 4, 5, 70)
        )
        val dantuoResult = PrizeCalculator.calculate(dantuo, happy8Draw)
        assertEquals(4, dantuoResult.totalLines)
        assertEquals(1060.0, dantuoResult.fixedPrize, 0.001)
    }

    @Test
    fun doubleColorBallCompoundCountsEachRedBlueCombination() {
        val draw = DrawResult(
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6),
            secondaryNumbers = listOf(7)
        )
        val ticket = SavedTicket(
            id = "s1",
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = draw.issue,
            mode = TicketMode.COMPOUND,
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6, 9),
            secondaryNumbers = listOf(7, 8)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertEquals(14, result.totalLines)
        assertEquals(14, result.winningLines)
        assertEquals(2, result.dynamicWinningLines)
        assertEquals(19_200.0, result.fixedPrize, 0.001)
    }

    @Test
    fun superLottoUsesNewSevenLevelRuleFromIssue26014() {
        val draw = DrawResult(
            game = LotteryGame.SUPER_LOTTO,
            issue = "26014",
            date = "2026-02-02",
            primaryNumbers = listOf(1, 2, 3, 4, 5),
            secondaryNumbers = listOf(1, 2),
            jackpot = 700_000_000L
        )
        val ticket = SavedTicket(
            id = "d1",
            game = LotteryGame.SUPER_LOTTO,
            issue = draw.issue,
            primaryNumbers = listOf(1, 2, 3, 4, 20),
            secondaryNumbers = listOf(1, 9)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertTrue(result.isWinner)
        assertEquals("四等奖", result.prizeLevel)
        assertEquals(300.0, result.fixedPrize, 0.001)
    }

    @Test
    fun digitLotteriesSupportDirectGroup3AndGroup6() {
        val fc3dDraw = DrawResult(
            game = LotteryGame.FC3D,
            issue = "2026001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 2)
        )
        val group3 = SavedTicket(
            id = "f1",
            game = LotteryGame.FC3D,
            issue = fc3dDraw.issue,
            digitPlay = DigitPlay.GROUP3,
            digits = listOf(2, 1, 2)
        )
        assertEquals(346.0, PrizeCalculator.calculate(group3, fc3dDraw).fixedPrize, 0.001)

        val pl3Draw = DrawResult(
            game = LotteryGame.PL3,
            issue = "26001",
            date = "2026-01-01",
            primaryNumbers = listOf(1, 2, 3)
        )
        val group6 = SavedTicket(
            id = "p1",
            game = LotteryGame.PL3,
            issue = pl3Draw.issue,
            digitPlay = DigitPlay.GROUP6,
            digits = listOf(3, 1, 2)
        )
        assertEquals(173.0, PrizeCalculator.calculate(group6, pl3Draw).fixedPrize, 0.001)

        val wrongDirect = group6.copy(digitPlay = DigitPlay.DIRECT)
        assertFalse(PrizeCalculator.calculate(wrongDirect, pl3Draw).isWinner)
    }

    @Test
    fun hotColdMethodFixesTwoFifteenIssueHotNumbersAndFillsSix() {
        val rotatingPool = (2..80).filter { it != 21 }
        val draws = (0 until 15).map { index ->
            val rotating = List(18) { offset ->
                rotatingPool[(index * 18 + offset) % rotatingPool.size]
            }
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026100 - index).toString(),
                date = "",
                primaryNumbers = (listOf(1, 21) + rotating).distinct().take(20)
            )
        }
        val numbers = NumberGenerator.hotColdNumbers(draws, 6)
        assertEquals(6, numbers.size)
        assertTrue(1 in numbers)
        assertTrue(21 in numbers)
    }

    @Test
    fun consecutiveMethodUsesTwoMostActiveZonesButCanChooseAnyPairInsideThem() {
        val draws = (0 until 15).map { index ->
            DrawResult(
                game = LotteryGame.HAPPY8,
                issue = (2026200 - index).toString(),
                date = "",
                primaryNumbers = (
                    listOf(21, 22, 51, 52) +
                        (1..80).filter { it !in setOf(21, 22, 51, 52) }.drop(index).take(16)
                    ).distinct().take(20)
            )
        }
        val numbers = NumberGenerator.consecutiveNumbers(draws, 6)
        assertEquals(6, numbers.size)
        assertTrue(numbers.zipWithNext().any { (a, b) -> a in 21..30 && b == a + 1 })
        assertTrue(numbers.zipWithNext().any { (a, b) -> a in 51..60 && b == a + 1 })
    }

    @Test
    fun compoundLimitsStayWithinTenThousandLines() {
        assertEquals(7, LotteryMath.defaultCompoundNumberCount(5))
        assertEquals(18, LotteryMath.maxCompoundNumberCount(5))
        assertEquals(8568, LotteryMath.combinations(18, 5))
        assertTrue(LotteryMath.combinations(19, 5) > 10_000)
    }
}
