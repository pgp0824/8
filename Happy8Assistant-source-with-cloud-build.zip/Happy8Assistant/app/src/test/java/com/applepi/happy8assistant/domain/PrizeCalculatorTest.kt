package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PrizeCalculatorTest {
    private val draw = DrawResult(
        issue = "2026001",
        date = "2026-01-01",
        numbers = (1..20).toList()
    )

    @Test
    fun singleSelectFiveThreeHitsPaysThreeYuan() {
        val ticket = SavedTicket(
            id = "1",
            issue = draw.issue,
            playCount = 5,
            mode = TicketMode.SINGLE,
            numbers = listOf(1, 2, 3, 70, 71)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertTrue(result.isWinner)
        assertEquals(3.0, result.fixedPrize, 0.001)
    }

    @Test
    fun compoundSelectFiveSixNumbersCalculatesEveryLine() {
        val ticket = SavedTicket(
            id = "2",
            issue = draw.issue,
            playCount = 5,
            mode = TicketMode.COMPOUND,
            numbers = listOf(1, 2, 3, 4, 5, 70)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertEquals(6, result.totalLines)
        assertEquals(1100.0, result.fixedPrize, 0.001)
        assertEquals(6, result.winningLines)
    }

    @Test
    fun dantuoCalculatesCombinationsCorrectly() {
        val ticket = SavedTicket(
            id = "3",
            issue = draw.issue,
            playCount = 5,
            mode = TicketMode.DANTUO,
            bankers = listOf(1, 2),
            drags = listOf(3, 4, 5, 70)
        )
        val result = PrizeCalculator.calculate(ticket, draw)
        assertEquals(4, result.totalLines)
        assertEquals(1060.0, result.fixedPrize, 0.001)
    }

    @Test
    fun compoundNumberCountCanBeChosenWithinTenThousandLines() {
        assertEquals(7, LotteryMath.defaultCompoundNumberCount(5))
        assertEquals(18, LotteryMath.maxCompoundNumberCount(5))
        assertEquals(8568, LotteryMath.combinations(18, 5))
        assertTrue(LotteryMath.combinations(19, 5) > 10_000)
        assertEquals(10, NumberGenerator.randomNumbers(10).size)
    }

    @Test
    fun triangleUsesFirstAndLastDrawnNumbersAsAnchors() {
        val candidates = NumberGenerator.triangleCandidates(listOf(12, 45, 67), downward = true)
        assertTrue(12 in candidates)
        assertTrue(67 in candidates)
        assertTrue(21 in candidates)
        assertTrue(78 in candidates)
    }
}
