package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import org.junit.Assert.assertEquals
import org.junit.Test

class TicketSummaryCalculatorTest {
    @Test
    fun totalsCostAndKnownPrizeAcrossSavedTickets() {
        val tickets = listOf(
            SavedTicket(
                id = "winner",
                game = LotteryGame.FC3D,
                issue = "2026001",
                digitPlay = DigitPlay.DIRECT,
                digits = listOf(1, 2, 3),
                multiplier = 2
            ),
            SavedTicket(
                id = "loser",
                game = LotteryGame.FC3D,
                issue = "2026001",
                digitPlay = DigitPlay.DIRECT,
                digits = listOf(3, 2, 1),
                multiplier = 1
            ),
            SavedTicket(
                id = "pending",
                game = LotteryGame.FC3D,
                issue = "2026002",
                digitPlay = DigitPlay.DIRECT,
                digits = listOf(1, 2, 3),
                multiplier = 1
            )
        )
        val draws = listOf(
            DrawResult(
                game = LotteryGame.FC3D,
                issue = "2026001",
                date = "2026-08-05",
                primaryNumbers = listOf(1, 2, 3)
            )
        )

        val summary = TicketSummaryCalculator.calculate(tickets, draws)

        assertEquals(8L, summary.totalCost)
        assertEquals(2080.0, summary.fixedPrize, 0.0)
        assertEquals(0L, summary.dynamicWinningLines)
    }

    @Test
    fun reportsDynamicPrizeLinesSeparately() {
        val ticket = SavedTicket(
            id = "ssq-jackpot",
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026099",
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6),
            secondaryNumbers = listOf(7),
            multiplier = 1
        )
        val draw = DrawResult(
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = "2026099",
            date = "2026-08-05",
            primaryNumbers = listOf(1, 2, 3, 4, 5, 6),
            secondaryNumbers = listOf(7)
        )

        val summary = TicketSummaryCalculator.calculate(listOf(ticket), listOf(draw))

        assertEquals(2L, summary.totalCost)
        assertEquals(0.0, summary.fixedPrize, 0.0)
        assertEquals(1L, summary.dynamicWinningLines)
    }
}
