package com.applepi.happy8assistant.model

enum class TicketMode(val label: String) {
    SINGLE("单式"),
    COMPOUND("复式"),
    DANTUO("胆拖")
}

enum class DanTuoPart(val label: String) {
    BANKER("选择胆码"),
    DRAG("选择拖码")
}

data class DrawResult(
    val issue: String,
    val date: String,
    val numbers: List<Int>,
    val source: String = "中国福利彩票官网"
)

data class SavedTicket(
    val id: String,
    val issue: String,
    val playCount: Int,
    val mode: TicketMode,
    val numbers: List<Int> = emptyList(),
    val bankers: List<Int> = emptyList(),
    val drags: List<Int> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
)

data class PrizeResult(
    val checked: Boolean,
    val isWinner: Boolean,
    val fixedPrize: Double = 0.0,
    val dynamicWinningLines: Long = 0,
    val winningLines: Long = 0,
    val totalLines: Long = 0,
    val bestHitCount: Int = 0,
    val hitNumbers: List<Int> = emptyList(),
    val description: String = "待开奖"
)
