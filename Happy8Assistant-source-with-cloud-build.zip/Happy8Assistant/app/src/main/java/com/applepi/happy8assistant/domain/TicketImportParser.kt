package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import java.util.UUID

/**
 * 把用户从其他投注平台复制的号码文本转换成可自动验奖的记录。
 *
 * 约定：一行一张票；同时兼容中文逗号、空格、加号、竖线等常见分隔符。
 */
object TicketImportParser {
    private val numberRegex = Regex("(?<!\\d)\\d{1,8}(?!\\d)")
    private val happy8PlayRegex = Regex("选\\s*(10|[1-9])")
    private val issueRegex = Regex("第\\s*\\d{3,}\\s*期")
    private val dateRegex = Regex("\\d{4}\\s*[-/.年]\\s*\\d{1,2}(?:\\s*[-/.月]\\s*\\d{1,2}\\s*日?)?")
    private val amountRegex = Regex("\\d+(?:\\.\\d+)?\\s*(?:倍|元|注|张)")

    fun parse(
        game: LotteryGame,
        issue: String,
        rawText: String,
        happy8PlayCount: Int,
        digitPlay: DigitPlay,
        multiplier: Int
    ): List<SavedTicket> {
        require(issue.trim().isNotEmpty()) { "请输入购买期号" }
        require(rawText.trim().isNotEmpty()) { "请先粘贴号码" }
        require(multiplier in 1..game.maxMultiplier) {
            "${game.label}倍数需要在1—${game.maxMultiplier}之间"
        }
        if (game == LotteryGame.HAPPY8) {
            require(happy8PlayCount in 1..10) { "快乐8请选择选一至选十" }
        }

        val lines = rawText
            .replace('\u3000', ' ')
            .split(Regex("[\\r\\n;；]+"))
            .map(String::trim)
            .filter(String::isNotEmpty)

        require(lines.size <= 200) { "一次最多导入200张号码" }

        val tickets = mutableListOf<SavedTicket>()
        val errors = mutableListOf<String>()
        lines.forEachIndexed { index, line ->
            val parsed = runCatching {
                parseLine(
                    game = game,
                    issue = issue.trim(),
                    line = line,
                    happy8PlayCount = happy8PlayCount,
                    defaultDigitPlay = digitPlay,
                    multiplier = multiplier,
                    createdAt = System.currentTimeMillis() - index
                )
            }
            parsed.onSuccess { ticket ->
                if (ticket != null) tickets += ticket
            }.onFailure { error ->
                errors += "第${index + 1}行：${error.message ?: "号码格式不正确"}"
            }
        }

        if (errors.isNotEmpty()) throw IllegalArgumentException(errors.first())
        require(tickets.isNotEmpty()) { "没有识别到可导入的号码；请按一行一张票粘贴" }
        return tickets
    }

    private fun parseLine(
        game: LotteryGame,
        issue: String,
        line: String,
        happy8PlayCount: Int,
        defaultDigitPlay: DigitPlay,
        multiplier: Int,
        createdAt: Long
    ): SavedTicket? {
        val cleaned = stripMetadata(line)
        if (!containsUsableNumber(cleaned, game)) return null
        return when (game) {
            LotteryGame.HAPPY8 -> parseHappy8(
                issue,
                line,
                cleaned,
                happy8PlayCount,
                multiplier,
                createdAt
            )
            LotteryGame.DOUBLE_COLOR_BALL -> parseDoubleColorBall(
                issue,
                cleaned,
                multiplier,
                createdAt
            )
            LotteryGame.SUPER_LOTTO -> parseSuperLotto(
                issue,
                cleaned,
                multiplier,
                createdAt
            )
            LotteryGame.FC3D, LotteryGame.PL3 -> parseDigitLottery(
                game,
                issue,
                cleaned,
                defaultDigitPlay,
                multiplier,
                createdAt
            )
        }
    }

    private fun parseHappy8(
        issue: String,
        originalLine: String,
        cleanedLine: String,
        selectedPlayCount: Int,
        multiplier: Int,
        createdAt: Long
    ): SavedTicket {
        val playCount = happy8PlayRegex.find(originalLine)?.groupValues?.get(1)?.toInt()
            ?: selectedPlayCount
        require(playCount in 1..10) { "快乐8玩法必须是选一至选十" }

        val bankerMatch = Regex("(?:胆码?|胆)\\s*[:：]?\\s*(.*?)(?=(?:拖码?|拖)\\s*[:：]?|$)")
            .find(cleanedLine)
        val dragMatch = Regex("(?:拖码?|拖)\\s*[:：]?\\s*(.*)$").find(cleanedLine)
        if (bankerMatch != null || dragMatch != null) {
            require(bankerMatch != null && dragMatch != null) { "胆拖格式需要同时包含‘胆’和‘拖’" }
            val bankers = extractUniqueNumbers(bankerMatch.groupValues[1], 1..80, "胆码")
            val drags = extractUniqueNumbers(dragMatch.groupValues[1], 1..80, "拖码")
            require(bankers.isNotEmpty()) { "请填写至少1个胆码" }
            require(bankers.size < playCount) { "胆码必须少于${playCount}个" }
            require(drags.isNotEmpty()) { "请填写拖码" }
            require((bankers intersect drags.toSet()).isEmpty()) { "胆码和拖码不能重复" }
            require(bankers.size + drags.size > playCount) { "胆码和拖码总数必须多于${playCount}个" }
            val ticket = SavedTicket(
                id = UUID.randomUUID().toString(),
                game = LotteryGame.HAPPY8,
                issue = issue,
                playCount = playCount,
                mode = TicketMode.DANTUO,
                primaryBankers = bankers.sorted(),
                primaryDrags = drags.sorted(),
                multiplier = multiplier,
                createdAt = createdAt
            )
            require(LotteryMath.ticketLineCount(ticket) in 1..10_000) { "胆拖组合超过10000注" }
            return ticket
        }

        val withoutPlayLabel = cleanedLine.replace(happy8PlayRegex, " ")
        val numbers = extractUniqueNumbers(withoutPlayLabel, 1..80, "号码")
        require(numbers.size >= playCount) { "选${playCount}至少需要${playCount}个号码，当前识别到${numbers.size}个" }
        val mode = if (numbers.size == playCount) TicketMode.SINGLE else TicketMode.COMPOUND
        if (mode == TicketMode.COMPOUND) {
            require(numbers.size <= LotteryMath.maxCompoundNumberCount(playCount)) {
                "选${playCount}复式号码过多，最多${LotteryMath.maxCompoundNumberCount(playCount)}个"
            }
        }
        val ticket = SavedTicket(
            id = UUID.randomUUID().toString(),
            game = LotteryGame.HAPPY8,
            issue = issue,
            playCount = playCount,
            mode = mode,
            primaryNumbers = numbers.sorted(),
            multiplier = multiplier,
            createdAt = createdAt
        )
        require(LotteryMath.ticketLineCount(ticket) in 1..10_000) { "组合超过10000注" }
        return ticket
    }

    private fun parseDoubleColorBall(
        issue: String,
        line: String,
        multiplier: Int,
        createdAt: Long
    ): SavedTicket {
        val areas = splitAreas(line, secondaryLabels = listOf("蓝球", "蓝"))
        val reds: List<Int>
        val blues: List<Int>
        if (areas != null) {
            reds = extractUniqueNumbers(areas.first, 1..33, "红球")
            blues = extractUniqueNumbers(areas.second, 1..16, "蓝球")
        } else {
            val all = extractUniqueNumbers(line, 1..33, "号码")
            require(all.size >= 7) { "双色球至少需要6个红球和1个蓝球" }
            reds = all.dropLast(1)
            blues = listOf(all.last())
        }
        require(reds.size in 6..12) { "红球需要6—12个，当前识别到${reds.size}个" }
        require(blues.size in 1..5) { "蓝球需要1—5个，当前识别到${blues.size}个" }
        require(blues.all { it in 1..16 }) { "蓝球必须在01—16之间" }
        val mode = if (reds.size == 6 && blues.size == 1) TicketMode.SINGLE else TicketMode.COMPOUND
        val ticket = SavedTicket(
            id = UUID.randomUUID().toString(),
            game = LotteryGame.DOUBLE_COLOR_BALL,
            issue = issue,
            mode = mode,
            primaryNumbers = reds.sorted(),
            secondaryNumbers = blues.sorted(),
            multiplier = multiplier,
            createdAt = createdAt
        )
        require(LotteryMath.ticketLineCount(ticket) in 1..10_000) { "双色球组合超过10000注" }
        return ticket
    }

    private fun parseSuperLotto(
        issue: String,
        line: String,
        multiplier: Int,
        createdAt: Long
    ): SavedTicket {
        val areas = splitAreas(line, secondaryLabels = listOf("后区", "后"))
        val fronts: List<Int>
        val backs: List<Int>
        if (areas != null) {
            fronts = extractUniqueNumbers(areas.first, 1..35, "前区")
            backs = extractUniqueNumbers(areas.second, 1..12, "后区")
        } else {
            val all = extractUniqueNumbers(line, 1..35, "号码")
            require(all.size >= 7) { "大乐透至少需要5个前区和2个后区号码" }
            fronts = all.dropLast(2)
            backs = all.takeLast(2)
        }
        require(fronts.size in 5..12) { "前区需要5—12个，当前识别到${fronts.size}个" }
        require(backs.size in 2..6) { "后区需要2—6个，当前识别到${backs.size}个" }
        require(backs.all { it in 1..12 }) { "后区号码必须在01—12之间" }
        val mode = if (fronts.size == 5 && backs.size == 2) TicketMode.SINGLE else TicketMode.COMPOUND
        val ticket = SavedTicket(
            id = UUID.randomUUID().toString(),
            game = LotteryGame.SUPER_LOTTO,
            issue = issue,
            mode = mode,
            primaryNumbers = fronts.sorted(),
            secondaryNumbers = backs.sorted(),
            multiplier = multiplier,
            createdAt = createdAt
        )
        require(LotteryMath.ticketLineCount(ticket) in 1..10_000) { "大乐透组合超过10000注" }
        return ticket
    }

    private fun parseDigitLottery(
        game: LotteryGame,
        issue: String,
        line: String,
        defaultPlay: DigitPlay,
        multiplier: Int,
        createdAt: Long
    ): SavedTicket {
        val play = when {
            line.contains("组选3", ignoreCase = true) || line.contains("组三", ignoreCase = true) -> DigitPlay.GROUP3
            line.contains("组选6", ignoreCase = true) || line.contains("组六", ignoreCase = true) -> DigitPlay.GROUP6
            line.contains("直选", ignoreCase = true) -> DigitPlay.DIRECT
            else -> defaultPlay
        }
        val withoutLabels = line
            .replace("组选3", "", ignoreCase = true)
            .replace("组三", "", ignoreCase = true)
            .replace("组选6", "", ignoreCase = true)
            .replace("组六", "", ignoreCase = true)
            .replace("直选", "", ignoreCase = true)

        val compact = Regex("(?<!\\d)\\d{3}(?!\\d)").find(withoutLabels)?.value
        val digits = compact?.map { it.digitToInt() }
            ?: numberRegex.findAll(withoutLabels)
                .mapNotNull { it.value.toIntOrNull() }
                .filter { it in 0..9 }
                .toList()
        require(digits.size == 3) { "${game.label}需要3位数字，当前识别到${digits.size}位" }
        when (play) {
            DigitPlay.DIRECT -> Unit
            DigitPlay.GROUP3 -> require(digits.distinct().size == 2) { "组选3需要恰好两个数字相同" }
            DigitPlay.GROUP6 -> require(digits.distinct().size == 3) { "组选6需要三个数字各不相同" }
        }
        return SavedTicket(
            id = UUID.randomUUID().toString(),
            game = game,
            issue = issue,
            digitPlay = play,
            digits = digits,
            multiplier = multiplier,
            createdAt = createdAt
        )
    }

    private fun splitAreas(line: String, secondaryLabels: List<String>): Pair<String, String>? {
        val labelMatch = secondaryLabels
            .mapNotNull { label -> Regex(Regex.escape(label) + "\\s*[:：]?").find(line) }
            .minByOrNull { it.range.first }
        if (labelMatch != null) {
            return line.substring(0, labelMatch.range.first) to line.substring(labelMatch.range.last + 1)
        }
        val separator = Regex("[+＋|｜/／]").find(line) ?: return null
        return line.substring(0, separator.range.first) to line.substring(separator.range.last + 1)
    }

    private fun extractUniqueNumbers(text: String, range: IntRange, label: String): List<Int> {
        val values = numberRegex.findAll(text)
            .mapNotNull { match ->
                val raw = match.value
                if (raw.length >= 3) null else raw.toIntOrNull()?.takeIf { it in range }
            }
            .toList()
        require(values.isNotEmpty()) { "没有识别到${label}" }
        require(values.distinct().size == values.size) { "${label}里有重复号码" }
        return values
    }

    private fun stripMetadata(line: String): String = line
        .replace(issueRegex, " ")
        .replace(dateRegex, " ")
        .replace(amountRegex, " ")
        .replace(Regex("(?:第|期号|期次|购买期)\\s*[:：]?\\s*\\d{3,}"), " ")
        .replace(Regex("(?:共计?|合计|金额|投注额|价格)\\s*[:：]?\\s*\\d+(?:\\.\\d+)?"), " ")

    private fun containsUsableNumber(text: String, game: LotteryGame): Boolean {
        if (game == LotteryGame.FC3D || game == LotteryGame.PL3) {
            if (Regex("(?<!\\d)\\d{3}(?!\\d)").containsMatchIn(text)) return true
        }
        val numberText = if (game == LotteryGame.HAPPY8) {
            text.replace(happy8PlayRegex, " ")
        } else text
        return numberRegex.findAll(numberText).any { match ->
            val raw = match.value
            raw.length <= 2 && raw.toIntOrNull() != null
        }
    }
}
