package com.applepi.happy8assistant

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.applepi.happy8assistant.data.JingcaiSyncClient
import kotlinx.coroutines.launch
import org.json.JSONTokener

/**
 * 正常打开竞彩网公开页面，页面渲染后读取当前 DOM HTML，
 * 上传到用户自己的 Phase18F 服务。
 *
 * 不注入/伪造官方认证信息；遇官方拦截页只显示失败，不绕过。
 */
class SportteryFundamentalCaptureActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())

    private var matchId: Int = 0
    private var sportteryMid: String = ""
    private var stage = 0
    private var scheduledForUrl: String? = null

    private val basicUrl get() = "https://m.sporttery.cn/zqlszl/bssj/index.html?mid=$sportteryMid"
    private val liveUrl get() = "https://m.sporttery.cn/mjc/zqzb/?mid=$sportteryMid"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        matchId = intent.getIntExtra("matchId", 0)
        sportteryMid = intent.getStringExtra("sportteryMid").orEmpty()
        if (matchId <= 0 || sportteryMid.isBlank() || sportteryMid.startsWith("mobile:")) {
            finish()
            return
        }

        status = TextView(this).apply {
            textSize = 15f
            setPadding(28, 20, 28, 20)
            text = "正在打开竞彩网基本面…"
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url.isNullOrBlank()) return
                    if (scheduledForUrl == url) return
                    scheduledForUrl = url
                    status.text = "页面已打开，等待公开数据渲染…"
                    handler.postDelayed({ captureRenderedPage(url) }, 7000)
                }
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(status, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
            addView(webView, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
        }
        setContentView(layout)
        webView.loadUrl(basicUrl)
    }

    private fun captureRenderedPage(url: String) {
        webView.evaluateJavascript(
            "(function(){return document.documentElement ? document.documentElement.outerHTML : '';})()"
        ) { encoded ->
            val html = runCatching {
                JSONTokener(encoded).nextValue() as? String
            }.getOrNull().orEmpty()

            if (html.isBlank()) {
                status.text = "没有读取到页面内容。"
                nextOrFinish()
                return@evaluateJavascript
            }
            val marker = html.take(5000)
            if (marker.contains("请求已被拦截") || marker.contains("Access Denied", ignoreCase = true)) {
                status.text = "竞彩网返回访问控制页面；已停止，不会绕过。"
                return@evaluateJavascript
            }

            val settings = JingcaiSyncClient.loadSettings(this)
            if (JingcaiSyncClient.validateServerUrl(settings.serverBaseUrl) != null || settings.token.isBlank()) {
                status.text = "请先在乐彩助手「竞彩」页面保存服务器 HTTPS 地址和 Token。"
                return@evaluateJavascript
            }

            status.text = if (stage == 0) "基本面对阵页已渲染，正在上传…" else "比赛技术页已渲染，正在上传…"
            lifecycleScope.launch {
                runCatching {
                    JingcaiSyncClient.uploadRenderedFundamentalHtml(
                        settings.serverBaseUrl,
                        settings.token,
                        matchId,
                        sportteryMid,
                        url,
                        html
                    )
                }.onSuccess {
                    status.text = if (stage == 0) "对阵基本面已上传，继续读取比赛技术页…" else "基本面同步完成，可以返回乐彩助手。"
                    nextOrFinish()
                }.onFailure {
                    status.text = "上传失败：${it.message ?: it::class.java.simpleName}"
                }
            }
        }
    }

    private fun nextOrFinish() {
        if (stage == 0) {
            stage = 1
            scheduledForUrl = null
            handler.postDelayed({
                webView.loadUrl(liveUrl)
            }, 800)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        webView.destroy()
        super.onDestroy()
    }
}
