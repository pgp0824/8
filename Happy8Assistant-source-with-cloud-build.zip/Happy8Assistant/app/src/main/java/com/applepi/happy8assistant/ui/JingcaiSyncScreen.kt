package com.applepi.happy8assistant.ui

import android.content.Intent
import android.net.Uri
import com.applepi.happy8assistant.SportteryFundamentalCaptureActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.applepi.happy8assistant.data.JingcaiSyncClient
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun JingcaiSyncScreen() {
    val context = LocalContext.current
    val initial = remember { JingcaiSyncClient.loadSettings(context) }
    val scope = rememberCoroutineScope()

    var serverUrl by remember { mutableStateOf(initial.serverBaseUrl) }
    var token by remember { mutableStateOf(initial.token) }
    var busy by remember { mutableStateOf(false) }
    var phase by remember { mutableStateOf("等待同步") }
    var detail by remember { mutableStateOf("竞彩网负责官方竞彩/基本面，球速负责市场盘口。") }
    var matches by remember { mutableStateOf<List<JingcaiSyncClient.JingcaiMatchSummary>>(emptyList()) }
    var selected by remember { mutableStateOf<JingcaiSyncClient.FundamentalDetails?>(null) }

    suspend fun loadMatchesAndStatus() {
        val err = JingcaiSyncClient.validateServerUrl(serverUrl)
        if (err != null || token.isBlank()) {
            phase = err ?: "请填写同步 Token"
            return
        }
        busy = true
        runCatching {
            val st = JingcaiSyncClient.getServerStatus(serverUrl, token)
            val ms = JingcaiSyncClient.getJingcaiMatches(serverUrl, token)
            st to ms
        }.onSuccess { (st, ms) ->
            matches = ms
            phase = "服务器连接正常"
            detail = "竞彩 ${st.officialActiveMatches} 场 · 已匹配球速 ${st.qstyLinkedMatches} 场" +
                (st.lastQstyItemCount?.let { " · 最近球速 $it 场" } ?: "")
        }.onFailure {
            phase = "读取服务器失败"
            detail = it.message ?: it::class.java.simpleName
        }
        busy = false
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.SportsSoccer, contentDescription = null)
                        Text("竞彩足球数据中心", fontWeight = FontWeight.Bold)
                    }
                    Text(phase, style = MaterialTheme.typography.titleMedium)
                    Text(detail, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("服务器设置", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("HTTPS 地址") }
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Phase18E/18F Token") },
                        visualTransformation = PasswordVisualTransformation()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                val err = JingcaiSyncClient.validateServerUrl(serverUrl)
                                if (err != null) phase = err
                                else if (token.isBlank()) phase = "请填写同步 Token"
                                else {
                                    JingcaiSyncClient.saveSettings(context, serverUrl, token)
                                    val cleaned = JingcaiSyncClient.loadSettings(context)
                                    serverUrl = cleaned.serverBaseUrl
                                    token = cleaned.token
                                    phase = "设置已保存 · 地址/Token 已自动清洗"
                                }
                            }
                        ) {
                            Icon(Icons.Default.Save, null)
                            Text("保存")
                        }
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            enabled = !busy,
                            onClick = { scope.launch { loadMatchesAndStatus() } }
                        ) {
                            Icon(Icons.Default.Refresh, null)
                            Text("刷新")
                        }
                    }
                }
            }
        }

        item {
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy,
                onClick = {
                    val err = JingcaiSyncClient.validateServerUrl(serverUrl)
                    if (err != null) {
                        phase = err
                        return@Button
                    }
                    if (token.isBlank()) {
                        phase = "请填写同步 Token"
                        return@Button
                    }
                    JingcaiSyncClient.saveSettings(context, serverUrl, token)
                    val cleaned = JingcaiSyncClient.loadSettings(context)
                    serverUrl = cleaned.serverBaseUrl
                    token = cleaned.token
                    busy = true
                    phase = "正在读取竞彩网官方竞彩…"
                    scope.launch {
                        val official = runCatching { JingcaiSyncClient.fetchSportteryOfficial() }
                            .getOrElse {
                                busy = false
                                phase = "竞彩网读取失败"
                                detail = (it.message ?: it::class.java.simpleName) +
                                    "\n遇访问控制会停止，不绕过。"
                                return@launch
                            }
                        runCatching {
                            JingcaiSyncClient.uploadOfficial(serverUrl, token, official.rawJson)
                        }.onSuccess {
                            phase = "官方竞彩同步完成"
                            detail = "手机取得 ${official.matchCount} 场 · 服务器接收 ${it.receivedMatches} 场"
                            matches = runCatching { JingcaiSyncClient.getJingcaiMatches(serverUrl, token) }.getOrDefault(emptyList())
                        }.onFailure {
                            phase = "上传失败"
                            detail = it.message ?: it::class.java.simpleName
                        }
                        busy = false
                    }
                }
            ) {
                Icon(Icons.Default.CloudDone, null)
                Text(if (busy) "同步中…" else "同步当天竞彩足球")
            }
        }

        item {
            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    context.startActivity(Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://www.sporttery.cn/jc/jsq/zqspf/index.html")
                    ))
                }
            ) {
                Icon(Icons.Default.Language, null)
                Text("浏览器打开竞彩网")
            }
        }

        if (matches.isNotEmpty()) {
            item {
                Text("当天竞彩 · 基本面", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            matches.forEach { m ->
                item(key = "match-${m.id}") {
                    Card {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${m.matchNumStr}  ${m.league.orEmpty()}", fontWeight = FontWeight.Bold)
                            Text("${m.home}  vs  ${m.away}", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${m.kickoff.orEmpty()} · 球速${if (m.qstyLinked) "已匹配" else "未匹配"} · 基本面 ${"%.0f".format(m.coverageScore)}%",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    modifier = Modifier.weight(1f),
                                    enabled = !busy,
                                    onClick = {
                                        busy = true
                                        scope.launch {
                                            runCatching { JingcaiSyncClient.getFundamentals(serverUrl, token, m.id) }
                                                .onSuccess {
                                                    selected = it
                                                    phase = "${m.matchNumStr} 基本面已加载"
                                                }
                                                .onFailure {
                                                    phase = "基本面读取失败"
                                                    detail = it.message ?: it::class.java.simpleName
                                                }
                                            busy = false
                                        }
                                    }
                                ) { Text("查看基本面") }

                                OutlinedButton(
                                    modifier = Modifier.weight(1f),
                                    enabled = !m.sportteryMid.isNullOrBlank() && !m.sportteryMid.orEmpty().startsWith("mobile:"),
                                    onClick = {
                                        JingcaiSyncClient.saveSettings(context, serverUrl, token)
                                        context.startActivity(Intent(
                                            context,
                                            SportteryFundamentalCaptureActivity::class.java
                                        ).apply {
                                            putExtra("matchId", m.id)
                                            putExtra("sportteryMid", m.sportteryMid)
                                        })
                                    }
                                ) { Text("手机同步基本面") }
                            }
                        }
                    }
                }
            }
        }

        selected?.let { f ->
            item {
                Text("${f.match.matchNumStr} 基本面详情", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            item {
                FeatureCard(f)
            }
            item {
                MatchRowsCard("历史交锋（最多10场）", f.h2h)
            }
            item {
                MatchRowsCard("${f.match.home} 近况", f.recentHome)
            }
            item {
                MatchRowsCard("${f.match.away} 近况", f.recentAway)
            }
            item {
                StandingCard(f)
            }
            item {
                PlayerListCard("伤停 / 缺阵", f)
            }
            item {
                ScorerCard("射手信息", f)
            }
            item {
                MatchRowsCard("未来赛程", f.futureSchedule)
            }
            if (f.lineup != null || f.context != null || f.liveStats != null) {
                item {
                    TechnicalCard(f)
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("数据原则", fontWeight = FontWeight.Bold)
                    Text(
                        "基本面只显示服务器数据库已经采集到的内容。没有的数据保持为空，不用其它来源静默补齐。" +
                            "竞彩网被 403/567 拦截时停止，不尝试绕过。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(f: JingcaiSyncClient.FundamentalDetails) {
    val x = f.feature
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("特征概览 · 覆盖率 ${"%.1f".format(f.coverageScore)}%", fontWeight = FontWeight.Bold)
            if (x == null) {
                Text("暂无已入库的特征分析。", style = MaterialTheme.typography.bodySmall)
            } else {
                val homeG = x.optNullable("home_avg_goals")
                val homeGA = x.optNullable("home_avg_goals_against")
                val awayG = x.optNullable("away_avg_goals")
                val awayGA = x.optNullable("away_avg_goals_against")
                Text("${f.match.home}：场均进球 ${homeG ?: "-"} · 场均失球 ${homeGA ?: "-"}")
                Text("${f.match.away}：场均进球 ${awayG ?: "-"} · 场均失球 ${awayGA ?: "-"}")
                Text(
                    "近况：主 ${x.optNullable("home_recent_wins") ?: "-"}胜 / ${x.optNullable("home_recent_draws") ?: "-"}平 / ${x.optNullable("home_recent_losses") ?: "-"}负；" +
                        "客 ${x.optNullable("away_recent_wins") ?: "-"}胜 / ${x.optNullable("away_recent_draws") ?: "-"}平 / ${x.optNullable("away_recent_losses") ?: "-"}负",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun MatchRowsCard(title: String, rows: List<JSONObject>) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (rows.isEmpty()) {
                Text("暂无数据", style = MaterialTheme.typography.bodySmall)
            } else rows.take(10).forEach { r ->
                val home = r.optString("home_team")
                val away = r.optString("away_team")
                val hs = r.optNullable("home_goals") ?: r.optString("fulltime_score")
                val ascore = r.optNullable("away_goals")
                val score = if (ascore != null) "$hs:$ascore" else hs?.toString().orEmpty()
                Text("${r.optString("kickoff").take(16)}  $home $score $away", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun StandingCard(f: JingcaiSyncClient.FundamentalDetails) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("积分榜", fontWeight = FontWeight.Bold)
            fun line(team: String, o: JSONObject?): String {
                if (o == null) return "$team：暂无"
                return "$team：第${o.optNullable("rank") ?: "-"} · ${o.optNullable("points") ?: "-"}分 · " +
                    "${o.optNullable("won") ?: "-"}胜 ${o.optNullable("drawn") ?: "-"}平 ${o.optNullable("lost") ?: "-"}负"
            }
            Text(line(f.match.home, f.standingHome))
            Text(line(f.match.away, f.standingAway))
        }
    }
}

@Composable
private fun PlayerListCard(title: String, f: JingcaiSyncClient.FundamentalDetails) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            val rows = (f.availabilityHome.map { f.match.home to it } + f.availabilityAway.map { f.match.away to it })
            if (rows.isEmpty()) Text("暂无数据", style = MaterialTheme.typography.bodySmall)
            else rows.take(16).forEach { (team, p) ->
                Text("$team · ${p.optString("player_name")} · ${p.optString("status")} ${p.optString("reason")}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ScorerCard(title: String, f: JingcaiSyncClient.FundamentalDetails) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            val rows = (f.scorersHome.take(6).map { f.match.home to it } + f.scorersAway.take(6).map { f.match.away to it })
            if (rows.isEmpty()) Text("暂无数据", style = MaterialTheme.typography.bodySmall)
            else rows.forEach { (team, p) ->
                Text("$team · ${p.optString("player_name")} · ${p.optNullable("goals") ?: "-"}球 ${p.optNullable("assists") ?: "-"}助", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun TechnicalCard(f: JingcaiSyncClient.FundamentalDetails) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("阵容 / 场地 / 技术数据", fontWeight = FontWeight.Bold)
            f.lineup?.let {
                Text("阵型：${f.match.home} ${it.optString("home_formation").ifBlank { "-" }} · ${f.match.away} ${it.optString("away_formation").ifBlank { "-" }}")
            }
            f.context?.let {
                Text("场地：${it.optString("venue").ifBlank { "-" }} · 阶段：${it.optString("stage").ifBlank { it.optString("round_text").ifBlank { "-" } }}")
            }
            f.liveStats?.let {
                Text("比分：${it.optNullable("home_score") ?: "-"}:${it.optNullable("away_score") ?: "-"} · ${it.optString("minute_text")}")
                Text("控球：${it.optNullable("home_possession") ?: "-"}% : ${it.optNullable("away_possession") ?: "-"}%")
                Text("射正：${it.optNullable("home_shots_on_target") ?: "-"} : ${it.optNullable("away_shots_on_target") ?: "-"} · 角球：${it.optNullable("home_corners") ?: "-"} : ${it.optNullable("away_corners") ?: "-"}")
            }
        }
    }
}

private fun JSONObject.optNullable(name: String): Any? {
    if (!has(name) || isNull(name)) return null
    return opt(name)
}
