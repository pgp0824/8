package com.applepi.happy8assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.applepi.happy8assistant.data.LotteryRepository
import com.applepi.happy8assistant.domain.LotteryMath
import com.applepi.happy8assistant.domain.NumberGenerator
import com.applepi.happy8assistant.model.DanTuoPart
import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.GeneratedPick
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID


data class Happy8UiState(
    val draws: List<DrawResult> = emptyList(),
    val tickets: List<SavedTicket> = emptyList(),
    val isSyncing: Boolean = false,
    val selectedGame: LotteryGame = LotteryGame.HAPPY8,
    val playCount: Int = 5,
    val mode: TicketMode = TicketMode.SINGLE,
    val compoundPrimaryCount: Int = 7,
    val compoundSecondaryCount: Int = 2,
    val danTuoPart: DanTuoPart = DanTuoPart.BANKER,
    val primaryNumbers: Set<Int> = emptySet(),
    val secondaryNumbers: Set<Int> = emptySet(),
    val primaryBankers: Set<Int> = emptySet(),
    val primaryDrags: Set<Int> = emptySet(),
    val digitPlay: DigitPlay = DigitPlay.DIRECT,
    val digits: List<Int?> = listOf(null, null, null),
    val multiplier: Int = 1,
    val issue: String = "",
    val triangleDownward: Boolean = true,
    val softBalancedPicks: List<GeneratedPick> = emptyList(),
    val message: String? = null
) {
    val gameDraws: List<DrawResult>
        get() = draws.filter { it.game == selectedGame }
            .sortedByDescending { it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L }
    val latestDraw: DrawResult? get() = gameDraws.firstOrNull()

    val primaryRange: IntRange get() = when (selectedGame) {
        LotteryGame.HAPPY8 -> 1..80
        LotteryGame.DOUBLE_COLOR_BALL -> 1..33
        LotteryGame.SUPER_LOTTO -> 1..35
        LotteryGame.FC3D, LotteryGame.PL3 -> 0..9
    }
    val secondaryRange: IntRange get() = when (selectedGame) {
        LotteryGame.DOUBLE_COLOR_BALL -> 1..16
        LotteryGame.SUPER_LOTTO -> 1..12
        else -> 1..0
    }

    val targetPrimaryCount: Int get() = when (selectedGame) {
        LotteryGame.HAPPY8 -> if (mode == TicketMode.COMPOUND) compoundPrimaryCount else playCount
        LotteryGame.DOUBLE_COLOR_BALL -> if (mode == TicketMode.COMPOUND) compoundPrimaryCount else 6
        LotteryGame.SUPER_LOTTO -> if (mode == TicketMode.COMPOUND) compoundPrimaryCount else 5
        LotteryGame.FC3D, LotteryGame.PL3 -> 3
    }
    val targetSecondaryCount: Int get() = when (selectedGame) {
        LotteryGame.DOUBLE_COLOR_BALL -> if (mode == TicketMode.COMPOUND) compoundSecondaryCount else 1
        LotteryGame.SUPER_LOTTO -> if (mode == TicketMode.COMPOUND) compoundSecondaryCount else 2
        else -> 0
    }

    val previewTicket: SavedTicket
        get() = SavedTicket(
            id = "preview",
            game = selectedGame,
            issue = issue,
            playCount = playCount,
            mode = mode,
            primaryNumbers = primaryNumbers.sorted(),
            secondaryNumbers = secondaryNumbers.sorted(),
            primaryBankers = primaryBankers.sorted(),
            primaryDrags = primaryDrags.sorted(),
            digitPlay = digitPlay,
            digits = digits.filterNotNull(),
            multiplier = multiplier
        )

    val lineCount: Long get() = when (selectedGame) {
        LotteryGame.HAPPY8 -> when (mode) {
            TicketMode.SINGLE -> if (primaryNumbers.size == playCount) 1 else 0
            TicketMode.COMPOUND -> if (primaryNumbers.size == compoundPrimaryCount) {
                LotteryMath.ticketLineCount(previewTicket)
            } else 0
            TicketMode.DANTUO -> LotteryMath.ticketLineCount(previewTicket)
        }
        LotteryGame.DOUBLE_COLOR_BALL, LotteryGame.SUPER_LOTTO ->
            if (primaryNumbers.size == targetPrimaryCount &&
                secondaryNumbers.size == targetSecondaryCount
            ) LotteryMath.ticketLineCount(previewTicket) else 0
        LotteryGame.FC3D, LotteryGame.PL3 -> if (digits.all { it != null }) 1 else 0
    }
    val cost: Long get() = LotteryMath.ticketCost(previewTicket)
}

class Happy8ViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LotteryRepository.get(application)
    private val _state = MutableStateFlow(
        Happy8UiState(
            draws = repository.loadDraws(),
            tickets = repository.loadTickets()
        )
    )
    val state: StateFlow<Happy8UiState> = _state.asStateFlow()

    init {
        ensureIssue()
        refreshDraws(silent = true)
    }

    fun selectGame(game: LotteryGame) {
        _state.update { current ->
            val defaults = defaultsFor(game)
            current.copy(
                selectedGame = game,
                playCount = defaults.playCount,
                mode = defaults.mode,
                compoundPrimaryCount = defaults.primaryCompound,
                compoundSecondaryCount = defaults.secondaryCompound,
                primaryNumbers = emptySet(),
                secondaryNumbers = emptySet(),
                primaryBankers = emptySet(),
                primaryDrags = emptySet(),
                digitPlay = DigitPlay.DIRECT,
                digits = listOf(null, null, null),
                multiplier = 1,
                softBalancedPicks = emptyList(),
                issue = nextIssue(current.draws, game)
            )
        }
    }

    fun selectPlayCount(count: Int) {
        require(count in 1..10)
        _state.update { current ->
            val fixedMode = if (count == 1 && current.mode == TicketMode.DANTUO) {
                TicketMode.SINGLE
            } else current.mode
            current.copy(
                playCount = count,
                mode = fixedMode,
                compoundPrimaryCount = LotteryMath.defaultCompoundNumberCount(count),
                primaryNumbers = emptySet(),
                primaryBankers = emptySet(),
                primaryDrags = emptySet(),
                softBalancedPicks = emptyList()
            )
        }
    }

    fun selectMode(mode: TicketMode) {
        val game = _state.value.selectedGame
        if (mode == TicketMode.DANTUO && game != LotteryGame.HAPPY8) {
            showMessage("${game.label}当前版本先支持单式和复式")
            return
        }
        if (mode == TicketMode.DANTUO && _state.value.playCount == 1) {
            showMessage("选一不支持胆拖")
            return
        }
        _state.update {
            it.copy(
                mode = mode,
                primaryNumbers = emptySet(),
                secondaryNumbers = emptySet(),
                primaryBankers = emptySet(),
                primaryDrags = emptySet(),
                softBalancedPicks = emptyList()
            )
        }
    }

    fun setCompoundPrimaryCount(count: Int) {
        _state.update { current ->
            val range = compoundPrimaryRange(current)
            val clamped = count.coerceIn(range.first, range.last)
            current.copy(
                compoundPrimaryCount = clamped,
                primaryNumbers = current.primaryNumbers.sorted().take(clamped).toSet(),
                softBalancedPicks = emptyList()
            )
        }
    }

    fun setCompoundSecondaryCount(count: Int) {
        _state.update { current ->
            val range = compoundSecondaryRange(current)
            if (range.isEmpty()) current else {
                val clamped = count.coerceIn(range.first, range.last)
                current.copy(
                    compoundSecondaryCount = clamped,
                    secondaryNumbers = current.secondaryNumbers.sorted().take(clamped).toSet(),
                    softBalancedPicks = emptyList()
                )
            }
        }
    }

    fun setDanTuoPart(part: DanTuoPart) {
        _state.update { it.copy(danTuoPart = part) }
    }

    fun setIssue(value: String) {
        _state.update { it.copy(issue = value.filter(Char::isDigit).take(12)) }
    }

    fun setMultiplier(value: Int) {
        _state.update { it.copy(multiplier = value.coerceIn(1, 99)) }
    }

    fun togglePrimary(number: Int) {
        val current = _state.value
        if (number !in current.primaryRange) return
        _state.update { state ->
            if (state.selectedGame == LotteryGame.HAPPY8 && state.mode == TicketMode.DANTUO) {
                val bankers = state.primaryBankers.toMutableSet()
                val drags = state.primaryDrags.toMutableSet()
                if (state.danTuoPart == DanTuoPart.BANKER) {
                    drags.remove(number)
                    if (!bankers.add(number)) bankers.remove(number)
                } else {
                    bankers.remove(number)
                    if (!drags.add(number)) drags.remove(number)
                }
                state.copy(primaryBankers = bankers, primaryDrags = drags, softBalancedPicks = emptyList())
            } else {
                val next = state.primaryNumbers.toMutableSet()
                if (number in next) {
                    next.remove(number)
                    state.copy(primaryNumbers = next, softBalancedPicks = emptyList())
                } else if (next.size >= state.targetPrimaryCount) {
                    state.copy(message = "已选满${state.targetPrimaryCount}个号码，请先取消一个或调整复式数量", softBalancedPicks = emptyList())
                } else {
                    next.add(number)
                    state.copy(primaryNumbers = next, softBalancedPicks = emptyList())
                }
            }
        }
    }

    fun toggleSecondary(number: Int) {
        val current = _state.value
        if (number !in current.secondaryRange) return
        _state.update { state ->
            val next = state.secondaryNumbers.toMutableSet()
            if (number in next) {
                next.remove(number)
                state.copy(secondaryNumbers = next, softBalancedPicks = emptyList())
            } else if (next.size >= state.targetSecondaryCount) {
                state.copy(message = "后区已选满${state.targetSecondaryCount}个号码", softBalancedPicks = emptyList())
            } else {
                next.add(number)
                state.copy(secondaryNumbers = next, softBalancedPicks = emptyList())
            }
        }
    }

    fun selectDigitPlay(play: DigitPlay) {
        _state.update { it.copy(digitPlay = play, digits = listOf(null, null, null), softBalancedPicks = emptyList()) }
    }

    fun setDigit(position: Int, number: Int) {
        if (position !in 0..2 || number !in 0..9) return
        _state.update { current ->
            val next = current.digits.toMutableList()
            next[position] = number
            current.copy(digits = next, softBalancedPicks = emptyList())
        }
    }

    fun generateRandom() {
        val current = _state.value
        val pick = generateDifferentPick(current) {
            NumberGenerator.randomPick(
                game = current.selectedGame,
                playCount = current.playCount,
                mode = current.mode,
                targetPrimaryCount = current.targetPrimaryCount,
                targetSecondaryCount = current.targetSecondaryCount,
                digitPlay = current.digitPlay
            )
        }
        _state.update { applyGeneratedPick(it, pick).copy(softBalancedPicks = emptyList()) }
        showMessage("已重新随机生成一组号码")
    }

    fun generateTriangle() {
        val current = _state.value
        if (current.selectedGame != LotteryGame.HAPPY8) return
        val latest = current.latestDraw ?: run {
            showMessage("暂无快乐8开奖数据，请先刷新")
            return
        }
        val target = happy8MethodTarget(current)
        val numbers = generateDifferentHappy8(current) {
            NumberGenerator.triangleNumbers(
                latest.primaryNumbers,
                target,
                downward = current.triangleDownward
            )
        }
        applyHappy8Generated(numbers, "已按三角定位范围重新随机选号")
    }

    fun generateHotCold() {
        val current = _state.value
        if (current.selectedGame != LotteryGame.HAPPY8) return
        val target = happy8MethodTarget(current)
        if (current.gameDraws.size < 15) {
            showMessage("热冷号法需要至少15期快乐8数据，请先刷新或补全历史")
            return
        }
        val numbers = generateDifferentHappy8(current) {
            NumberGenerator.hotColdNumbers(current.gameDraws, target)
        }
        applyHappy8Generated(numbers, "已用热冷号法重新随机：2个近15期热号＋平衡号码")
    }

    fun generateConsecutive() {
        val current = _state.value
        if (current.selectedGame != LotteryGame.HAPPY8) return
        val target = happy8MethodTarget(current)
        if (target < 6) {
            showMessage("连号法需要至少6个号码，建议使用选5复式6")
            return
        }
        if (current.gameDraws.size < 15) {
            showMessage("连号法需要至少15期快乐8数据，请先刷新或补全历史")
            return
        }
        val numbers = generateDifferentHappy8(current) {
            NumberGenerator.consecutiveNumbers(current.gameDraws, target)
        }
        applyHappy8Generated(numbers, "已在两个活跃区间重新随机两组连号并补齐")
    }

    fun generateSoftBalanced(batchSize: Int) {
        if (batchSize != 1 && batchSize != 5) return
        val current = _state.value
        val avoid = buildList {
            addAll(current.softBalancedPicks)
            currentPickOrNull(current)?.let { add(it) }
        }
        val picks = NumberGenerator.softBalancedPicks(
            game = current.selectedGame,
            playCount = current.playCount,
            mode = current.mode,
            targetPrimaryCount = current.targetPrimaryCount,
            targetSecondaryCount = current.targetSecondaryCount,
            digitPlay = current.digitPlay,
            batchSize = batchSize,
            avoidPicks = avoid
        )
        if (picks.isEmpty()) {
            showMessage("生成失败，请再试一次")
            return
        }
        _state.update {
            applyGeneratedPick(it, picks.first()).copy(softBalancedPicks = picks)
        }
        showMessage("软控均衡法已重新随机生成${batchSize}组号码")
    }

    fun applySoftBalancedPick(index: Int) {
        val current = _state.value
        val pick = current.softBalancedPicks.getOrNull(index) ?: return
        _state.update { applyGeneratedPick(it, pick) }
        showMessage("已使用软控均衡法第${index + 1}组")
    }

    fun toggleTriangleDirection() {
        _state.update { it.copy(triangleDownward = !it.triangleDownward, softBalancedPicks = emptyList()) }
    }

    fun clearSelection() {
        _state.update {
            it.copy(
                primaryNumbers = emptySet(),
                secondaryNumbers = emptySet(),
                primaryBankers = emptySet(),
                primaryDrags = emptySet(),
                digits = listOf(null, null, null),
                softBalancedPicks = emptyList()
            )
        }
    }

    fun saveTicket() {
        val current = _state.value
        val validation = validate(current)
        if (validation != null) {
            showMessage(validation)
            return
        }
        val ticket = SavedTicket(
            id = UUID.randomUUID().toString(),
            game = current.selectedGame,
            issue = current.issue,
            playCount = current.playCount,
            mode = current.mode,
            primaryNumbers = current.primaryNumbers.sorted(),
            secondaryNumbers = current.secondaryNumbers.sorted(),
            primaryBankers = current.primaryBankers.sorted(),
            primaryDrags = current.primaryDrags.sorted(),
            digitPlay = current.digitPlay,
            digits = current.digits.filterNotNull(),
            multiplier = current.multiplier
        )
        repository.saveTicket(ticket)
        _state.update {
            it.copy(
                tickets = repository.loadTickets(),
                primaryNumbers = emptySet(),
                secondaryNumbers = emptySet(),
                primaryBankers = emptySet(),
                primaryDrags = emptySet(),
                digits = listOf(null, null, null),
                softBalancedPicks = emptyList(),
                message = "已保存，开奖后会自动核对"
            )
        }
    }

    fun deleteTicket(id: String) {
        repository.deleteTicket(id)
        _state.update { it.copy(tickets = repository.loadTickets(), message = "记录已删除") }
    }

    fun refreshFullHistory() {
        if (_state.value.isSyncing) return
        val game = _state.value.selectedGame
        viewModelScope.launch {
            _state.update { it.copy(isSyncing = true, message = "正在补全${game.label}历史开奖…") }
            val result = runCatching {
                withContext(Dispatchers.IO) { repository.syncFullHistory(game) }
            }
            result.onSuccess { draws ->
                _state.update {
                    it.copy(
                        draws = draws,
                        tickets = repository.loadTickets(),
                        isSyncing = false,
                        message = "${game.label}历史开奖已补全"
                    )
                }
                ensureIssue()
            }.onFailure { error ->
                _state.update {
                    it.copy(
                        isSyncing = false,
                        message = "补全失败：${error.message ?: "网络异常"}"
                    )
                }
            }
        }
    }

    fun refreshDraws(silent: Boolean = false) {
        if (_state.value.isSyncing) return
        viewModelScope.launch {
            _state.update { it.copy(isSyncing = true) }
            val result = runCatching {
                withContext(Dispatchers.IO) { repository.syncDraws() }
            }
            result.onSuccess { draws ->
                _state.update {
                    it.copy(
                        draws = draws,
                        tickets = repository.loadTickets(),
                        isSyncing = false,
                        message = if (silent) it.message else "五个彩种开奖结果已更新"
                    )
                }
                ensureIssue()
            }.onFailure { error ->
                _state.update {
                    it.copy(
                        isSyncing = false,
                        message = if (silent && it.draws.isNotEmpty()) it.message
                        else "更新失败：${error.message ?: "网络异常"}"
                    )
                }
            }
        }
    }

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    private fun applyHappy8Generated(seed: List<Int>, message: String) {
        _state.update { state ->
            when (state.mode) {
                TicketMode.SINGLE -> state.copy(
                    primaryNumbers = NumberGenerator.completeToCount(seed, state.playCount).toSet(),
                    primaryBankers = emptySet(),
                    primaryDrags = emptySet(),
                    softBalancedPicks = emptyList()
                )
                TicketMode.COMPOUND -> state.copy(
                    primaryNumbers = NumberGenerator.completeToCount(
                        seed,
                        state.compoundPrimaryCount
                    ).toSet(),
                    primaryBankers = emptySet(),
                    primaryDrags = emptySet(),
                    softBalancedPicks = emptyList()
                )
                TicketMode.DANTUO -> {
                    val bankerCount = (state.playCount - 2).coerceAtLeast(1)
                        .coerceAtMost(state.playCount - 1)
                    val total = bankerCount + (state.playCount - bankerCount + 2).coerceAtLeast(3)
                    val completed = NumberGenerator.completeToCount(seed, total).shuffled()
                    state.copy(
                        primaryNumbers = emptySet(),
                        primaryBankers = completed.take(bankerCount).toSet(),
                        primaryDrags = completed.drop(bankerCount).toSet(),
                        softBalancedPicks = emptyList()
                    )
                }
            }
        }
        showMessage(message)
    }

    private fun applyGeneratedPick(state: Happy8UiState, pick: GeneratedPick): Happy8UiState =
        state.copy(
            primaryNumbers = pick.primaryNumbers.toSet(),
            secondaryNumbers = pick.secondaryNumbers.toSet(),
            primaryBankers = pick.primaryBankers.toSet(),
            primaryDrags = pick.primaryDrags.toSet(),
            digits = if (pick.digits.isEmpty()) listOf(null, null, null)
            else pick.digits.take(3).map<Int, Int?> { it }
        )

    private fun currentPickOrNull(state: Happy8UiState): GeneratedPick? {
        val pick = GeneratedPick(
            primaryNumbers = state.primaryNumbers.sorted(),
            secondaryNumbers = state.secondaryNumbers.sorted(),
            primaryBankers = state.primaryBankers.sorted(),
            primaryDrags = state.primaryDrags.sorted(),
            digits = state.digits.filterNotNull()
        )
        val hasNumbers = pick.primaryNumbers.isNotEmpty() || pick.secondaryNumbers.isNotEmpty() ||
            pick.primaryBankers.isNotEmpty() || pick.primaryDrags.isNotEmpty() || pick.digits.isNotEmpty()
        return pick.takeIf { hasNumbers }
    }

    private fun generateDifferentPick(
        state: Happy8UiState,
        producer: () -> GeneratedPick
    ): GeneratedPick {
        val currentSignature = currentPickOrNull(state)?.let {
            NumberGenerator.pickSignature(state.selectedGame, state.digitPlay, it)
        }
        var pick = producer()
        repeat(30) {
            val signature = NumberGenerator.pickSignature(state.selectedGame, state.digitPlay, pick)
            if (signature != currentSignature) return pick
            pick = producer()
        }
        return pick
    }

    private fun generateDifferentHappy8(
        state: Happy8UiState,
        producer: () -> List<Int>
    ): List<Int> {
        val currentNumbers = when (state.mode) {
            TicketMode.DANTUO -> state.primaryBankers + state.primaryDrags
            else -> state.primaryNumbers
        }
        var numbers = producer()
        repeat(30) {
            if (numbers.toSet() != currentNumbers) return numbers
            numbers = producer()
        }
        return numbers
    }

    private fun happy8MethodTarget(state: Happy8UiState): Int = when (state.mode) {
        TicketMode.SINGLE -> state.playCount
        TicketMode.COMPOUND -> state.compoundPrimaryCount
        TicketMode.DANTUO -> (state.playCount + 2).coerceAtMost(12)
    }

    private fun ensureIssue() {
        _state.update { current ->
            if (current.issue.isNotBlank()) current
            else current.copy(issue = nextIssue(current.draws, current.selectedGame))
        }
    }

    private fun nextIssue(draws: List<DrawResult>, game: LotteryGame): String {
        val latest = draws.filter { it.game == game }
            .maxByOrNull { it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L }
            ?.issue
        val parsed = latest?.filter(Char::isDigit)?.toLongOrNull()
        return parsed?.plus(1)?.toString().orEmpty()
    }

    private fun validate(state: Happy8UiState): String? {
        if (state.issue.isBlank()) return "请输入购买期号"
        if (state.lineCount > 10_000) return "组合超过10000注，请减少复式号码数"
        return when (state.selectedGame) {
            LotteryGame.HAPPY8 -> when (state.mode) {
                TicketMode.SINGLE -> if (state.primaryNumbers.size != state.playCount) {
                    "单式需要选择${state.playCount}个号码"
                } else null
                TicketMode.COMPOUND -> if (state.primaryNumbers.size != state.compoundPrimaryCount) {
                    "复式需要选择${state.compoundPrimaryCount}个号码（当前${state.primaryNumbers.size}个）"
                } else null
                TicketMode.DANTUO -> when {
                    state.playCount < 2 -> "选一不支持胆拖"
                    state.primaryBankers.isEmpty() -> "请至少选择1个胆码"
                    state.primaryBankers.size >= state.playCount -> "胆码必须少于${state.playCount}个"
                    state.primaryBankers.size + state.primaryDrags.size <= state.playCount ->
                        "胆码和拖码总数必须多于${state.playCount}个"
                    state.lineCount <= 0 -> "拖码数量不足"
                    else -> null
                }
            }
            LotteryGame.DOUBLE_COLOR_BALL -> when {
                state.primaryNumbers.size != state.targetPrimaryCount ->
                    "红球需要选择${state.targetPrimaryCount}个"
                state.secondaryNumbers.size != state.targetSecondaryCount ->
                    "蓝球需要选择${state.targetSecondaryCount}个"
                state.mode == TicketMode.COMPOUND && state.lineCount <= 1 -> "复式至少需要多选一个号码"
                else -> null
            }
            LotteryGame.SUPER_LOTTO -> when {
                state.primaryNumbers.size != state.targetPrimaryCount ->
                    "前区需要选择${state.targetPrimaryCount}个"
                state.secondaryNumbers.size != state.targetSecondaryCount ->
                    "后区需要选择${state.targetSecondaryCount}个"
                state.mode == TicketMode.COMPOUND && state.lineCount <= 1 -> "复式至少需要多选一个号码"
                else -> null
            }
            LotteryGame.FC3D, LotteryGame.PL3 -> {
                val digits = state.digits.filterNotNull()
                when {
                    digits.size != 3 -> "请分别选择百位、十位、个位"
                    state.digitPlay == DigitPlay.GROUP3 && digits.distinct().size != 2 ->
                        "组选3需要恰好两个数字相同"
                    state.digitPlay == DigitPlay.GROUP6 && digits.distinct().size != 3 ->
                        "组选6需要三个数字各不相同"
                    else -> null
                }
            }
        }
    }

    private data class GameDefaults(
        val playCount: Int,
        val mode: TicketMode,
        val primaryCompound: Int,
        val secondaryCompound: Int
    )

    private fun defaultsFor(game: LotteryGame): GameDefaults = when (game) {
        LotteryGame.HAPPY8 -> GameDefaults(5, TicketMode.SINGLE, 7, 0)
        LotteryGame.DOUBLE_COLOR_BALL -> GameDefaults(0, TicketMode.SINGLE, 7, 2)
        LotteryGame.SUPER_LOTTO -> GameDefaults(0, TicketMode.SINGLE, 6, 3)
        LotteryGame.FC3D, LotteryGame.PL3 -> GameDefaults(0, TicketMode.SINGLE, 0, 0)
    }

    private fun compoundPrimaryRange(state: Happy8UiState): IntRange = when (state.selectedGame) {
        LotteryGame.HAPPY8 -> (state.playCount + 1)..LotteryMath.maxCompoundNumberCount(state.playCount)
        LotteryGame.DOUBLE_COLOR_BALL -> 7..12
        LotteryGame.SUPER_LOTTO -> 6..12
        LotteryGame.FC3D, LotteryGame.PL3 -> 0..0
    }

    private fun compoundSecondaryRange(state: Happy8UiState): IntRange = when (state.selectedGame) {
        LotteryGame.DOUBLE_COLOR_BALL -> 2..5
        LotteryGame.SUPER_LOTTO -> 3..6
        else -> 1..0
    }

    private fun showMessage(message: String) {
        _state.update { it.copy(message = message) }
    }
}
