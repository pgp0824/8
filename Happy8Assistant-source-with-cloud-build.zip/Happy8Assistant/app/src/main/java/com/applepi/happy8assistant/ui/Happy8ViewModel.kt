package com.applepi.happy8assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.applepi.happy8assistant.data.LotteryRepository
import com.applepi.happy8assistant.domain.LotteryMath
import com.applepi.happy8assistant.domain.NumberGenerator
import com.applepi.happy8assistant.model.DanTuoPart
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID


data class Happy8UiState(
    val draws: List<DrawResult> = emptyList(),
    val tickets: List<SavedTicket> = emptyList(),
    val isSyncing: Boolean = false,
    val playCount: Int = 5,
    val mode: TicketMode = TicketMode.SINGLE,
    val danTuoPart: DanTuoPart = DanTuoPart.BANKER,
    val selectedNumbers: Set<Int> = emptySet(),
    val bankers: Set<Int> = emptySet(),
    val drags: Set<Int> = emptySet(),
    val issue: String = "",
    val triangleDownward: Boolean = true,
    val message: String? = null
) {
    val latestDraw: DrawResult? get() = draws.firstOrNull()

    val previewTicket: SavedTicket
        get() = SavedTicket(
            id = "preview",
            issue = issue,
            playCount = playCount,
            mode = mode,
            numbers = selectedNumbers.sorted(),
            bankers = bankers.sorted(),
            drags = drags.sorted()
        )

    val lineCount: Long
        get() = when (mode) {
            TicketMode.SINGLE -> if (selectedNumbers.size == playCount) 1 else 0
            TicketMode.COMPOUND, TicketMode.DANTUO -> LotteryMath.ticketLineCount(previewTicket)
        }
    val cost: Long get() = if (lineCount == Long.MAX_VALUE) Long.MAX_VALUE else lineCount * 2
}

class Happy8ViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = LotteryRepository.get(application)
    private val _state = MutableStateFlow(
        Happy8UiState(
            draws = repository.loadDraws(),
            tickets = repository.loadTickets()
        )
    )
    val state: StateFlow<Happy8UiState> = _state.asStateFlow()

    init {
        ensureIssue()
        refreshDraws(silent = true)
    }

    fun selectPlayCount(count: Int) {
        require(count in 1..10)
        _state.update { current ->
            val fixedMode = if (count == 1 && current.mode == TicketMode.DANTUO) {
                TicketMode.SINGLE
            } else current.mode
            current.copy(
                playCount = count,
                mode = fixedMode,
                selectedNumbers = emptySet(),
                bankers = emptySet(),
                drags = emptySet()
            )
        }
    }

    fun selectMode(mode: TicketMode) {
        if (mode == TicketMode.DANTUO && _state.value.playCount == 1) {
            showMessage("选一不支持胆拖")
            return
        }
        _state.update {
            it.copy(
                mode = mode,
                selectedNumbers = emptySet(),
                bankers = emptySet(),
                drags = emptySet()
            )
        }
    }

    fun setDanTuoPart(part: DanTuoPart) {
        _state.update { it.copy(danTuoPart = part) }
    }

    fun setIssue(value: String) {
        _state.update { it.copy(issue = value.filter(Char::isDigit).take(12)) }
    }

    fun toggleNumber(number: Int) {
        if (number !in 1..80) return
        _state.update { current ->
            when (current.mode) {
                TicketMode.SINGLE, TicketMode.COMPOUND -> {
                    val next = current.selectedNumbers.toMutableSet()
                    if (!next.add(number)) next.remove(number)
                    current.copy(selectedNumbers = next)
                }

                TicketMode.DANTUO -> {
                    val bankers = current.bankers.toMutableSet()
                    val drags = current.drags.toMutableSet()
                    if (current.danTuoPart == DanTuoPart.BANKER) {
                        drags.remove(number)
                        if (!bankers.add(number)) bankers.remove(number)
                    } else {
                        bankers.remove(number)
                        if (!drags.add(number)) drags.remove(number)
                    }
                    current.copy(bankers = bankers, drags = drags)
                }
            }
        }
    }

    fun generateRandom() {
        _state.update { current ->
            when (current.mode) {
                TicketMode.SINGLE -> current.copy(
                    selectedNumbers = NumberGenerator.randomNumbers(current.playCount).toSet()
                )

                TicketMode.COMPOUND -> {
                    val count = (current.playCount + 2).coerceAtMost(15)
                    current.copy(selectedNumbers = NumberGenerator.randomNumbers(count).toSet())
                }

                TicketMode.DANTUO -> {
                    val bankerCount = (current.playCount - 2).coerceAtLeast(1)
                        .coerceAtMost(current.playCount - 1)
                    val bankers = NumberGenerator.randomNumbers(bankerCount)
                    val dragCount = (current.playCount - bankerCount + 2).coerceAtLeast(3)
                    val drags = NumberGenerator.randomNumbers(dragCount, bankers.toSet())
                    current.copy(bankers = bankers.toSet(), drags = drags.toSet())
                }
            }
        }
        showMessage("已生成一组随机号码")
    }

    fun generateTriangle() {
        val current = _state.value
        val latest = current.latestDraw
        if (latest == null) {
            showMessage("暂无开奖数据，请先刷新")
            return
        }
        val candidates = NumberGenerator.triangleCandidates(
            latest.numbers,
            downward = current.triangleDownward
        )
        _state.update { state ->
            when (state.mode) {
                TicketMode.SINGLE -> state.copy(
                    selectedNumbers = NumberGenerator.completeToCount(candidates, state.playCount).toSet()
                )

                TicketMode.COMPOUND -> {
                    val minCount = state.playCount + 1
                    state.copy(
                        selectedNumbers = NumberGenerator.completeToCount(candidates, minCount).toSet()
                    )
                }

                TicketMode.DANTUO -> {
                    val bankerCount = (state.playCount - 2).coerceAtLeast(1)
                        .coerceAtMost(state.playCount - 1)
                    val completed = NumberGenerator.completeToCount(
                        candidates,
                        bankerCount + (state.playCount - bankerCount + 2)
                    )
                    state.copy(
                        bankers = completed.take(bankerCount).toSet(),
                        drags = completed.drop(bankerCount).toSet()
                    )
                }
            }
        }
        showMessage("已按上期首球、末球生成三角定位候选")
    }

    fun toggleTriangleDirection() {
        _state.update { it.copy(triangleDownward = !it.triangleDownward) }
    }

    fun clearSelection() {
        _state.update {
            it.copy(selectedNumbers = emptySet(), bankers = emptySet(), drags = emptySet())
        }
    }

    fun saveTicket() {
        val current = _state.value
        val validation = validate(current)
        if (validation != null) {
            showMessage(validation)
            return
        }
        val ticket = SavedTicket(
            id = UUID.randomUUID().toString(),
            issue = current.issue,
            playCount = current.playCount,
            mode = current.mode,
            numbers = current.selectedNumbers.sorted(),
            bankers = current.bankers.sorted(),
            drags = current.drags.sorted()
        )
        repository.saveTicket(ticket)
        _state.update {
            it.copy(
                tickets = repository.loadTickets(),
                selectedNumbers = emptySet(),
                bankers = emptySet(),
                drags = emptySet(),
                message = "已保存，开奖后会自动核对"
            )
        }
    }

    fun deleteTicket(id: String) {
        repository.deleteTicket(id)
        _state.update { it.copy(tickets = repository.loadTickets(), message = "记录已删除") }
    }

    fun refreshFullHistory() {
        if (_state.value.isSyncing) return
        viewModelScope.launch {
            _state.update { it.copy(isSyncing = true, message = "正在补全历史开奖…") }
            val result = runCatching {
                withContext(Dispatchers.IO) { repository.syncFullHistory() }
            }
            result.onSuccess { draws ->
                _state.update {
                    it.copy(
                        draws = draws,
                        tickets = repository.loadTickets(),
                        isSyncing = false,
                        message = "历史开奖已补全，共${draws.size}期"
                    )
                }
                ensureIssue()
            }.onFailure { error ->
                _state.update {
                    it.copy(
                        isSyncing = false,
                        message = "补全失败：${error.message ?: "网络异常"}"
                    )
                }
            }
        }
    }

    fun refreshDraws(silent: Boolean = false) {
        if (_state.value.isSyncing) return
        viewModelScope.launch {
            _state.update { it.copy(isSyncing = true) }
            val result = runCatching {
                withContext(Dispatchers.IO) { repository.syncDraws() }
            }
            result.onSuccess { draws ->
                _state.update {
                    it.copy(
                        draws = draws,
                        tickets = repository.loadTickets(),
                        isSyncing = false,
                        message = if (silent) it.message else "开奖结果已更新"
                    )
                }
                ensureIssue()
            }.onFailure { error ->
                _state.update {
                    it.copy(
                        isSyncing = false,
                        message = if (silent && it.draws.isNotEmpty()) {
                            it.message
                        } else {
                            "更新失败：${error.message ?: "网络异常"}"
                        }
                    )
                }
            }
        }
    }

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    private fun ensureIssue() {
        _state.update { current ->
            if (current.issue.isNotBlank()) current
            else current.copy(issue = nextIssue(current.draws.firstOrNull()?.issue))
        }
    }

    private fun nextIssue(latestIssue: String?): String {
        val parsed = latestIssue?.toIntOrNull()
        return parsed?.plus(1)?.toString().orEmpty()
    }

    private fun validate(state: Happy8UiState): String? {
        if (state.issue.isBlank()) return "请输入购买期号"
        return when (state.mode) {
            TicketMode.SINGLE -> when {
                state.selectedNumbers.size != state.playCount ->
                    "单式需要选择${state.playCount}个号码"
                else -> null
            }

            TicketMode.COMPOUND -> when {
                state.selectedNumbers.size <= state.playCount ->
                    "复式号码必须多于${state.playCount}个"
                state.lineCount > 10_000 ->
                    "组合超过10000注，请减少号码"
                else -> null
            }

            TicketMode.DANTUO -> when {
                state.playCount < 2 -> "选一不支持胆拖"
                state.bankers.isEmpty() -> "请至少选择1个胆码"
                state.bankers.size >= state.playCount ->
                    "胆码必须少于${state.playCount}个"
                state.bankers.size + state.drags.size <= state.playCount ->
                    "胆码和拖码总数必须多于${state.playCount}个"
                state.lineCount <= 0 -> "拖码数量不足"
                state.lineCount > 10_000 -> "组合超过10000注，请减少拖码"
                else -> null
            }
        }
    }

    private fun showMessage(message: String) {
        _state.update { it.copy(message = message) }
    }
}
