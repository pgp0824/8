package com.applepi.happy8assistant

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.applepi.happy8assistant.worker.DrawSyncWorker
import com.applepi.happy8assistant.worker.NotificationHelper
import java.util.concurrent.TimeUnit

class Happy8Application : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        val request = PeriodicWorkRequestBuilder<DrawSyncWorker>(1, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "happy8_draw_sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
