package com.applepi.happy8assistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.applepi.happy8assistant.domain.LotteryMath
import com.applepi.happy8assistant.domain.PrizeCalculator
import com.applepi.happy8assistant.model.DanTuoPart
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class MainSection(val label: String, val icon: ImageVector) {
    HOME("首页", Icons.Default.Home),
    PICK("选号", Icons.Default.Casino),
    DRAWS("开奖", Icons.Default.History),
    TICKETS("我的号码", Icons.Default.CheckCircle)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Happy8App(viewModel: Happy8ViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var section by rememberSaveable { mutableStateOf(MainSection.HOME) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("乐8助手", fontWeight = FontWeight.Bold)
                        Text(
                            "仅作选号记录与验奖，不提供彩票销售",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (state.isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(12.dp))
                    } else {
                        IconButton(onClick = { viewModel.refreshDraws() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "刷新开奖")
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                MainSection.entries.forEach { item ->
                    NavigationBarItem(
                        selected = section == item,
                        onClick = { section = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (section) {
                MainSection.HOME -> HomeScreen(
                    state = state,
                    onPick = { section = MainSection.PICK },
                    onDraws = { section = MainSection.DRAWS },
                    onTickets = { section = MainSection.TICKETS }
                )
                MainSection.PICK -> PickScreen(state, viewModel)
                MainSection.DRAWS -> DrawsScreen(state.draws, state.isSyncing, viewModel::refreshFullHistory)
                MainSection.TICKETS -> TicketsScreen(
                    tickets = state.tickets,
                    draws = state.draws,
                    onDelete = viewModel::deleteTicket
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    state: Happy8UiState,
    onPick: () -> Unit,
    onDraws: () -> Unit,
    onTickets: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            LatestDrawCard(state.latestDraw)
        }
        item {
            Text("常用功能", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("手动/机选", Icons.Default.Casino, onPick, Modifier.weight(1f))
                QuickAction("三角定位", Icons.Default.AutoAwesome, onPick, Modifier.weight(1f))
                QuickAction("自动验奖", Icons.Default.CheckCircle, onTickets, Modifier.weight(1f))
            }
        }
        item {
            val pending = state.tickets.count { ticket -> state.draws.none { it.issue == ticket.issue } }
            val winners = state.tickets.count { ticket ->
                val draw = state.draws.firstOrNull { it.issue == ticket.issue }
                PrizeCalculator.calculate(ticket, draw).isWinner
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("我的记录", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("已保存 ${state.tickets.size} 张方案 · 待开奖 $pending 张 · 中奖记录 $winners 张")
                    OutlinedButton(onClick = onTickets) { Text("查看自动验奖结果") }
                }
            }
        }
        item {
            Card(onClick = onDraws) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.History, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("往期开奖", fontWeight = FontWeight.Bold)
                        Text("查看每期20个号码及实际摇出顺序", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("查看")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "三角定位和条件机选属于娱乐型选号工具，不会改变每个号码的随机概率。奖金存在限赔或浮动时，以当期官方开奖公告为准。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null)
            Text(label, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun LatestDrawCard(draw: DrawResult?) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                if (draw == null) "等待获取开奖结果" else "第${draw.issue}期",
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            if (draw == null) {
                Text("点击右上角刷新", color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text(draw.date, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                NumberFlow(draw.numbers, selected = draw.numbers.toSet(), compact = true, inverted = true)
                Text(
                    "号码按官方接口返回的摇出顺序展示",
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

@Composable
private fun PickScreen(state: Happy8UiState, viewModel: Happy8ViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("选择玩法", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..10).forEach { count ->
                    FilterChip(
                        selected = state.playCount == count,
                        onClick = { viewModel.selectPlayCount(count) },
                        label = { Text("选$count") }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TicketMode.entries.forEach { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { viewModel.selectMode(mode) },
                        enabled = mode != TicketMode.DANTUO || state.playCount >= 2,
                        label = { Text(mode.label) }
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = state.issue,
                onValueChange = viewModel::setIssue,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("购买期号") },
                placeholder = { Text("例如 2026199") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }

        if (state.mode == TicketMode.DANTUO) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DanTuoPart.entries.forEach { part ->
                        FilterChip(
                            selected = state.danTuoPart == part,
                            onClick = { viewModel.setDanTuoPart(part) },
                            label = { Text(part.label) }
                        )
                    }
                }
                Text(
                    "胆码 ${state.bankers.size} 个 · 拖码 ${state.drags.size} 个",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        item {
            Text("快速生成", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = viewModel::generateRandom, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Casino, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("随机机选")
                }
                OutlinedButton(onClick = viewModel::generateTriangle, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("三角定位")
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssistChip(
                    onClick = viewModel::toggleTriangleDirection,
                    label = { Text(if (state.triangleDownward) "方向：下三角" else "方向：上三角") },
                    leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, Modifier.size(18.dp)) }
                )
                Spacer(Modifier.width(8.dp))
                state.latestDraw?.let {
                    Text(
                        "定位点 ${it.numbers.firstOrNull()?.twoDigits()}、${it.numbers.lastOrNull()?.twoDigits()}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("01–80选号", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(
                    when (state.mode) {
                        TicketMode.DANTUO -> "胆码红色，拖码描边"
                        else -> "已选 ${state.selectedNumbers.size} 个"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(8),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(480.dp),
                userScrollEnabled = false,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items((1..80).toList()) { number ->
                    val selected = when (state.mode) {
                        TicketMode.DANTUO -> number in state.bankers || number in state.drags
                        else -> number in state.selectedNumbers
                    }
                    val banker = number in state.bankers
                    val drag = number in state.drags
                    NumberSelector(
                        number = number,
                        selected = selected,
                        banker = banker,
                        drag = drag,
                        onClick = { viewModel.toggleNumber(number) }
                    )
                }
            }
        }

        item {
            SelectionSummary(state)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = viewModel::clearSelection, modifier = Modifier.weight(1f)) {
                    Text("清空")
                }
                Button(onClick = viewModel::saveTicket, modifier = Modifier.weight(2f)) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("保存号码")
                }
            }
        }
    }
}

@Composable
private fun NumberSelector(
    number: Int,
    selected: Boolean,
    banker: Boolean,
    drag: Boolean,
    onClick: () -> Unit
) {
    val container = when {
        banker -> MaterialTheme.colorScheme.primary
        selected && !drag -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.surface
    }
    val content = if (banker || (selected && !drag)) MaterialTheme.colorScheme.onPrimary
    else MaterialTheme.colorScheme.onSurface
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .clickable(onClick = onClick),
        shape = CircleShape,
        color = container,
        contentColor = content,
        border = when {
            drag -> BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
            !selected -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            else -> null
        }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(number.twoDigits(), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SelectionSummary(state: Happy8UiState) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (state.mode) {
                TicketMode.DANTUO -> {
                    Text("胆码", fontWeight = FontWeight.Bold)
                    NumberFlow(state.bankers.sorted(), selected = state.bankers, compact = true)
                    Text("拖码", fontWeight = FontWeight.Bold)
                    NumberFlow(state.drags.sorted(), selected = emptySet(), compact = true)
                }
                else -> {
                    Text("已选号码", fontWeight = FontWeight.Bold)
                    NumberFlow(state.selectedNumbers.sorted(), selected = state.selectedNumbers, compact = true)
                }
            }
            HorizontalDivider()
            Text(
                "${state.mode.label} · ${state.lineCount.prettyCount()}注 · 金额 ¥${state.cost.prettyCount()}",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DrawsScreen(
    draws: List<DrawResult>,
    isSyncing: Boolean,
    onLoadAll: () -> Unit
) {
    if (draws.isEmpty()) {
        EmptyState("暂无开奖数据", "请检查网络并点击右上角刷新")
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(
                    Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("已缓存 ${draws.size} 期", fontWeight = FontWeight.Bold)
                        Text("需要时可从官网逐页补全历史开奖", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = onLoadAll, enabled = !isSyncing) {
                        Text(if (isSyncing) "同步中" else "补全历史")
                    }
                }
            }
        }
        items(draws, key = { it.issue }) { draw ->
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("第${draw.issue}期", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(draw.date, style = MaterialTheme.typography.bodySmall)
                    }
                    NumberFlow(draw.numbers, selected = draw.numbers.toSet(), compact = true)
                    Text(draw.source, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun TicketsScreen(
    tickets: List<SavedTicket>,
    draws: List<DrawResult>,
    onDelete: (String) -> Unit
) {
    if (tickets.isEmpty()) {
        EmptyState("还没有保存号码", "去选号页面保存后，开奖时会自动核对")
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(tickets, key = { it.id }) { ticket ->
            val draw = draws.firstOrNull { it.issue == ticket.issue }
            TicketCard(ticket, draw, onDelete)
        }
    }
}

@Composable
private fun TicketCard(ticket: SavedTicket, draw: DrawResult?, onDelete: (String) -> Unit) {
    val prize = PrizeCalculator.calculate(ticket, draw)
    val statusColor = when {
        !prize.checked -> MaterialTheme.colorScheme.secondaryContainer
        prize.isWinner -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    Card(colors = CardDefaults.cardColors(containerColor = statusColor)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("第${ticket.issue}期 · 选${ticket.playCount}${ticket.mode.label}", fontWeight = FontWeight.Bold)
                    Text(
                        formatTimestamp(ticket.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { onDelete(ticket.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "删除")
                }
            }
            when (ticket.mode) {
                TicketMode.DANTUO -> {
                    Text("胆码：${ticket.bankers.joinToString(" ") { it.twoDigits() }}")
                    Text("拖码：${ticket.drags.joinToString(" ") { it.twoDigits() }}")
                }
                else -> Text("号码：${ticket.numbers.joinToString(" ") { it.twoDigits() }}")
            }
            Text("${LotteryMath.ticketLineCount(ticket).prettyCount()}注 · ¥${(LotteryMath.ticketLineCount(ticket) * 2).prettyCount()}")
            HorizontalDivider()
            Text(prize.description, fontWeight = FontWeight.Bold)
            if (prize.checked) {
                Text(
                    "命中号码：${if (prize.hitNumbers.isEmpty()) "无" else prize.hitNumbers.joinToString(" ") { it.twoDigits() }}",
                    style = MaterialTheme.typography.bodySmall
                )
                if (prize.winningLines > 0) {
                    Text("中奖注数 ${prize.winningLines} · 最佳命中 ${prize.bestHitCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(42.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NumberFlow(
    numbers: List<Int>,
    selected: Set<Int>,
    compact: Boolean,
    inverted: Boolean = false
) {
    if (numbers.isEmpty()) {
        Text("尚未选择", style = MaterialTheme.typography.bodySmall)
        return
    }
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        numbers.forEach { number ->
            val isSelected = number in selected
            val background = when {
                inverted -> MaterialTheme.colorScheme.onPrimary
                isSelected -> MaterialTheme.colorScheme.primary
                else -> Color.Transparent
            }
            val foreground = when {
                inverted -> MaterialTheme.colorScheme.primary
                isSelected -> MaterialTheme.colorScheme.onPrimary
                else -> MaterialTheme.colorScheme.onSurface
            }
            Surface(
                shape = CircleShape,
                color = background,
                contentColor = foreground,
                border = if (!isSelected && !inverted) BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null,
                modifier = Modifier.size(if (compact) 34.dp else 40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(number.twoDigits(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun Int.twoDigits(): String = toString().padStart(2, '0')
private fun Long.prettyCount(): String = if (this == Long.MAX_VALUE) "过多" else toString()
private fun formatTimestamp(value: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.CHINA).format(Date(value))
