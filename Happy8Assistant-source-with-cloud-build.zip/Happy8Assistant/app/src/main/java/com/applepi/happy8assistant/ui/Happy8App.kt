package com.applepi.happy8assistant.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.applepi.happy8assistant.domain.LotteryMath
import com.applepi.happy8assistant.domain.PrizeCalculator
import com.applepi.happy8assistant.model.DanTuoPart
import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.GeneratedPick
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode

private enum class MainSection(val label: String, val icon: ImageVector) {
    HOME("首页", Icons.Default.Home),
    PICK("选号", Icons.Default.Casino),
    DRAWS("开奖", Icons.Default.History),
    TICKETS("验奖", Icons.Default.CheckCircle)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Happy8App(viewModel: Happy8ViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var section by remember { mutableStateOf(MainSection.HOME) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.consumeMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("乐彩助手", fontWeight = FontWeight.Bold)
                        Text(
                            "${state.selectedGame.label} · 选号、开奖、自动验奖",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshDraws() }, enabled = !state.isSyncing) {
                        Icon(Icons.Default.Refresh, contentDescription = "刷新全部开奖")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                MainSection.entries.forEach { item ->
                    NavigationBarItem(
                        selected = section == item,
                        onClick = { section = item },
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(item.label) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            GameSelector(
                selected = state.selectedGame,
                onSelect = viewModel::selectGame
            )
            HorizontalDivider()
            Box(Modifier.weight(1f)) {
                when (section) {
                    MainSection.HOME -> HomeScreen(
                        state = state,
                        onPick = { section = MainSection.PICK },
                        onDraws = { section = MainSection.DRAWS },
                        onTickets = { section = MainSection.TICKETS }
                    )
                    MainSection.PICK -> PickScreen(state, viewModel)
                    MainSection.DRAWS -> DrawsScreen(
                        game = state.selectedGame,
                        draws = state.gameDraws,
                        isSyncing = state.isSyncing,
                        onFullHistory = viewModel::refreshFullHistory
                    )
                    MainSection.TICKETS -> TicketsScreen(
                        game = state.selectedGame,
                        tickets = state.tickets.filter { it.game == state.selectedGame },
                        draws = state.draws,
                        suggestedIssue = state.issue,
                        suggestedPlayCount = state.playCount.coerceIn(1, 10),
                        suggestedMultiplier = state.multiplier,
                        onImport = viewModel::importCopiedTickets,
                        onDelete = viewModel::deleteTicket
                    )
                }
            }
        }
    }
}

@Composable
private fun GameSelector(selected: LotteryGame, onSelect: (LotteryGame) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        LotteryGame.entries.forEach { game ->
            FilterChip(
                selected = selected == game,
                onClick = { onSelect(game) },
                label = { Text(game.shortLabel) }
            )
        }
    }
}

@Composable
private fun HomeScreen(
    state: Happy8UiState,
    onPick: () -> Unit,
    onDraws: () -> Unit,
    onTickets: () -> Unit
) {
    val gameTickets = state.tickets.filter { it.game == state.selectedGame }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { LatestDrawCard(state.latestDraw, state.selectedGame) }
        item {
            Text("常用功能", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("手动/机选", Icons.Default.Casino, onPick, Modifier.weight(1f))
                QuickAction(
                    if (state.selectedGame == LotteryGame.HAPPY8) "统计选号" else "保存选号",
                    Icons.Default.AutoAwesome,
                    onPick,
                    Modifier.weight(1f)
                )
                QuickAction("自动验奖", Icons.Default.CheckCircle, onTickets, Modifier.weight(1f))
            }
        }
        item {
            val pending = gameTickets.count { ticket ->
                state.draws.none { it.game == ticket.game && it.issue == ticket.issue }
            }
            val winners = gameTickets.count { ticket ->
                val draw = state.draws.firstOrNull { it.game == ticket.game && it.issue == ticket.issue }
                PrizeCalculator.calculate(ticket, draw).isWinner
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${state.selectedGame.shortLabel}记录", fontWeight = FontWeight.Bold)
                    Text("已保存 ${gameTickets.size} 张 · 待开奖 $pending 张 · 中奖 $winners 张")
                    OutlinedButton(onClick = onTickets) { Text("查看自动验奖结果") }
                }
            }
        }
        item {
            Card(onClick = onDraws) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("往期开奖", fontWeight = FontWeight.Bold)
                        Text("数据来自福彩或体彩官方公开接口", style = MaterialTheme.typography.bodySmall)
                    }
                    Text("查看")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "冷热号、连号、三角定位和软控均衡属于选号风格工具，不会改变单个组合的理论开奖概率。每次点击都会重新随机；自动验奖以官方公告和彩票原票为最终依据。",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null)
            Text(label, textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun LatestDrawCard(draw: DrawResult?, game: LotteryGame) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("最新${game.shortLabel}开奖", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(draw?.let { "第${it.issue}期" } ?: "暂无数据", style = MaterialTheme.typography.bodySmall)
            }
            if (draw == null) {
                Text("点击右上角刷新按钮获取官方开奖结果")
            } else {
                DrawNumbers(draw)
                Text("${draw.date} · ${draw.source}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PickScreen(state: Happy8UiState, viewModel: Happy8ViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            OutlinedTextField(
                value = state.issue,
                onValueChange = viewModel::setIssue,
                label = { Text("购买期号") },
                supportingText = { Text("默认按最新期号加1，可手动修改") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        when (state.selectedGame) {
            LotteryGame.HAPPY8 -> item { Happy8Picker(state, viewModel) }
            LotteryGame.DOUBLE_COLOR_BALL -> item {
                DualAreaPicker(
                    state = state,
                    primaryTitle = "红球 01—33",
                    secondaryTitle = "蓝球 01—16",
                    primaryColorHint = "红球",
                    secondaryColorHint = "蓝球",
                    viewModel = viewModel
                )
            }
            LotteryGame.SUPER_LOTTO -> item {
                DualAreaPicker(
                    state = state,
                    primaryTitle = "前区 01—35",
                    secondaryTitle = "后区 01—12",
                    primaryColorHint = "前区",
                    secondaryColorHint = "后区",
                    viewModel = viewModel
                )
            }
            LotteryGame.FC3D, LotteryGame.PL3 -> item { DigitPicker(state, viewModel) }
        }
        if (state.hotPoolTwentyYuanCombo != null) {
            item { HotPoolTwentyYuanComboCard(state, viewModel) }
        }
        if (state.hotPoolPicks.size > 1) {
            item { HotPoolBatchCard(state, viewModel) }
        }
        if (state.softBalancedPicks.size > 1) {
            item { SoftBalancedBatchCard(state, viewModel) }
        }
        item {
            SectionCard("倍投设置") {
                CountStepper(
                    label = "投注倍数",
                    value = state.multiplier,
                    min = 1,
                    max = state.maxMultiplier,
                    onChange = viewModel::setMultiplier
                )
                Text(
                    if (state.selectedGame == LotteryGame.HAPPY8) {
                        if (state.hotPoolTwentyYuanCombo != null) {
                            "每注2元；快乐8支持单倍或2—15倍。当前20元组合共10注 × ${state.multiplier}倍"
                        } else {
                            "每注2元；快乐8支持单倍或2—15倍。当前 ${state.lineCount}注 × ${state.multiplier}倍"
                        }
                    } else {
                        "每注2元，当前 ${state.lineCount}注 × ${state.multiplier}倍"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        if (state.hotPoolTwentyYuanCombo == null) {
            item { SelectionSummary(state) }
        }
        item {
            val batchCount = when {
                state.hotPoolTwentyYuanCombo != null -> 2
                state.hotPoolPicks.size > 1 -> state.hotPoolPicks.size
                state.softBalancedPicks.size > 1 -> state.softBalancedPicks.size
                else -> 0
            }
            Button(
                onClick = viewModel::saveActiveBatch,
                modifier = Modifier.fillMaxWidth(),
                enabled = if (batchCount > 1) true else state.lineCount in 1..10_000
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (batchCount > 1) "一次保存${batchCount}注并自动验奖"
                    else "保存选号并自动验奖"
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Happy8Picker(state: Happy8UiState, viewModel: Happy8ViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionCard("选择玩法") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                (1..10).forEach { count ->
                    FilterChip(
                        selected = state.playCount == count,
                        onClick = { viewModel.selectPlayCount(count) },
                        label = { Text("选$count") }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TicketMode.entries.forEach { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { viewModel.selectMode(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
            if (state.mode == TicketMode.COMPOUND) {
                Spacer(Modifier.height(10.dp))
                CountStepper(
                    label = "复式号码数量",
                    value = state.compoundPrimaryCount,
                    min = state.playCount + 1,
                    max = LotteryMath.maxCompoundNumberCount(state.playCount),
                    onChange = viewModel::setCompoundPrimaryCount
                )
                Text(
                    "预计 ${LotteryMath.combinations(state.compoundPrimaryCount, state.playCount)} 注",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (state.mode == TicketMode.DANTUO) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DanTuoPart.entries.forEach { part ->
                        FilterChip(
                            selected = state.danTuoPart == part,
                            onClick = { viewModel.setDanTuoPart(part) },
                            label = { Text(part.label) }
                        )
                    }
                }
                Text(
                    "胆码：${state.primaryBankers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}\n" +
                        "拖码：${state.primaryDrags.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        SectionCard("选号工具") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = viewModel::generateRandom, label = { Text("随机机选") }, leadingIcon = {
                    Icon(Icons.Default.Casino, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(onClick = viewModel::generateTriangle, label = { Text("三角定位") }, leadingIcon = {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(onClick = { viewModel.generateHotPool(1) }, label = { Text("热号池 1注") }, leadingIcon = {
                    Icon(Icons.Default.LocalFireDepartment, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(onClick = { viewModel.generateHotPool(5) }, label = { Text("热号池 5注") }, leadingIcon = {
                    Icon(Icons.Default.LocalFireDepartment, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(
                    onClick = viewModel::generateHotPoolTwentyYuanCombo,
                    label = { Text("热号池20元组合") },
                    leadingIcon = {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, Modifier.size(18.dp))
                    }
                )
                AssistChip(onClick = viewModel::generateHotCold, label = { Text("热冷号法") }, leadingIcon = {
                    Icon(Icons.Default.Tune, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(onClick = viewModel::generateConsecutive, label = { Text("连号法") }, leadingIcon = {
                    Icon(Icons.Default.Tune, contentDescription = null, Modifier.size(18.dp))
                })
                AssistChip(
                    onClick = { viewModel.generateSoftBalanced(1) },
                    label = { Text("软控均衡 1注") },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, Modifier.size(18.dp)) }
                )
                AssistChip(
                    onClick = { viewModel.generateSoftBalanced(5) },
                    label = { Text("软控均衡 5注") },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, Modifier.size(18.dp)) }
                )
                AssistChip(
                    onClick = viewModel::toggleTriangleDirection,
                    label = { Text(if (state.triangleDownward) "下三角" else "上三角") }
                )
                AssistChip(onClick = viewModel::clearSelection, label = { Text("清空") })
            }
            Text(
                "热号池：取近7期至少3次、近14期至少5次、近28期至少8次的共同热号；" +
                    "超过15个按综合热度取前15个，否则全部保留。可按当前玩法生成1注或5注，" +
                    "每次点击都会重新随机；生成5注时尽量降低注间重号。20元组合会同时生成选三复式4码和选五复式6码，并优先做到两注不重号。\n" +
                    "热冷号法：近15期热号池中随机取2个热号，再随机加权补齐。\n" +
                    "连号法：近15期判断两个活跃区间，每次重新随机区间内连号和补充号码。\n" +
                    "软控均衡法：先随机，再对奇偶、大小和区间做宽松筛选；可生成1注或5注。",
                style = MaterialTheme.typography.bodySmall
            )
            if (state.hotPoolNumbers.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "热号池（${state.hotPoolNumbers.size}个）：\n" +
                        state.hotPoolNumbers.joinToString("  ") { two(it) },
                    style = MaterialTheme.typography.bodyMedium
                )
            }

        }

        SectionCard("01—80手动选号") {
            NumberGrid(
                range = 1..80,
                selected = state.primaryNumbers,
                bankers = state.primaryBankers,
                drags = state.primaryDrags,
                onToggle = viewModel::togglePrimary,
                columns = 8
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DualAreaPicker(
    state: Happy8UiState,
    primaryTitle: String,
    secondaryTitle: String,
    primaryColorHint: String,
    secondaryColorHint: String,
    viewModel: Happy8ViewModel
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionCard("投注方式") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(TicketMode.SINGLE, TicketMode.COMPOUND).forEach { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { viewModel.selectMode(mode) },
                        label = { Text(mode.label) }
                    )
                }
            }
            if (state.mode == TicketMode.COMPOUND) {
                Spacer(Modifier.height(10.dp))
                val primaryMin = if (state.selectedGame == LotteryGame.DOUBLE_COLOR_BALL) 7 else 6
                val primaryMax = 12
                val secondaryMin = if (state.selectedGame == LotteryGame.DOUBLE_COLOR_BALL) 2 else 3
                val secondaryMax = if (state.selectedGame == LotteryGame.DOUBLE_COLOR_BALL) 5 else 6
                CountStepper(
                    label = "${primaryColorHint}数量",
                    value = state.compoundPrimaryCount,
                    min = primaryMin,
                    max = primaryMax,
                    onChange = viewModel::setCompoundPrimaryCount
                )
                Spacer(Modifier.height(8.dp))
                CountStepper(
                    label = "${secondaryColorHint}数量",
                    value = state.compoundSecondaryCount,
                    min = secondaryMin,
                    max = secondaryMax,
                    onChange = viewModel::setCompoundSecondaryCount
                )
            }
        }
        SectionCard("选号工具") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = viewModel::generateRandom, label = { Text("随机机选") })
                AssistChip(onClick = { viewModel.generateSoftBalanced(1) }, label = { Text("软控均衡 1注") })
                AssistChip(onClick = { viewModel.generateSoftBalanced(5) }, label = { Text("软控均衡 5注") })
                AssistChip(onClick = viewModel::clearSelection, label = { Text("清空") })
            }
            Text(
                "软控均衡法对前后区分别随机并进行宽松的奇偶、大小与分区平衡；5组之间尽量减少重号。",
                style = MaterialTheme.typography.bodySmall
            )
        }
        SectionCard(primaryTitle) {
            Text("已选 ${state.primaryNumbers.size}/${state.targetPrimaryCount}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            NumberGrid(
                range = state.primaryRange,
                selected = state.primaryNumbers,
                onToggle = viewModel::togglePrimary,
                columns = if (state.selectedGame == LotteryGame.DOUBLE_COLOR_BALL) 7 else 7
            )
        }
        SectionCard(secondaryTitle) {
            Text("已选 ${state.secondaryNumbers.size}/${state.targetSecondaryCount}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            NumberGrid(
                range = state.secondaryRange,
                selected = state.secondaryNumbers,
                onToggle = viewModel::toggleSecondary,
                columns = 6,
                secondaryStyle = true
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DigitPicker(state: Happy8UiState, viewModel: Happy8ViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionCard("投注方式") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DigitPlay.entries.forEach { play ->
                    FilterChip(
                        selected = state.digitPlay == play,
                        onClick = { viewModel.selectDigitPlay(play) },
                        label = { Text(play.label) }
                    )
                }
            }
            Text(
                when (state.digitPlay) {
                    DigitPlay.DIRECT -> "三个数字与顺序都必须一致"
                    DigitPlay.GROUP3 -> "三个数字中恰好有两个相同，顺序不限"
                    DigitPlay.GROUP6 -> "三个数字各不相同，顺序不限"
                },
                style = MaterialTheme.typography.bodySmall
            )
        }
        SectionCard("手动选号") {
            listOf("百位", "十位", "个位").forEachIndexed { index, label ->
                Text("$label：${state.digits[index]?.toString() ?: "未选"}", fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(5.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..9).forEach { number ->
                        NumberBall(
                            number = number,
                            selected = state.digits[index] == number,
                            onClick = { viewModel.setDigit(index, number) },
                            twoDigits = false
                        )
                    }
                }
                if (index < 2) Spacer(Modifier.height(10.dp))
            }
        }
        SectionCard("选号工具") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = viewModel::generateRandom, label = { Text("随机机选") })
                AssistChip(onClick = { viewModel.generateSoftBalanced(1) }, label = { Text("软控均衡 1注") })
                AssistChip(onClick = { viewModel.generateSoftBalanced(5) }, label = { Text("软控均衡 5注") })
                AssistChip(onClick = viewModel::clearSelection, label = { Text("清空") })
            }
            Text(
                "直选、组选3和组选6都会保持玩法约束，再对奇偶、大小和数字跨度做软平衡。",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun HotPoolTwentyYuanComboCard(state: Happy8UiState, viewModel: Happy8ViewModel) {
    val combo = state.hotPoolTwentyYuanCombo ?: return
    val multiplier = state.multiplier
    val selectThreeCost = 8L * multiplier
    val selectFiveCost = 12L * multiplier
    val overlap = combo.selectThreeCompound4.primaryNumbers.toSet()
        .intersect(combo.selectFiveCompound6.primaryNumbers.toSet())
        .size

    SectionCard("热号池 · 20元组合") {
        Text(
            "两注都由本次热号池随机生成。优先不重号；热号池不足10个时自动采用当前条件下的最少重号。",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        OutlinedCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("选三复式4码", fontWeight = FontWeight.Bold)
                Text(combo.selectThreeCompound4.primaryNumbers.joinToString(" ") { two(it) })
                Text("4注 · 当前${multiplier}倍 ¥${selectThreeCost}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("选五复式6码", fontWeight = FontWeight.Bold)
                Text(combo.selectFiveCompound6.primaryNumbers.joinToString(" ") { two(it) })
                Text("6注 · 当前${multiplier}倍 ¥${selectFiveCost}", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            if (overlap == 0) "两注号码：无重复"
            else "两注号码：重复${overlap}个（已是当前热号池可达到的最少值）",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            "基础金额20元；当前${multiplier}倍合计 ¥${selectThreeCost + selectFiveCost}",
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = viewModel::saveHotPoolTwentyYuanCombo,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("一次保存这2注")
        }
    }
}

@Composable
private fun HotPoolBatchCard(state: Happy8UiState, viewModel: Happy8ViewModel) {
    SectionCard("热号池 · 本次5注") {
        Text(
            "5注均由本次点击重新随机生成，并尽量减少相互重号。可以逐注查看，也可以一次保存全部5注。",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        state.hotPoolPicks.forEachIndexed { index, pick ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("第${index + 1}注", fontWeight = FontWeight.Bold)
                        Text(formatGeneratedPick(state, pick), style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { viewModel.applyHotPoolPick(index) }) {
                        Text("查看")
                    }
                }
            }
            if (index < state.hotPoolPicks.lastIndex) Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = viewModel::saveHotPoolBatch,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("一次保存这5注")
        }
    }
}

@Composable
private fun SoftBalancedBatchCard(state: Happy8UiState, viewModel: Happy8ViewModel) {
    SectionCard("软控均衡法 · 本次5注") {
        Text(
            "每注都由本次点击重新随机生成，并尽量减少重复。可以逐注查看，也可以一次保存全部5注。",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        state.softBalancedPicks.forEachIndexed { index, pick ->
            OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("第${index + 1}注", fontWeight = FontWeight.Bold)
                        Text(formatGeneratedPick(state, pick), style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { viewModel.applySoftBalancedPick(index) }) {
                        Text("查看")
                    }
                }
            }
            if (index < state.softBalancedPicks.lastIndex) Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = viewModel::saveSoftBalancedBatch,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("一次保存这5注")
        }
    }
}

private fun formatGeneratedPick(state: Happy8UiState, pick: GeneratedPick): String = when (state.selectedGame) {
    LotteryGame.HAPPY8 -> if (state.mode == TicketMode.DANTUO) {
        "胆 ${pick.primaryBankers.joinToString(" ") { two(it) }} · 拖 ${pick.primaryDrags.joinToString(" ") { two(it) }}"
    } else {
        pick.primaryNumbers.joinToString(" ") { two(it) }
    }
    LotteryGame.DOUBLE_COLOR_BALL ->
        "红 ${pick.primaryNumbers.joinToString(" ") { two(it) }} · 蓝 ${pick.secondaryNumbers.joinToString(" ") { two(it) }}"
    LotteryGame.SUPER_LOTTO ->
        "前 ${pick.primaryNumbers.joinToString(" ") { two(it) }} · 后 ${pick.secondaryNumbers.joinToString(" ") { two(it) }}"
    LotteryGame.FC3D, LotteryGame.PL3 -> pick.digits.joinToString(" ")
}

@Composable
private fun SelectionSummary(state: Happy8UiState) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("选号汇总", fontWeight = FontWeight.Bold)
            Text(formatCurrentSelection(state))
            Text(
                "${state.lineCount} 注 × ${state.multiplier} 倍 · ¥${state.cost}",
                fontWeight = FontWeight.Bold
            )
            if (state.lineCount > 10_000) {
                Text("超过10000注，请减少复式号码", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun CountStepper(
    label: String,
    value: Int,
    min: Int,
    max: Int,
    onChange: (Int) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { onChange(value - 1) }, enabled = value > min) { Text("−") }
        Text("$value", modifier = Modifier.width(46.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = { onChange(value + 1) }, enabled = value < max) { Text("+") }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NumberGrid(
    range: IntRange,
    selected: Set<Int>,
    onToggle: (Int) -> Unit,
    columns: Int,
    bankers: Set<Int> = emptySet(),
    drags: Set<Int> = emptySet(),
    secondaryStyle: Boolean = false,
    twoDigits: Boolean = true
) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        maxItemsInEachRow = columns,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        range.forEach { number ->
            NumberBall(
                number = number,
                selected = number in selected || number in bankers || number in drags,
                banker = number in bankers,
                drag = number in drags,
                secondaryStyle = secondaryStyle,
                twoDigits = twoDigits,
                onClick = { onToggle(number) }
            )
        }
    }
}

@Composable
private fun NumberBall(
    number: Int,
    selected: Boolean,
    onClick: () -> Unit,
    banker: Boolean = false,
    drag: Boolean = false,
    secondaryStyle: Boolean = false,
    twoDigits: Boolean = true
) {
    val selectedColor = when {
        banker -> MaterialTheme.colorScheme.tertiary
        drag -> MaterialTheme.colorScheme.secondary
        secondaryStyle -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.primary
    }
    Surface(
        modifier = Modifier
            .size(39.dp)
            .clickable(onClick = onClick),
        shape = CircleShape,
        color = if (selected) selectedColor else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (selected) selectedColor else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                if (twoDigits && number < 10) "0$number" else number.toString(),
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun DrawsScreen(
    game: LotteryGame,
    draws: List<DrawResult>,
    isSyncing: Boolean,
    onFullHistory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${game.label}开奖结果", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("已缓存 ${draws.size} 期", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick = onFullHistory, enabled = !isSyncing) {
                    Text(if (isSyncing) "更新中" else "补全历史")
                }
            }
        }
        if (draws.isEmpty()) {
            item { Text("暂无开奖数据，请点击右上角刷新。") }
        } else {
            items(draws, key = { "${it.game.name}-${it.issue}" }) { draw ->
                OutlinedCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row {
                            Text("第${draw.issue}期", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(draw.date, style = MaterialTheme.typography.bodySmall)
                        }
                        DrawNumbers(draw)
                        Text(draw.source, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TicketsScreen(
    game: LotteryGame,
    tickets: List<SavedTicket>,
    draws: List<DrawResult>,
    suggestedIssue: String,
    suggestedPlayCount: Int,
    suggestedMultiplier: Int,
    onImport: (String, String, Int, DigitPlay, String) -> Boolean,
    onDelete: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("${game.label}保存与自动验奖", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        item {
            ImportTicketsCard(
                game = game,
                suggestedIssue = suggestedIssue,
                suggestedPlayCount = suggestedPlayCount,
                suggestedMultiplier = suggestedMultiplier,
                onImport = onImport
            )
        }
        if (tickets.isEmpty()) {
            item { Text("还没有保存号码。可在上方粘贴外部号码，或去选号页面保存。") }
        } else {
            items(tickets, key = { it.id }) { ticket ->
                val draw = draws.firstOrNull { it.game == ticket.game && it.issue == ticket.issue }
                val prize = PrizeCalculator.calculate(ticket, draw)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            !prize.checked -> MaterialTheme.colorScheme.surfaceVariant
                            prize.isWinner -> MaterialTheme.colorScheme.primaryContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                    )
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("第${ticket.issue}期 · ${ticketTitle(ticket)}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { onDelete(ticket.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "删除")
                            }
                        }
                        Text(formatTicket(ticket))
                        Text(
                            "${LotteryMath.ticketLineCount(ticket)} 注 × ${ticket.multiplier} 倍 · " +
                                "¥${LotteryMath.ticketCost(ticket)}"
                        )
                        HorizontalDivider()
                        Text(
                            when {
                                !prize.checked -> "待开奖"
                                prize.isWinner -> prize.description
                                else -> "未中奖"
                            },
                            fontWeight = FontWeight.Bold,
                            color = if (prize.isWinner) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                        if (prize.hitNumbers.isNotEmpty()) {
                            val hitText = prize.hitNumbers.joinToString("、") {
                                if (ticket.game == LotteryGame.FC3D || ticket.game == LotteryGame.PL3) it.toString()
                                else two(it)
                            }
                            Text("命中：$hitText", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ImportTicketsCard(
    game: LotteryGame,
    suggestedIssue: String,
    suggestedPlayCount: Int,
    suggestedMultiplier: Int,
    onImport: (String, String, Int, DigitPlay, String) -> Boolean
) {
    val clipboardManager = LocalClipboardManager.current
    var issue by remember(game) { mutableStateOf(suggestedIssue) }
    var rawText by remember(game) { mutableStateOf("") }
    var happy8PlayCount by remember(game) { mutableStateOf(suggestedPlayCount.coerceIn(1, 10)) }
    var digitPlay by remember(game) { mutableStateOf(DigitPlay.DIRECT) }
    var multiplier by remember(game) { mutableStateOf(suggestedMultiplier.toString()) }

    LaunchedEffect(game, suggestedIssue) {
        if (issue.isBlank()) issue = suggestedIssue
    }

    val example = when (game) {
        LotteryGame.HAPPY8 -> "每行一张，例如：04 10 29 40 42；复式可多填号码，胆拖写‘胆 01 02 拖 03 04 05 06’。"
        LotteryGame.DOUBLE_COLOR_BALL -> "每行一张，例如：01 02 03 04 05 06 + 07。复式多蓝球时请用 + 或 | 分开红球和蓝球。"
        LotteryGame.SUPER_LOTTO -> "每行一张，例如：01 02 03 04 05 + 06 07。复式请用 + 或 | 分开前区和后区。"
        LotteryGame.FC3D, LotteryGame.PL3 -> "每行一张，例如：123 或 1 2 3；也可在号码前写直选、组选3、组选6。"
    }

    OutlinedCard {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("粘贴号码导入", fontWeight = FontWeight.Bold)
            Text(
                "从其他地方复制投注号码，粘贴后直接保存并自动验奖。$example",
                style = MaterialTheme.typography.bodySmall
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = issue,
                    onValueChange = { issue = it.filter(Char::isDigit) },
                    label = { Text("购买期号") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = multiplier,
                    onValueChange = { multiplier = it.filter(Char::isDigit).take(2) },
                    label = { Text("倍数") },
                    supportingText = { Text("1—${game.maxMultiplier}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(0.55f)
                )
            }

            if (game == LotteryGame.HAPPY8) {
                Text("快乐8玩法", style = MaterialTheme.typography.labelMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    (1..10).forEach { count ->
                        FilterChip(
                            selected = happy8PlayCount == count,
                            onClick = { happy8PlayCount = count },
                            label = { Text("选$count") }
                        )
                    }
                }
            }

            if (game == LotteryGame.FC3D || game == LotteryGame.PL3) {
                Text("默认玩法", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    DigitPlay.entries.forEach { play ->
                        FilterChip(
                            selected = digitPlay == play,
                            onClick = { digitPlay = play },
                            label = { Text(play.label) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = rawText,
                onValueChange = { rawText = it },
                label = { Text("号码文本（一行一张）") },
                minLines = 4,
                maxLines = 8,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        clipboardManager.getText()?.text?.takeIf { it.isNotBlank() }?.let {
                            rawText = it
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("粘贴剪贴板")
                }
                Button(
                    onClick = {
                        val imported = onImport(
                            issue,
                            rawText,
                            happy8PlayCount,
                            digitPlay,
                            multiplier
                        )
                        if (imported) rawText = ""
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("导入并保存")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DrawNumbers(draw: DrawResult) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        if (draw.game == LotteryGame.SUPER_LOTTO) Text("前区", style = MaterialTheme.typography.labelSmall)
        if (draw.game == LotteryGame.DOUBLE_COLOR_BALL) Text("红球", style = MaterialTheme.typography.labelSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            draw.primaryNumbers.forEach { number ->
                StaticBall(
                    number = number,
                    twoDigits = draw.game != LotteryGame.FC3D && draw.game != LotteryGame.PL3
                )
            }
        }
        if (draw.secondaryNumbers.isNotEmpty()) {
            Text(
                if (draw.game == LotteryGame.SUPER_LOTTO) "后区" else "蓝球",
                style = MaterialTheme.typography.labelSmall
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                draw.secondaryNumbers.forEach { number -> StaticBall(number, secondary = true) }
            }
        }
    }
}

@Composable
private fun StaticBall(
    number: Int,
    secondary: Boolean = false,
    twoDigits: Boolean = true
) {
    val color = if (secondary) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
    Surface(shape = CircleShape, color = color, modifier = Modifier.size(34.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                if (twoDigits && number < 10) "0$number" else number.toString(),
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}

private fun formatCurrentSelection(state: Happy8UiState): String = when (state.selectedGame) {
    LotteryGame.HAPPY8 -> if (state.mode == TicketMode.DANTUO) {
        "胆码 ${state.primaryBankers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}；" +
            "拖码 ${state.primaryDrags.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}"
    } else {
        state.primaryNumbers.sorted().joinToString("、") { two(it) }.ifBlank { "尚未选号" }
    }
    LotteryGame.DOUBLE_COLOR_BALL ->
        "红球 ${state.primaryNumbers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}；" +
            "蓝球 ${state.secondaryNumbers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}"
    LotteryGame.SUPER_LOTTO ->
        "前区 ${state.primaryNumbers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}；" +
            "后区 ${state.secondaryNumbers.sorted().joinToString("、") { two(it) }.ifBlank { "未选" }}"
    LotteryGame.FC3D, LotteryGame.PL3 ->
        "${state.digitPlay.label} ${state.digits.joinToString("") { it?.toString() ?: "_" }}"
}

private fun ticketTitle(ticket: SavedTicket): String = when (ticket.game) {
    LotteryGame.HAPPY8 -> "选${ticket.playCount}${ticket.mode.label}"
    LotteryGame.DOUBLE_COLOR_BALL, LotteryGame.SUPER_LOTTO -> ticket.mode.label
    LotteryGame.FC3D, LotteryGame.PL3 -> ticket.digitPlay?.label ?: "直选"
}

private fun formatTicket(ticket: SavedTicket): String = when (ticket.game) {
    LotteryGame.HAPPY8 -> if (ticket.mode == TicketMode.DANTUO) {
        "胆码 ${ticket.primaryBankers.joinToString("、") { two(it) }}；拖码 ${ticket.primaryDrags.joinToString("、") { two(it) }}"
    } else ticket.primaryNumbers.joinToString("、") { two(it) }
    LotteryGame.DOUBLE_COLOR_BALL ->
        "红 ${ticket.primaryNumbers.joinToString("、") { two(it) }}；蓝 ${ticket.secondaryNumbers.joinToString("、") { two(it) }}"
    LotteryGame.SUPER_LOTTO ->
        "前 ${ticket.primaryNumbers.joinToString("、") { two(it) }}；后 ${ticket.secondaryNumbers.joinToString("、") { two(it) }}"
    LotteryGame.FC3D, LotteryGame.PL3 -> ticket.digits.joinToString("")
}

private fun two(number: Int): String = if (number < 10) "0$number" else number.toString()
