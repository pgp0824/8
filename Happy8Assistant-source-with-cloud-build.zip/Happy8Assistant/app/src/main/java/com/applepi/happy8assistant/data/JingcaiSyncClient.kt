package com.applepi.happy8assistant.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * 手机端竞彩足球官方同步。
 *
 * 原则：
 * 1. 只访问中国体育彩票公开 HTTPS 页面/API；
 * 2. 不绕过 403/567/WAF，不伪造认证或签名；
 * 3. 官方返回原样转发到用户自己的 Phase18E 服务器；
 * 4. Phase18E 再负责竞彩白名单落库与球速盘口重新匹配。
 */
object JingcaiSyncClient {
    private const val PRIMARY_ENDPOINT =
        "https://webapi.sporttery.cn/gateway/jc/football/getMatchCalculatorV1.qry?poolCode=hhad,had,crs,ttg,hafu&channel=c"
    private const val ALTERNATE_ENDPOINT =
        "https://webapi.sporttery.cn/gateway/uniform/football/getMatchCalculatorV1.qry?poolCode=hhad,had,crs,ttg,hafu&channel=c"

    private const val PREFS = "jingcai_sync"
    private const val KEY_SERVER = "server_base_url"
    private const val KEY_TOKEN = "sync_token"

    data class Settings(
        val serverBaseUrl: String,
        val token: String
    )

    data class FetchResult(
        val rawJson: String,
        val matchCount: Int,
        val lastUpdateTime: String?
    )

    data class UploadResult(
        val responseJson: String,
        val receivedMatches: Int,
        val officialActiveMatches: Int?,
        val qstyLinkedMatches: Int?
    )

    data class ServerStatus(
        val rawJson: String,
        val officialActiveMatches: Int,
        val qstyLinkedMatches: Int,
        val lastMobileMatchCount: Int,
        val lastMobileSyncAt: String?,
        val lastQstyItemCount: Int?
    )

    fun loadSettings(context: Context): Settings {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Settings(
            serverBaseUrl = sp.getString(KEY_SERVER, "") ?: "",
            token = sp.getString(KEY_TOKEN, "") ?: ""
        )
    }

    fun saveSettings(context: Context, serverBaseUrl: String, token: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SERVER, serverBaseUrl.trim().trimEnd('/'))
            .putString(KEY_TOKEN, token.trim())
            .apply()
    }

    fun validateServerUrl(value: String): String? {
        val s = value.trim().trimEnd('/')
        if (s.isBlank()) return "请填写服务器 HTTPS 地址"
        if (!s.startsWith("https://", ignoreCase = true)) {
            return "服务器地址必须使用 https://"
        }
        return null
    }

    suspend fun fetchSportteryOfficial(): FetchResult = withContext(Dispatchers.IO) {
        try {
            fetchSportteryEndpoint(PRIMARY_ENDPOINT)
        } catch (e: SportteryHttpException) {
            // 401/403/429/451/567 属于官方访问控制：直接停止，不换路由规避。
            if (e.code in setOf(401, 403, 429, 451, 567)) throw e
            fetchSportteryEndpoint(ALTERNATE_ENDPOINT)
        } catch (e: SportteryPayloadException) {
            // 仅在公开路由/返回结构不匹配时尝试官方另一路由。
            fetchSportteryEndpoint(ALTERNATE_ENDPOINT)
        }
    }

    private fun fetchSportteryEndpoint(endpoint: String): FetchResult {
        val connection = (URL(endpoint).openConnection() as HttpsURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 25_000
            useCaches = false
            setRequestProperty("Accept", "application/json,text/plain,*/*")
            setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9")
        }

        try {
            val code = connection.responseCode
            val body = readBody(connection, code)
            if (code !in 200..299) {
                throw SportteryHttpException(code, "竞彩网官方接口 HTTP $code${body.shortDetail()}")
            }

            if (body.take(500).contains("<html", ignoreCase = true)) {
                throw SportteryPayloadException("竞彩网返回访问控制页面")
            }

            val root = runCatching { JSONObject(body) }
                .getOrElse { throw SportteryPayloadException("竞彩网返回的不是有效 JSON") }
            val value = root.optJSONObject("value")
                ?: throw SportteryPayloadException("竞彩网返回缺少 value 数据")

            val groups = value.optJSONArray("matchInfoList")
                ?: throw SportteryPayloadException("竞彩网返回缺少 matchInfoList")

            var count = 0
            for (i in 0 until groups.length()) {
                val group = groups.optJSONObject(i) ?: continue
                count += group.optJSONArray("subMatchList")?.length() ?: 0
            }
            if (count <= 0) throw SportteryPayloadException("竞彩网当前没有可同步的竞彩足球比赛")

            return FetchResult(
                rawJson = body,
                matchCount = count,
                lastUpdateTime = value.optString("lastUpdateTime").takeIf { it.isNotBlank() }
            )
        } finally {
            connection.disconnect()
        }
    }

    private class SportteryHttpException(val code: Int, message: String) : IllegalStateException(message)
    private class SportteryPayloadException(message: String) : IllegalStateException(message)

    suspend fun uploadOfficial(
        serverBaseUrl: String,
        token: String,
        rawJson: String
    ): UploadResult = withContext(Dispatchers.IO) {
        require(validateServerUrl(serverBaseUrl) == null) { "服务器地址必须使用 HTTPS" }
        require(token.isNotBlank()) { "请填写同步 Token" }

        val url = "${serverBaseUrl.trim().trimEnd('/')}/api/sporttery/sync"
        val connection = (URL(url).openConnection() as HttpsURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 30_000
            doOutput = true
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer ${token.trim()}")
        }

        try {
            connection.outputStream.use { it.write(rawJson.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val body = readBody(connection, code)
            if (code !in 200..299) {
                throw IllegalStateException("服务器同步 HTTP $code${body.shortDetail()}")
            }

            val root = JSONObject(body)
            val status = root.optJSONObject("status")
            UploadResult(
                responseJson = body,
                receivedMatches = root.optInt("receivedMatches", 0),
                officialActiveMatches = status?.optInt("officialActiveMatches")?.takeIf { it >= 0 },
                qstyLinkedMatches = status?.optInt("qstyLinkedMatches")?.takeIf { it >= 0 }
            )
        } finally {
            connection.disconnect()
        }
    }

    suspend fun getServerStatus(serverBaseUrl: String, token: String): ServerStatus =
        withContext(Dispatchers.IO) {
            require(validateServerUrl(serverBaseUrl) == null) { "服务器地址必须使用 HTTPS" }
            require(token.isNotBlank()) { "请填写同步 Token" }

            val url = "${serverBaseUrl.trim().trimEnd('/')}/api/sporttery/status"
            val connection = (URL(url).openConnection() as HttpsURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
                useCaches = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer ${token.trim()}")
            }

            try {
                val code = connection.responseCode
                val body = readBody(connection, code)
                if (code !in 200..299) {
                    throw IllegalStateException("服务器状态 HTTP $code${body.shortDetail()}")
                }
                val root = JSONObject(body)
                val qsty = root.optJSONObject("lastQstyCapture")
                ServerStatus(
                    rawJson = body,
                    officialActiveMatches = root.optInt("officialActiveMatches", 0),
                    qstyLinkedMatches = root.optInt("qstyLinkedMatches", 0),
                    lastMobileMatchCount = root.optInt("lastMobileMatchCount", 0),
                    lastMobileSyncAt = root.optString("lastMobileSyncAt").takeIf { it.isNotBlank() && it != "null" },
                    lastQstyItemCount = qsty?.optInt("item_count")?.takeIf { it >= 0 }
                )
            } finally {
                connection.disconnect()
            }
        }


    data class JingcaiMatchSummary(
        val id: Int,
        val sportteryMid: String?,
        val matchNumStr: String,
        val businessDate: String?,
        val league: String?,
        val home: String,
        val away: String,
        val kickoff: String?,
        val qstyLinked: Boolean,
        val coverageScore: Double
    )

    data class FundamentalDetails(
        val rawJson: String,
        val match: JingcaiMatchSummary,
        val coverageScore: Double,
        val coverageFlags: Map<String, Boolean>,
        val feature: JSONObject?,
        val h2h: List<JSONObject>,
        val recentHome: List<JSONObject>,
        val recentAway: List<JSONObject>,
        val standingHome: JSONObject?,
        val standingAway: JSONObject?,
        val availabilityHome: List<JSONObject>,
        val availabilityAway: List<JSONObject>,
        val scorersHome: List<JSONObject>,
        val scorersAway: List<JSONObject>,
        val futureSchedule: List<JSONObject>,
        val lineup: JSONObject?,
        val context: JSONObject?,
        val liveStats: JSONObject?
    )

    suspend fun getJingcaiMatches(serverBaseUrl: String, token: String): List<JingcaiMatchSummary> =
        withContext(Dispatchers.IO) {
            val root = authenticatedJsonGet(
                "${serverBaseUrl.trim().trimEnd('/')}/api/jingcai/matches",
                token
            )
            val arr = root.optJSONArray("matches") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    add(parseMatchSummary(o))
                }
            }
        }

    suspend fun getFundamentals(
        serverBaseUrl: String,
        token: String,
        matchId: Int
    ): FundamentalDetails = withContext(Dispatchers.IO) {
        val root = authenticatedJsonGet(
            "${serverBaseUrl.trim().trimEnd('/')}/api/jingcai/match/$matchId/fundamentals",
            token
        )
        val match = parseMatchSummary(root.getJSONObject("match"))
        val coverage = root.optJSONObject("coverage")
        val coverageFlags = linkedMapOf<String, Boolean>()
        coverage?.optJSONObject("coverage_json")
            ?.optJSONObject("flags")
            ?.let { flags ->
                val it = flags.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    coverageFlags[k] = flags.optInt(k, 0) == 1
                }
            }

        fun array(name: String): List<JSONObject> {
            val a = root.optJSONArray(name) ?: return emptyList()
            return buildList {
                for (i in 0 until a.length()) {
                    a.optJSONObject(i)?.let(::add)
                }
            }
        }
        fun nestedArray(parent: String, child: String): List<JSONObject> {
            val a = root.optJSONObject(parent)?.optJSONArray(child) ?: return emptyList()
            return buildList {
                for (i in 0 until a.length()) {
                    a.optJSONObject(i)?.let(::add)
                }
            }
        }

        FundamentalDetails(
            rawJson = root.toString(),
            match = match,
            coverageScore = coverage?.optDouble("coverage_score", 0.0) ?: match.coverageScore,
            coverageFlags = coverageFlags,
            feature = root.optJSONObject("feature"),
            h2h = array("h2h"),
            recentHome = nestedArray("recentForm", "home"),
            recentAway = nestedArray("recentForm", "away"),
            standingHome = root.optJSONObject("standings")?.optJSONObject("home"),
            standingAway = root.optJSONObject("standings")?.optJSONObject("away"),
            availabilityHome = nestedArray("availability", "home"),
            availabilityAway = nestedArray("availability", "away"),
            scorersHome = nestedArray("scorers", "home"),
            scorersAway = nestedArray("scorers", "away"),
            futureSchedule = array("futureSchedule"),
            lineup = root.optJSONObject("lineup"),
            context = root.optJSONObject("context"),
            liveStats = root.optJSONObject("liveStats")
        )
    }

    suspend fun uploadRenderedFundamentalHtml(
        serverBaseUrl: String,
        token: String,
        matchId: Int,
        sportteryMid: String,
        sourceUrl: String,
        renderedHtml: String
    ): String = withContext(Dispatchers.IO) {
        require(validateServerUrl(serverBaseUrl) == null) { "服务器地址必须使用 HTTPS" }
        val body = JSONObject()
            .put("matchId", matchId)
            .put("sportteryMid", sportteryMid)
            .put("sourceUrl", sourceUrl)
            .put("renderedHtml", renderedHtml)
            .toString()
        authenticatedJsonPost(
            "${serverBaseUrl.trim().trimEnd('/')}/api/sporttery/fundamentals/sync",
            token,
            body
        ).toString()
    }

    private fun parseMatchSummary(o: JSONObject): JingcaiMatchSummary =
        JingcaiMatchSummary(
            id = o.optInt("id"),
            sportteryMid = o.optString("sportteryMid").takeIf { it.isNotBlank() && it != "null" },
            matchNumStr = o.optString("matchNumStr"),
            businessDate = o.optString("businessDate").takeIf { it.isNotBlank() && it != "null" },
            league = o.optString("league").takeIf { it.isNotBlank() && it != "null" },
            home = o.optString("home"),
            away = o.optString("away"),
            kickoff = o.optString("kickoff").takeIf { it.isNotBlank() && it != "null" },
            qstyLinked = o.optBoolean("qstyLinked", false),
            coverageScore = o.optDouble("coverageScore", 0.0)
        )

    private fun authenticatedJsonGet(url: String, token: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpsURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 25_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer ${token.trim()}")
        }
        try {
            val code = connection.responseCode
            val body = readBody(connection, code)
            if (code !in 200..299) {
                throw IllegalStateException("服务器 HTTP $code${body.shortDetail()}")
            }
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun authenticatedJsonPost(url: String, token: String, body: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpsURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 35_000
            doOutput = true
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Authorization", "Bearer ${token.trim()}")
        }
        try {
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val response = readBody(connection, code)
            if (code !in 200..299) {
                throw IllegalStateException("服务器 HTTP $code${response.shortDetail()}")
            }
            return JSONObject(response)
        } finally {
            connection.disconnect()
        }
    }

    private fun readBody(connection: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
    }

    private fun String.shortDetail(): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.isBlank()) "" else ": ${clean.take(160)}"
    }
}
