package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.PrizeResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import kotlin.math.min
import kotlin.random.Random

sealed interface PrizeValue {
    data class Fixed(val amount: Double) : PrizeValue
    data class Dynamic(val maxAmount: Double? = null) : PrizeValue
}

object Happy8Rules {
    const val NEW_RULE_START_ISSUE = 2025350

    private val oldRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.6)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(53.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(100.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(21.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(3000.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(10000.0), 6 to PrizeValue.Fixed(288.0), 5 to PrizeValue.Fixed(28.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(88.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Fixed(300000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(200.0), 6 to PrizeValue.Fixed(20.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(800.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    private val newRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.5)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(52.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(93.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(20.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(2880.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(8500.0), 6 to PrizeValue.Fixed(300.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(80.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Dynamic(250_000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(225.0), 6 to PrizeValue.Fixed(22.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(720.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    fun prizeFor(issue: String, playCount: Int, hitCount: Int): PrizeValue? {
        val issueNumber = issue.toIntOrNull() ?: Int.MAX_VALUE
        val table = if (issueNumber >= NEW_RULE_START_ISSUE) newRules else oldRules
        return table[playCount]?.get(hitCount)
    }
}

object LotteryMath {
    fun combinations(n: Int, k: Int): Long {
        if (k < 0 || n < 0 || k > n) return 0
        if (k == 0 || k == n) return 1
        val useK = min(k, n - k)
        var result = 1L
        for (i in 1..useK) {
            val numerator = n - useK + i
            if (result > Long.MAX_VALUE / numerator) return Long.MAX_VALUE
            result = result * numerator / i
        }
        return result
    }

    fun maxCompoundNumberCount(playCount: Int, maxLines: Long = 10_000): Int {
        require(playCount in 1..10)
        var best = playCount + 1
        for (count in (playCount + 1)..80) {
            if (combinations(count, playCount) > maxLines) break
            best = count
        }
        return best
    }

    fun defaultCompoundNumberCount(playCount: Int): Int =
        (playCount + 2).coerceAtMost(maxCompoundNumberCount(playCount))

    fun ticketLineCount(ticket: SavedTicket): Long = when (ticket.game) {
        LotteryGame.HAPPY8 -> when (ticket.mode) {
            TicketMode.SINGLE -> 1
            TicketMode.COMPOUND -> combinations(ticket.primaryNumbers.size, ticket.playCount)
            TicketMode.DANTUO -> combinations(
                ticket.primaryDrags.size,
                ticket.playCount - ticket.primaryBankers.size
            )
        }

        LotteryGame.DOUBLE_COLOR_BALL ->
            combinations(ticket.primaryNumbers.size, 6) * ticket.secondaryNumbers.size

        LotteryGame.SUPER_LOTTO ->
            combinations(ticket.primaryNumbers.size, 5) * combinations(ticket.secondaryNumbers.size, 2)

        LotteryGame.FC3D, LotteryGame.PL3 -> 1
    }

    fun ticketCost(ticket: SavedTicket): Long {
        val baseCost = safeMultiply(ticketLineCount(ticket), 2L)
        return safeMultiply(baseCost, ticket.multiplier.coerceIn(1, 99).toLong())
    }

    private fun safeMultiply(left: Long, right: Long): Long {
        if (left == 0L || right == 0L) return 0L
        return if (left > Long.MAX_VALUE / right) Long.MAX_VALUE else left * right
    }
}

object PrizeCalculator {
    fun calculate(ticket: SavedTicket, draw: DrawResult?): PrizeResult {
        if (draw == null || draw.game != ticket.game || draw.issue != ticket.issue) {
            return PrizeResult(
                checked = false,
                isWinner = false,
                totalLines = LotteryMath.ticketLineCount(ticket)
            )
        }
        return when (ticket.game) {
            LotteryGame.HAPPY8 -> calculateHappy8(ticket, draw)
            LotteryGame.DOUBLE_COLOR_BALL -> calculateDoubleColorBall(ticket, draw)
            LotteryGame.SUPER_LOTTO -> calculateSuperLotto(ticket, draw)
            LotteryGame.FC3D, LotteryGame.PL3 -> calculateDigitLottery(ticket, draw)
        }
    }

    private fun calculateHappy8(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningSet = draw.primaryNumbers.toSet()
        val allTicketNumbers = when (ticket.mode) {
            TicketMode.DANTUO -> ticket.primaryBankers + ticket.primaryDrags
            else -> ticket.primaryNumbers
        }
        val hitNumbers = allTicketNumbers.filter { it in winningSet }.distinct().sorted()
        var fixedPrize = 0.0
        var dynamicLines = 0L
        var winningLines = 0L
        var bestHit = 0
        val totalLines = LotteryMath.ticketLineCount(ticket)

        fun addOutcome(hitCount: Int, lineCount: Long) {
            if (lineCount <= 0) return
            val prize = Happy8Rules.prizeFor(ticket.issue, ticket.playCount, hitCount) ?: return
            bestHit = maxOf(bestHit, hitCount)
            winningLines += lineCount
            when (prize) {
                is PrizeValue.Fixed -> fixedPrize += prize.amount * lineCount
                is PrizeValue.Dynamic -> dynamicLines += lineCount
            }
        }

        when (ticket.mode) {
            TicketMode.SINGLE -> addOutcome(ticket.primaryNumbers.count { it in winningSet }, 1)
            TicketMode.COMPOUND -> {
                val hits = ticket.primaryNumbers.count { it in winningSet }
                val misses = ticket.primaryNumbers.size - hits
                for (hitCount in 0..ticket.playCount) {
                    addOutcome(
                        hitCount,
                        LotteryMath.combinations(hits, hitCount) *
                            LotteryMath.combinations(misses, ticket.playCount - hitCount)
                    )
                }
            }
            TicketMode.DANTUO -> {
                val bankerHits = ticket.primaryBankers.count { it in winningSet }
                val dragHits = ticket.primaryDrags.count { it in winningSet }
                val dragMisses = ticket.primaryDrags.size - dragHits
                val chosenFromDrag = ticket.playCount - ticket.primaryBankers.size
                for (selectedHitDrags in 0..chosenFromDrag) {
                    addOutcome(
                        bankerHits + selectedHitDrags,
                        LotteryMath.combinations(dragHits, selectedHitDrags) *
                            LotteryMath.combinations(dragMisses, chosenFromDrag - selectedHitDrags)
                    )
                }
            }
        }

        return buildPrizeResult(
            totalLines = totalLines,
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = bestHit,
            hitNumbers = hitNumbers,
            levels = if (winningLines > 0) linkedMapOf("快乐8中奖" to winningLines) else linkedMapOf(),
            multiplier = ticket.multiplier
        )
    }

    private fun calculateDoubleColorBall(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningReds = draw.primaryNumbers.toSet()
        val winningBlue = draw.secondaryNumbers.firstOrNull()
        val redHits = ticket.primaryNumbers.count { it in winningReds }
        val redMisses = ticket.primaryNumbers.size - redHits
        val blueHitLines = if (winningBlue != null && winningBlue in ticket.secondaryNumbers) 1 else 0
        val blueMissLines = ticket.secondaryNumbers.size - blueHitLines
        val levels = linkedMapOf<String, Long>()
        var fixedPrize = 0.0
        var dynamicLines = 0L

        fun add(redHit: Int, blueHit: Int, lines: Long) {
            if (lines <= 0) return
            val award = ssqAward(redHit, blueHit) ?: return
            levels[award.first] = levels.getOrDefault(award.first, 0) + lines
            when (val value = award.second) {
                is PrizeValue.Fixed -> fixedPrize += value.amount * lines
                is PrizeValue.Dynamic -> dynamicLines += lines
            }
        }

        for (hit in 0..6) {
            val redLines = LotteryMath.combinations(redHits, hit) *
                LotteryMath.combinations(redMisses, 6 - hit)
            add(hit, 1, redLines * blueHitLines)
            add(hit, 0, redLines * blueMissLines)
        }
        val winningLines = levels.values.sum()
        return buildPrizeResult(
            totalLines = LotteryMath.ticketLineCount(ticket),
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = redHits + blueHitLines,
            hitNumbers = ticket.primaryNumbers.filter { it in winningReds }.sorted(),
            levels = levels,
            multiplier = ticket.multiplier
        )
    }

    private fun ssqAward(redHit: Int, blueHit: Int): Pair<String, PrizeValue>? = when {
        redHit == 6 && blueHit == 1 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
        redHit == 6 -> "二等奖" to PrizeValue.Dynamic()
        redHit == 5 && blueHit == 1 -> "三等奖" to PrizeValue.Fixed(3000.0)
        redHit == 5 || (redHit == 4 && blueHit == 1) -> "四等奖" to PrizeValue.Fixed(200.0)
        redHit == 4 || (redHit == 3 && blueHit == 1) -> "五等奖" to PrizeValue.Fixed(10.0)
        blueHit == 1 && redHit in 0..2 -> "六等奖" to PrizeValue.Fixed(5.0)
        else -> null
    }

    private fun calculateSuperLotto(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningFront = draw.primaryNumbers.toSet()
        val winningBack = draw.secondaryNumbers.toSet()
        val frontHits = ticket.primaryNumbers.count { it in winningFront }
        val frontMisses = ticket.primaryNumbers.size - frontHits
        val backHits = ticket.secondaryNumbers.count { it in winningBack }
        val backMisses = ticket.secondaryNumbers.size - backHits
        val levels = linkedMapOf<String, Long>()
        var fixedPrize = 0.0
        var dynamicLines = 0L

        for (frontHit in 0..5) {
            val frontLines = LotteryMath.combinations(frontHits, frontHit) *
                LotteryMath.combinations(frontMisses, 5 - frontHit)
            for (backHit in 0..2) {
                val lines = frontLines * LotteryMath.combinations(backHits, backHit) *
                    LotteryMath.combinations(backMisses, 2 - backHit)
                if (lines <= 0) continue
                val award = dltAward(ticket.issue, frontHit, backHit, draw.jackpot) ?: continue
                levels[award.first] = levels.getOrDefault(award.first, 0) + lines
                when (val value = award.second) {
                    is PrizeValue.Fixed -> fixedPrize += value.amount * lines
                    is PrizeValue.Dynamic -> dynamicLines += lines
                }
            }
        }
        val winningLines = levels.values.sum()
        return buildPrizeResult(
            totalLines = LotteryMath.ticketLineCount(ticket),
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = frontHits + backHits,
            hitNumbers = ticket.primaryNumbers.filter { it in winningFront }.sorted(),
            levels = levels,
            multiplier = ticket.multiplier
        )
    }

    private fun dltAward(
        issue: String,
        frontHit: Int,
        backHit: Int,
        jackpot: Long?
    ): Pair<String, PrizeValue>? {
        val numericIssue = issue.filter(Char::isDigit).takeLast(5).toIntOrNull() ?: Int.MAX_VALUE
        val isNewRule = numericIssue >= 26014
        if (!isNewRule) {
            return when {
                frontHit == 5 && backHit == 2 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
                frontHit == 5 && backHit == 1 -> "二等奖" to PrizeValue.Dynamic()
                frontHit == 5 -> "三等奖" to PrizeValue.Fixed(10_000.0)
                frontHit == 4 && backHit == 2 -> "四等奖" to PrizeValue.Fixed(3000.0)
                frontHit == 4 && backHit == 1 -> "五等奖" to PrizeValue.Fixed(300.0)
                frontHit == 3 && backHit == 2 -> "六等奖" to PrizeValue.Fixed(200.0)
                frontHit == 4 -> "七等奖" to PrizeValue.Fixed(100.0)
                (frontHit == 3 && backHit == 1) || (frontHit == 2 && backHit == 2) ->
                    "八等奖" to PrizeValue.Fixed(15.0)
                frontHit == 3 || (frontHit == 2 && backHit == 1) ||
                    (frontHit == 1 && backHit == 2) || backHit == 2 ->
                    "九等奖" to PrizeValue.Fixed(5.0)
                else -> null
            }
        }

        val upgraded = jackpot != null && jackpot >= 800_000_000L
        val level3 = if (upgraded) 6666.0 else 5000.0
        val level4 = if (upgraded) 380.0 else 300.0
        val level5 = if (upgraded) 200.0 else 150.0
        val level6 = if (upgraded) 18.0 else 15.0
        val level7 = if (upgraded) 7.0 else 5.0
        return when {
            frontHit == 5 && backHit == 2 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
            frontHit == 5 && backHit == 1 -> "二等奖" to PrizeValue.Dynamic()
            frontHit == 5 || (frontHit == 4 && backHit == 2) -> "三等奖" to PrizeValue.Fixed(level3)
            frontHit == 4 && backHit == 1 -> "四等奖" to PrizeValue.Fixed(level4)
            frontHit == 4 || (frontHit == 3 && backHit == 2) -> "五等奖" to PrizeValue.Fixed(level5)
            (frontHit == 3 && backHit == 1) || (frontHit == 2 && backHit == 2) ->
                "六等奖" to PrizeValue.Fixed(level6)
            frontHit == 3 || (frontHit == 2 && backHit == 1) ||
                (frontHit == 1 && backHit == 2) || backHit == 2 ->
                "七等奖" to PrizeValue.Fixed(level7)
            else -> null
        }
    }

    private fun calculateDigitLottery(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val drawDigits = draw.primaryNumbers.take(3)
        val ticketDigits = ticket.digits.take(3)
        val play = ticket.digitPlay ?: DigitPlay.DIRECT
        val isWinner = when (play) {
            DigitPlay.DIRECT -> ticketDigits == drawDigits
            DigitPlay.GROUP3 ->
                drawDigits.distinct().size == 2 && ticketDigits.sorted() == drawDigits.sorted()
            DigitPlay.GROUP6 ->
                drawDigits.distinct().size == 3 && ticketDigits.sorted() == drawDigits.sorted()
        }
        val singleAmount = when (play) {
            DigitPlay.DIRECT -> 1040.0
            DigitPlay.GROUP3 -> 346.0
            DigitPlay.GROUP6 -> 173.0
        }
        val multiplier = ticket.multiplier.coerceIn(1, 99)
        val amount = singleAmount * multiplier
        return if (isWinner) {
            PrizeResult(
                checked = true,
                isWinner = true,
                fixedPrize = amount,
                winningLines = 1,
                totalLines = 1,
                bestHitCount = 3,
                hitNumbers = drawDigits,
                prizeLevel = play.label,
                description = "中得${play.label}，${multiplier}倍，奖金 ¥${formatMoney(amount)}"
            )
        } else {
            PrizeResult(
                checked = true,
                isWinner = false,
                totalLines = 1,
                bestHitCount = ticketDigits.zip(drawDigits).count { it.first == it.second },
                description = "未中奖"
            )
        }
    }

    private fun buildPrizeResult(
        totalLines: Long,
        fixedPrize: Double,
        dynamicLines: Long,
        winningLines: Long,
        bestHit: Int,
        hitNumbers: List<Int>,
        levels: LinkedHashMap<String, Long>,
        multiplier: Int
    ): PrizeResult {
        val safeMultiplier = multiplier.coerceIn(1, 99)
        val multipliedFixedPrize = fixedPrize * safeMultiplier
        val isWinner = winningLines > 0
        val levelText = levels.entries.joinToString("、") { (level, count) -> "$level${count}注" }
        val multiplierText = if (safeMultiplier > 1) " × ${safeMultiplier}倍" else ""
        val description = when {
            !isWinner -> "未中奖"
            dynamicLines > 0 && multipliedFixedPrize > 0 ->
                "$levelText$multiplierText；固定奖金 ¥${formatMoney(multipliedFixedPrize)}，浮动奖按倍数计算并以当期公告为准"
            dynamicLines > 0 ->
                "$levelText$multiplierText；浮动奖按倍数计算并以当期官方公告为准"
            else -> "$levelText$multiplierText；奖金 ¥${formatMoney(multipliedFixedPrize)}"
        }
        return PrizeResult(
            checked = true,
            isWinner = isWinner,
            fixedPrize = multipliedFixedPrize,
            dynamicWinningLines = dynamicLines,
            winningLines = winningLines,
            totalLines = totalLines,
            bestHitCount = bestHit,
            hitNumbers = hitNumbers,
            prizeLevel = levels.keys.firstOrNull(),
            description = description
        )
    }

    private fun formatMoney(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else "%.1f".format(value)
}

object NumberGenerator {
    fun randomNumbers(count: Int, excluded: Set<Int> = emptySet()): List<Int> =
        randomFromRange(1..80, count, excluded)

    fun randomFromRange(range: IntRange, count: Int, excluded: Set<Int> = emptySet()): List<Int> {
        require(count >= 0)
        val pool = range.filterNot { it in excluded }.shuffled()
        require(pool.size >= count)
        return pool.take(count).sorted()
    }

    fun randomDigits(play: DigitPlay): List<Int> = when (play) {
        DigitPlay.DIRECT -> List(3) { Random.nextInt(0, 10) }
        DigitPlay.GROUP3 -> {
            val repeated = Random.nextInt(0, 10)
            val other = (0..9).filter { it != repeated }.random()
            listOf(repeated, repeated, other).shuffled()
        }
        DigitPlay.GROUP6 -> (0..9).shuffled().take(3)
    }

    /**
     * 娱乐型“三角定位”：把1—80排成8行×10列，以上期首球和末球为定位点，
     * 每个定位点取自身与相邻一行的左、中、右三个号码。
     */
    fun triangleCandidates(drawNumbersInOrder: List<Int>, downward: Boolean = true): List<Int> {
        if (drawNumbersInOrder.isEmpty()) return emptyList()
        val anchors = listOf(drawNumbersInOrder.first(), drawNumbersInOrder.last()).distinct()
        val result = linkedSetOf<Int>()
        anchors.forEach { anchor ->
            result += anchor
            val zero = anchor - 1
            val row = zero / 10
            val col = zero % 10
            val targetRow = if (downward) row + 1 else row - 1
            val usableRow = if (targetRow in 0..7) targetRow else if (downward) row - 1 else row + 1
            if (usableRow in 0..7) {
                for (targetCol in (col - 1)..(col + 1)) {
                    if (targetCol in 0..9) result += usableRow * 10 + targetCol + 1
                }
            }
        }
        return result.toList()
    }

    fun completeToCount(seed: List<Int>, count: Int, range: IntRange = 1..80): List<Int> {
        val unique = seed.filter { it in range }.distinct().toMutableList()
        if (unique.size < count) unique += randomFromRange(range, count - unique.size, unique.toSet())
        return unique.take(count).sorted()
    }

    /**
     * 热冷号法：近15期取2个热号，排除极冷号，其余按分区、奇偶与活跃度补齐。
     * 这只是历史统计型娱乐工具，不改变理论开奖概率。
     */
    fun hotColdNumbers(draws: List<DrawResult>, count: Int): List<Int> {
        if (count <= 0) return emptyList()
        val stats = happy8Stats(draws)
        if (stats.drawCount == 0) return randomNumbers(count)
        val hotOrder = (1..80).sortedWith(
            compareByDescending<Int> { stats.frequency[it] }
                .thenBy { stats.lastSeen[it] }
                .thenBy { it }
        )
        val seed = mutableListOf<Int>()
        hotOrder.firstOrNull()?.let(seed::add)
        hotOrder.firstOrNull { candidate ->
            candidate !in seed && zone(candidate) != seed.firstOrNull()?.let(::zone)
        }?.let(seed::add)
        // 明确只固定2个“热号”；其余号码从温号池中按奇偶、分区和近期活跃度补齐。
        val otherHotNumbers = hotOrder.take(10).toSet() - seed.toSet()
        return balancedFill(seed, count, stats, forbidden = otherHotNumbers)
    }

    /**
     * 连号法：近15期只判断最活跃的两个十位区间；每个区间再挑一组相邻号码，
     * 具体连号不要求历史上曾经同时开出，最后用平衡号码补齐。
     */
    fun consecutiveNumbers(draws: List<DrawResult>, count: Int): List<Int> {
        if (count <= 0) return emptyList()
        val recent = draws.filter { it.game == LotteryGame.HAPPY8 }.take(15)
        if (recent.isEmpty()) return randomNumbers(count)
        val stats = happy8Stats(recent)
        val zoneScores = IntArray(8)
        val historicalPairs = mutableSetOf<Pair<Int, Int>>()
        recent.forEach { draw ->
            val sorted = draw.primaryNumbers.distinct().sorted()
            sorted.zipWithNext().forEach { (a, b) ->
                if (b == a + 1 && zone(a) == zone(b)) {
                    zoneScores[zone(a)]++
                    historicalPairs += a to b
                }
            }
        }
        val selectedZones = (0..7).sortedWith(
            compareByDescending<Int> { zoneScores[it] }.thenBy { it }
        ).take(2)
        val seed = mutableListOf<Int>()
        selectedZones.forEach { z ->
            val start = z * 10 + 1
            val bestPair = (start until start + 9).map { it to (it + 1) }.maxWithOrNull(
                compareBy<Pair<Int, Int>> {
                    val (a, b) = it
                    val unseenBonus = if (it !in historicalPairs) 3 else 0
                    stats.frequency[a] * 10 + stats.frequency[b] * 10 +
                        recencyScore(stats.lastSeen[a]) + recencyScore(stats.lastSeen[b]) + unseenBonus
                }.thenByDescending { -it.first }
            )
            if (bestPair != null) {
                seed += bestPair.first
                seed += bestPair.second
            }
        }
        return balancedFill(seed.distinct(), count, stats)
    }

    private data class Happy8Stats(
        val frequency: IntArray,
        val lastSeen: IntArray,
        val drawCount: Int
    )

    private fun happy8Stats(draws: List<DrawResult>): Happy8Stats {
        val recent = draws.filter { it.game == LotteryGame.HAPPY8 }.take(15)
        val frequency = IntArray(81)
        val lastSeen = IntArray(81) { 99 }
        recent.forEachIndexed { index, draw ->
            draw.primaryNumbers.distinct().forEach { number ->
                if (number in 1..80) {
                    frequency[number]++
                    lastSeen[number] = min(lastSeen[number], index)
                }
            }
        }
        return Happy8Stats(frequency, lastSeen, recent.size)
    }

    private fun balancedFill(
        seed: List<Int>,
        count: Int,
        stats: Happy8Stats,
        forbidden: Set<Int> = emptySet()
    ): List<Int> {
        val result = seed.filter { it in 1..80 }.distinct().take(count).toMutableList()
        while (result.size < count) {
            val oddCount = result.count { it % 2 == 1 }
            val evenCount = result.size - oddCount
            val zoneCounts = IntArray(8).also { counts -> result.forEach { counts[zone(it)]++ } }
            val candidate = (1..80)
                .asSequence()
                .filterNot { it in result || it in forbidden }
                .filterNot { stats.frequency[it] <= 1 && stats.lastSeen[it] >= 8 }
                .maxWithOrNull(
                    compareBy<Int> { number ->
                        val parityBonus = when {
                            oddCount > evenCount && number % 2 == 0 -> 8
                            evenCount > oddCount && number % 2 == 1 -> 8
                            else -> 0
                        }
                        stats.frequency[number] * 12 + recencyScore(stats.lastSeen[number]) +
                            parityBonus - zoneCounts[zone(number)] * 9
                    }.thenByDescending { -it }
                ) ?: (1..80).first { it !in result && it !in forbidden }
            result += candidate
        }
        return result.sorted()
    }

    private fun recencyScore(lastSeen: Int): Int = (10 - lastSeen.coerceAtMost(10)).coerceAtLeast(0)
    private fun zone(number: Int): Int = ((number - 1) / 10).coerceIn(0, 7)
}
