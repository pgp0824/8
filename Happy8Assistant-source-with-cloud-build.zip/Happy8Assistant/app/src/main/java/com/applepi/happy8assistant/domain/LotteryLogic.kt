package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.PrizeResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import kotlin.math.min
import kotlin.random.Random

sealed interface PrizeValue {
    data class Fixed(val amount: Double) : PrizeValue
    data class Dynamic(val maxAmount: Double) : PrizeValue
}

object Happy8Rules {
    const val NEW_RULE_START_ISSUE = 2025350

    private val oldRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.6)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(53.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(100.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(21.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(3000.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(10000.0), 6 to PrizeValue.Fixed(288.0), 5 to PrizeValue.Fixed(28.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(88.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Fixed(300000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(200.0), 6 to PrizeValue.Fixed(20.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(800.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    private val newRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.5)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(52.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(93.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(20.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(2880.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(8500.0), 6 to PrizeValue.Fixed(300.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(80.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Dynamic(250_000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(225.0), 6 to PrizeValue.Fixed(22.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(720.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    fun prizeFor(issue: String, playCount: Int, hitCount: Int): PrizeValue? {
        val issueNumber = issue.toIntOrNull() ?: Int.MAX_VALUE
        val table = if (issueNumber >= NEW_RULE_START_ISSUE) newRules else oldRules
        return table[playCount]?.get(hitCount)
    }
}

object LotteryMath {
    fun combinations(n: Int, k: Int): Long {
        if (k < 0 || n < 0 || k > n) return 0
        if (k == 0 || k == n) return 1
        val useK = min(k, n - k)
        var result = 1L
        for (i in 1..useK) {
            val numerator = n - useK + i
            if (result > Long.MAX_VALUE / numerator) return Long.MAX_VALUE
            result = result * numerator / i
        }
        return result
    }

    fun maxCompoundNumberCount(playCount: Int, maxLines: Long = 10_000): Int {
        require(playCount in 1..10)
        var best = playCount + 1
        for (count in (playCount + 1)..80) {
            if (combinations(count, playCount) > maxLines) break
            best = count
        }
        return best
    }

    fun defaultCompoundNumberCount(playCount: Int): Int =
        (playCount + 2).coerceAtMost(maxCompoundNumberCount(playCount))

    fun ticketLineCount(ticket: SavedTicket): Long = when (ticket.mode) {
        TicketMode.SINGLE -> 1
        TicketMode.COMPOUND -> combinations(ticket.numbers.size, ticket.playCount)
        TicketMode.DANTUO -> combinations(ticket.drags.size, ticket.playCount - ticket.bankers.size)
    }
}

object PrizeCalculator {
    fun calculate(ticket: SavedTicket, draw: DrawResult?): PrizeResult {
        if (draw == null || draw.issue != ticket.issue) {
            return PrizeResult(checked = false, isWinner = false, totalLines = LotteryMath.ticketLineCount(ticket))
        }

        val winningSet = draw.numbers.toSet()
        val allTicketNumbers = when (ticket.mode) {
            TicketMode.DANTUO -> ticket.bankers + ticket.drags
            else -> ticket.numbers
        }
        val hitNumbers = allTicketNumbers.filter { it in winningSet }.distinct().sorted()

        var fixedPrize = 0.0
        var dynamicLines = 0L
        var winningLines = 0L
        var bestHit = 0
        val totalLines = LotteryMath.ticketLineCount(ticket)

        fun addOutcome(hitCount: Int, lineCount: Long) {
            if (lineCount <= 0) return
            val prize = Happy8Rules.prizeFor(ticket.issue, ticket.playCount, hitCount) ?: return
            bestHit = maxOf(bestHit, hitCount)
            winningLines += lineCount
            when (prize) {
                is PrizeValue.Fixed -> fixedPrize += prize.amount * lineCount
                is PrizeValue.Dynamic -> dynamicLines += lineCount
            }
        }

        when (ticket.mode) {
            TicketMode.SINGLE -> {
                val hitCount = ticket.numbers.count { it in winningSet }
                addOutcome(hitCount, 1)
            }

            TicketMode.COMPOUND -> {
                val hits = ticket.numbers.count { it in winningSet }
                val misses = ticket.numbers.size - hits
                for (hitCount in 0..ticket.playCount) {
                    val lines = LotteryMath.combinations(hits, hitCount) *
                        LotteryMath.combinations(misses, ticket.playCount - hitCount)
                    addOutcome(hitCount, lines)
                }
            }

            TicketMode.DANTUO -> {
                val bankerHits = ticket.bankers.count { it in winningSet }
                val dragHits = ticket.drags.count { it in winningSet }
                val dragMisses = ticket.drags.size - dragHits
                val chosenFromDrag = ticket.playCount - ticket.bankers.size
                for (selectedHitDrags in 0..chosenFromDrag) {
                    val lines = LotteryMath.combinations(dragHits, selectedHitDrags) *
                        LotteryMath.combinations(dragMisses, chosenFromDrag - selectedHitDrags)
                    addOutcome(bankerHits + selectedHitDrags, lines)
                }
            }
        }

        val isWinner = winningLines > 0
        val description = when {
            !isWinner -> "未中奖"
            dynamicLines > 0 && fixedPrize > 0 -> "固定奖金已计算，另有${dynamicLines}注浮动奖，以官方公告为准"
            dynamicLines > 0 -> "中得${dynamicLines}注浮动奖，金额以官方公告为准"
            else -> "中奖 ¥${formatMoney(fixedPrize)}"
        }

        return PrizeResult(
            checked = true,
            isWinner = isWinner,
            fixedPrize = fixedPrize,
            dynamicWinningLines = dynamicLines,
            winningLines = winningLines,
            totalLines = totalLines,
            bestHitCount = bestHit,
            hitNumbers = hitNumbers,
            description = description
        )
    }

    private fun formatMoney(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else "%.1f".format(value)
}

object NumberGenerator {
    fun randomNumbers(count: Int, excluded: Set<Int> = emptySet()): List<Int> {
        require(count in 1..80)
        val pool = (1..80).filterNot { it in excluded }.shuffled()
        require(pool.size >= count)
        return pool.take(count).sorted()
    }

    /**
     * 娱乐型“三角定位”：把 1–80 排成 8 行 × 10 列，以上期首球和末球为定位点，
     * 每个定位点取自身与相邻一行的左、中、右三个号码，形成两个小三角。
     */
    fun triangleCandidates(drawNumbersInOrder: List<Int>, downward: Boolean = true): List<Int> {
        if (drawNumbersInOrder.isEmpty()) return emptyList()
        val anchors = listOf(drawNumbersInOrder.first(), drawNumbersInOrder.last()).distinct()
        val result = linkedSetOf<Int>()
        anchors.forEach { anchor ->
            result += anchor
            val zero = anchor - 1
            val row = zero / 10
            val col = zero % 10
            val targetRow = if (downward) row + 1 else row - 1
            if (targetRow in 0..7) {
                for (targetCol in (col - 1)..(col + 1)) {
                    if (targetCol in 0..9) result += targetRow * 10 + targetCol + 1
                }
            } else {
                val fallbackRow = if (downward) row - 1 else row + 1
                if (fallbackRow in 0..7) {
                    for (targetCol in (col - 1)..(col + 1)) {
                        if (targetCol in 0..9) result += fallbackRow * 10 + targetCol + 1
                    }
                }
            }
        }
        return result.toList()
    }

    fun completeToCount(seed: List<Int>, count: Int): List<Int> {
        val unique = seed.filter { it in 1..80 }.distinct().toMutableList()
        if (unique.size < count) {
            unique += randomNumbers(count - unique.size, unique.toSet())
        }
        return unique.take(count).sorted()
    }
}
