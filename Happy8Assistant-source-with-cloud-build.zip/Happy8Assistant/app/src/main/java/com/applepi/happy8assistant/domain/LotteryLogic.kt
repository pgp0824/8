package com.applepi.happy8assistant.domain

import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.GeneratedPick
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.PrizeResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

sealed interface PrizeValue {
    data class Fixed(val amount: Double) : PrizeValue
    data class Dynamic(val maxAmount: Double? = null) : PrizeValue
}

object Happy8Rules {
    const val NEW_RULE_START_ISSUE = 2025350

    private val oldRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.6)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(53.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(100.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(21.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(3000.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(10000.0), 6 to PrizeValue.Fixed(288.0), 5 to PrizeValue.Fixed(28.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(88.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Fixed(300000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(200.0), 6 to PrizeValue.Fixed(20.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(800.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    private val newRules: Map<Int, Map<Int, PrizeValue>> = mapOf(
        1 to mapOf(1 to PrizeValue.Fixed(4.5)),
        2 to mapOf(2 to PrizeValue.Fixed(19.0)),
        3 to mapOf(3 to PrizeValue.Fixed(52.0), 2 to PrizeValue.Fixed(3.0)),
        4 to mapOf(4 to PrizeValue.Fixed(93.0), 3 to PrizeValue.Fixed(5.0), 2 to PrizeValue.Fixed(3.0)),
        5 to mapOf(5 to PrizeValue.Fixed(1000.0), 4 to PrizeValue.Fixed(20.0), 3 to PrizeValue.Fixed(3.0)),
        6 to mapOf(6 to PrizeValue.Fixed(2880.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(10.0), 3 to PrizeValue.Fixed(3.0)),
        7 to mapOf(7 to PrizeValue.Fixed(8500.0), 6 to PrizeValue.Fixed(300.0), 5 to PrizeValue.Fixed(30.0), 4 to PrizeValue.Fixed(4.0), 0 to PrizeValue.Fixed(2.0)),
        8 to mapOf(8 to PrizeValue.Fixed(50000.0), 7 to PrizeValue.Fixed(800.0), 6 to PrizeValue.Fixed(80.0), 5 to PrizeValue.Fixed(10.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        9 to mapOf(9 to PrizeValue.Dynamic(250_000.0), 8 to PrizeValue.Fixed(2000.0), 7 to PrizeValue.Fixed(225.0), 6 to PrizeValue.Fixed(22.0), 5 to PrizeValue.Fixed(5.0), 4 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0)),
        10 to mapOf(10 to PrizeValue.Dynamic(5_000_000.0), 9 to PrizeValue.Fixed(8000.0), 8 to PrizeValue.Fixed(720.0), 7 to PrizeValue.Fixed(80.0), 6 to PrizeValue.Fixed(5.0), 5 to PrizeValue.Fixed(3.0), 0 to PrizeValue.Fixed(2.0))
    )

    fun prizeFor(issue: String, playCount: Int, hitCount: Int): PrizeValue? {
        val issueNumber = issue.toIntOrNull() ?: Int.MAX_VALUE
        val table = if (issueNumber >= NEW_RULE_START_ISSUE) newRules else oldRules
        return table[playCount]?.get(hitCount)
    }
}

object LotteryMath {
    fun combinations(n: Int, k: Int): Long {
        if (k < 0 || n < 0 || k > n) return 0
        if (k == 0 || k == n) return 1
        val useK = min(k, n - k)
        var result = 1L
        for (i in 1..useK) {
            val numerator = n - useK + i
            if (result > Long.MAX_VALUE / numerator) return Long.MAX_VALUE
            result = result * numerator / i
        }
        return result
    }

    fun maxCompoundNumberCount(playCount: Int, maxLines: Long = 10_000): Int {
        require(playCount in 1..10)
        var best = playCount + 1
        for (count in (playCount + 1)..80) {
            if (combinations(count, playCount) > maxLines) break
            best = count
        }
        return best
    }

    fun defaultCompoundNumberCount(playCount: Int): Int =
        (playCount + 2).coerceAtMost(maxCompoundNumberCount(playCount))

    fun ticketLineCount(ticket: SavedTicket): Long = when (ticket.game) {
        LotteryGame.HAPPY8 -> when (ticket.mode) {
            TicketMode.SINGLE -> 1
            TicketMode.COMPOUND -> combinations(ticket.primaryNumbers.size, ticket.playCount)
            TicketMode.DANTUO -> combinations(
                ticket.primaryDrags.size,
                ticket.playCount - ticket.primaryBankers.size
            )
        }

        LotteryGame.DOUBLE_COLOR_BALL ->
            combinations(ticket.primaryNumbers.size, 6) * ticket.secondaryNumbers.size

        LotteryGame.SUPER_LOTTO ->
            combinations(ticket.primaryNumbers.size, 5) * combinations(ticket.secondaryNumbers.size, 2)

        LotteryGame.FC3D, LotteryGame.PL3 -> 1
    }

    fun ticketCost(ticket: SavedTicket): Long {
        val baseCost = safeMultiply(ticketLineCount(ticket), 2L)
        return safeMultiply(baseCost, ticket.multiplier.coerceIn(1, 99).toLong())
    }

    private fun safeMultiply(left: Long, right: Long): Long {
        if (left == 0L || right == 0L) return 0L
        return if (left > Long.MAX_VALUE / right) Long.MAX_VALUE else left * right
    }
}

object PrizeCalculator {
    fun calculate(ticket: SavedTicket, draw: DrawResult?): PrizeResult {
        if (draw == null || draw.game != ticket.game || draw.issue != ticket.issue) {
            return PrizeResult(
                checked = false,
                isWinner = false,
                totalLines = LotteryMath.ticketLineCount(ticket)
            )
        }
        return when (ticket.game) {
            LotteryGame.HAPPY8 -> calculateHappy8(ticket, draw)
            LotteryGame.DOUBLE_COLOR_BALL -> calculateDoubleColorBall(ticket, draw)
            LotteryGame.SUPER_LOTTO -> calculateSuperLotto(ticket, draw)
            LotteryGame.FC3D, LotteryGame.PL3 -> calculateDigitLottery(ticket, draw)
        }
    }

    private fun calculateHappy8(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningSet = draw.primaryNumbers.toSet()
        val allTicketNumbers = when (ticket.mode) {
            TicketMode.DANTUO -> ticket.primaryBankers + ticket.primaryDrags
            else -> ticket.primaryNumbers
        }
        val hitNumbers = allTicketNumbers.filter { it in winningSet }.distinct().sorted()
        var fixedPrize = 0.0
        var dynamicLines = 0L
        var winningLines = 0L
        var bestHit = 0
        val totalLines = LotteryMath.ticketLineCount(ticket)

        fun addOutcome(hitCount: Int, lineCount: Long) {
            if (lineCount <= 0) return
            val prize = Happy8Rules.prizeFor(ticket.issue, ticket.playCount, hitCount) ?: return
            bestHit = maxOf(bestHit, hitCount)
            winningLines += lineCount
            when (prize) {
                is PrizeValue.Fixed -> fixedPrize += prize.amount * lineCount
                is PrizeValue.Dynamic -> dynamicLines += lineCount
            }
        }

        when (ticket.mode) {
            TicketMode.SINGLE -> addOutcome(ticket.primaryNumbers.count { it in winningSet }, 1)
            TicketMode.COMPOUND -> {
                val hits = ticket.primaryNumbers.count { it in winningSet }
                val misses = ticket.primaryNumbers.size - hits
                for (hitCount in 0..ticket.playCount) {
                    addOutcome(
                        hitCount,
                        LotteryMath.combinations(hits, hitCount) *
                            LotteryMath.combinations(misses, ticket.playCount - hitCount)
                    )
                }
            }
            TicketMode.DANTUO -> {
                val bankerHits = ticket.primaryBankers.count { it in winningSet }
                val dragHits = ticket.primaryDrags.count { it in winningSet }
                val dragMisses = ticket.primaryDrags.size - dragHits
                val chosenFromDrag = ticket.playCount - ticket.primaryBankers.size
                for (selectedHitDrags in 0..chosenFromDrag) {
                    addOutcome(
                        bankerHits + selectedHitDrags,
                        LotteryMath.combinations(dragHits, selectedHitDrags) *
                            LotteryMath.combinations(dragMisses, chosenFromDrag - selectedHitDrags)
                    )
                }
            }
        }

        return buildPrizeResult(
            totalLines = totalLines,
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = bestHit,
            hitNumbers = hitNumbers,
            levels = if (winningLines > 0) linkedMapOf("快乐8中奖" to winningLines) else linkedMapOf(),
            multiplier = ticket.multiplier
        )
    }

    private fun calculateDoubleColorBall(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningReds = draw.primaryNumbers.toSet()
        val winningBlue = draw.secondaryNumbers.firstOrNull()
        val redHits = ticket.primaryNumbers.count { it in winningReds }
        val redMisses = ticket.primaryNumbers.size - redHits
        val blueHitLines = if (winningBlue != null && winningBlue in ticket.secondaryNumbers) 1 else 0
        val blueMissLines = ticket.secondaryNumbers.size - blueHitLines
        val levels = linkedMapOf<String, Long>()
        var fixedPrize = 0.0
        var dynamicLines = 0L

        fun add(redHit: Int, blueHit: Int, lines: Long) {
            if (lines <= 0) return
            val award = ssqAward(redHit, blueHit) ?: return
            levels[award.first] = levels.getOrDefault(award.first, 0) + lines
            when (val value = award.second) {
                is PrizeValue.Fixed -> fixedPrize += value.amount * lines
                is PrizeValue.Dynamic -> dynamicLines += lines
            }
        }

        for (hit in 0..6) {
            val redLines = LotteryMath.combinations(redHits, hit) *
                LotteryMath.combinations(redMisses, 6 - hit)
            add(hit, 1, redLines * blueHitLines)
            add(hit, 0, redLines * blueMissLines)
        }
        val winningLines = levels.values.sum()
        return buildPrizeResult(
            totalLines = LotteryMath.ticketLineCount(ticket),
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = redHits + blueHitLines,
            hitNumbers = ticket.primaryNumbers.filter { it in winningReds }.sorted(),
            levels = levels,
            multiplier = ticket.multiplier
        )
    }

    private fun ssqAward(redHit: Int, blueHit: Int): Pair<String, PrizeValue>? = when {
        redHit == 6 && blueHit == 1 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
        redHit == 6 -> "二等奖" to PrizeValue.Dynamic()
        redHit == 5 && blueHit == 1 -> "三等奖" to PrizeValue.Fixed(3000.0)
        redHit == 5 || (redHit == 4 && blueHit == 1) -> "四等奖" to PrizeValue.Fixed(200.0)
        redHit == 4 || (redHit == 3 && blueHit == 1) -> "五等奖" to PrizeValue.Fixed(10.0)
        blueHit == 1 && redHit in 0..2 -> "六等奖" to PrizeValue.Fixed(5.0)
        else -> null
    }

    private fun calculateSuperLotto(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val winningFront = draw.primaryNumbers.toSet()
        val winningBack = draw.secondaryNumbers.toSet()
        val frontHits = ticket.primaryNumbers.count { it in winningFront }
        val frontMisses = ticket.primaryNumbers.size - frontHits
        val backHits = ticket.secondaryNumbers.count { it in winningBack }
        val backMisses = ticket.secondaryNumbers.size - backHits
        val levels = linkedMapOf<String, Long>()
        var fixedPrize = 0.0
        var dynamicLines = 0L

        for (frontHit in 0..5) {
            val frontLines = LotteryMath.combinations(frontHits, frontHit) *
                LotteryMath.combinations(frontMisses, 5 - frontHit)
            for (backHit in 0..2) {
                val lines = frontLines * LotteryMath.combinations(backHits, backHit) *
                    LotteryMath.combinations(backMisses, 2 - backHit)
                if (lines <= 0) continue
                val award = dltAward(ticket.issue, frontHit, backHit, draw.jackpot) ?: continue
                levels[award.first] = levels.getOrDefault(award.first, 0) + lines
                when (val value = award.second) {
                    is PrizeValue.Fixed -> fixedPrize += value.amount * lines
                    is PrizeValue.Dynamic -> dynamicLines += lines
                }
            }
        }
        val winningLines = levels.values.sum()
        return buildPrizeResult(
            totalLines = LotteryMath.ticketLineCount(ticket),
            fixedPrize = fixedPrize,
            dynamicLines = dynamicLines,
            winningLines = winningLines,
            bestHit = frontHits + backHits,
            hitNumbers = ticket.primaryNumbers.filter { it in winningFront }.sorted(),
            levels = levels,
            multiplier = ticket.multiplier
        )
    }

    private fun dltAward(
        issue: String,
        frontHit: Int,
        backHit: Int,
        jackpot: Long?
    ): Pair<String, PrizeValue>? {
        val numericIssue = issue.filter(Char::isDigit).takeLast(5).toIntOrNull() ?: Int.MAX_VALUE
        val isNewRule = numericIssue >= 26014
        if (!isNewRule) {
            return when {
                frontHit == 5 && backHit == 2 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
                frontHit == 5 && backHit == 1 -> "二等奖" to PrizeValue.Dynamic()
                frontHit == 5 -> "三等奖" to PrizeValue.Fixed(10_000.0)
                frontHit == 4 && backHit == 2 -> "四等奖" to PrizeValue.Fixed(3000.0)
                frontHit == 4 && backHit == 1 -> "五等奖" to PrizeValue.Fixed(300.0)
                frontHit == 3 && backHit == 2 -> "六等奖" to PrizeValue.Fixed(200.0)
                frontHit == 4 -> "七等奖" to PrizeValue.Fixed(100.0)
                (frontHit == 3 && backHit == 1) || (frontHit == 2 && backHit == 2) ->
                    "八等奖" to PrizeValue.Fixed(15.0)
                frontHit == 3 || (frontHit == 2 && backHit == 1) ||
                    (frontHit == 1 && backHit == 2) || backHit == 2 ->
                    "九等奖" to PrizeValue.Fixed(5.0)
                else -> null
            }
        }

        val upgraded = jackpot != null && jackpot >= 800_000_000L
        val level3 = if (upgraded) 6666.0 else 5000.0
        val level4 = if (upgraded) 380.0 else 300.0
        val level5 = if (upgraded) 200.0 else 150.0
        val level6 = if (upgraded) 18.0 else 15.0
        val level7 = if (upgraded) 7.0 else 5.0
        return when {
            frontHit == 5 && backHit == 2 -> "一等奖" to PrizeValue.Dynamic(10_000_000.0)
            frontHit == 5 && backHit == 1 -> "二等奖" to PrizeValue.Dynamic()
            frontHit == 5 || (frontHit == 4 && backHit == 2) -> "三等奖" to PrizeValue.Fixed(level3)
            frontHit == 4 && backHit == 1 -> "四等奖" to PrizeValue.Fixed(level4)
            frontHit == 4 || (frontHit == 3 && backHit == 2) -> "五等奖" to PrizeValue.Fixed(level5)
            (frontHit == 3 && backHit == 1) || (frontHit == 2 && backHit == 2) ->
                "六等奖" to PrizeValue.Fixed(level6)
            frontHit == 3 || (frontHit == 2 && backHit == 1) ||
                (frontHit == 1 && backHit == 2) || backHit == 2 ->
                "七等奖" to PrizeValue.Fixed(level7)
            else -> null
        }
    }

    private fun calculateDigitLottery(ticket: SavedTicket, draw: DrawResult): PrizeResult {
        val drawDigits = draw.primaryNumbers.take(3)
        val ticketDigits = ticket.digits.take(3)
        val play = ticket.digitPlay ?: DigitPlay.DIRECT
        val isWinner = when (play) {
            DigitPlay.DIRECT -> ticketDigits == drawDigits
            DigitPlay.GROUP3 ->
                drawDigits.distinct().size == 2 && ticketDigits.sorted() == drawDigits.sorted()
            DigitPlay.GROUP6 ->
                drawDigits.distinct().size == 3 && ticketDigits.sorted() == drawDigits.sorted()
        }
        val singleAmount = when (play) {
            DigitPlay.DIRECT -> 1040.0
            DigitPlay.GROUP3 -> 346.0
            DigitPlay.GROUP6 -> 173.0
        }
        val multiplier = ticket.multiplier.coerceIn(1, 99)
        val amount = singleAmount * multiplier
        return if (isWinner) {
            PrizeResult(
                checked = true,
                isWinner = true,
                fixedPrize = amount,
                winningLines = 1,
                totalLines = 1,
                bestHitCount = 3,
                hitNumbers = drawDigits,
                prizeLevel = play.label,
                description = "中得${play.label}，${multiplier}倍，奖金 ¥${formatMoney(amount)}"
            )
        } else {
            PrizeResult(
                checked = true,
                isWinner = false,
                totalLines = 1,
                bestHitCount = ticketDigits.zip(drawDigits).count { it.first == it.second },
                description = "未中奖"
            )
        }
    }

    private fun buildPrizeResult(
        totalLines: Long,
        fixedPrize: Double,
        dynamicLines: Long,
        winningLines: Long,
        bestHit: Int,
        hitNumbers: List<Int>,
        levels: LinkedHashMap<String, Long>,
        multiplier: Int
    ): PrizeResult {
        val safeMultiplier = multiplier.coerceIn(1, 99)
        val multipliedFixedPrize = fixedPrize * safeMultiplier
        val isWinner = winningLines > 0
        val levelText = levels.entries.joinToString("、") { (level, count) -> "$level${count}注" }
        val multiplierText = if (safeMultiplier > 1) " × ${safeMultiplier}倍" else ""
        val description = when {
            !isWinner -> "未中奖"
            dynamicLines > 0 && multipliedFixedPrize > 0 ->
                "$levelText$multiplierText；固定奖金 ¥${formatMoney(multipliedFixedPrize)}，浮动奖按倍数计算并以当期公告为准"
            dynamicLines > 0 ->
                "$levelText$multiplierText；浮动奖按倍数计算并以当期官方公告为准"
            else -> "$levelText$multiplierText；奖金 ¥${formatMoney(multipliedFixedPrize)}"
        }
        return PrizeResult(
            checked = true,
            isWinner = isWinner,
            fixedPrize = multipliedFixedPrize,
            dynamicWinningLines = dynamicLines,
            winningLines = winningLines,
            totalLines = totalLines,
            bestHitCount = bestHit,
            hitNumbers = hitNumbers,
            prizeLevel = levels.keys.firstOrNull(),
            description = description
        )
    }

    private fun formatMoney(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else "%.1f".format(value)
}

object NumberGenerator {
    fun randomNumbers(count: Int, excluded: Set<Int> = emptySet()): List<Int> =
        randomFromRange(1..80, count, excluded)

    fun randomFromRange(range: IntRange, count: Int, excluded: Set<Int> = emptySet()): List<Int> {
        require(count >= 0)
        val pool = range.filterNot { it in excluded }.shuffled()
        require(pool.size >= count)
        return pool.take(count).sorted()
    }

    fun randomDigits(play: DigitPlay): List<Int> = when (play) {
        DigitPlay.DIRECT -> List(3) { Random.nextInt(0, 10) }
        DigitPlay.GROUP3 -> {
            val repeated = Random.nextInt(0, 10)
            val other = (0..9).filter { it != repeated }.random()
            listOf(repeated, repeated, other).shuffled()
        }
        DigitPlay.GROUP6 -> (0..9).shuffled().take(3)
    }

    fun randomPick(
        game: LotteryGame,
        playCount: Int,
        mode: TicketMode,
        targetPrimaryCount: Int,
        targetSecondaryCount: Int,
        digitPlay: DigitPlay
    ): GeneratedPick = when (game) {
        LotteryGame.HAPPY8 -> when (mode) {
            TicketMode.SINGLE, TicketMode.COMPOUND -> GeneratedPick(
                primaryNumbers = randomNumbers(targetPrimaryCount)
            )
            TicketMode.DANTUO -> {
                val bankerCount = happy8BankerCount(playCount)
                val dragCount = happy8DragCount(playCount, bankerCount)
                val all = randomNumbers(bankerCount + dragCount).shuffled()
                GeneratedPick(
                    primaryBankers = all.take(bankerCount).sorted(),
                    primaryDrags = all.drop(bankerCount).sorted()
                )
            }
        }
        LotteryGame.DOUBLE_COLOR_BALL -> GeneratedPick(
            primaryNumbers = randomFromRange(1..33, targetPrimaryCount),
            secondaryNumbers = randomFromRange(1..16, targetSecondaryCount)
        )
        LotteryGame.SUPER_LOTTO -> GeneratedPick(
            primaryNumbers = randomFromRange(1..35, targetPrimaryCount),
            secondaryNumbers = randomFromRange(1..12, targetSecondaryCount)
        )
        LotteryGame.FC3D, LotteryGame.PL3 -> GeneratedPick(digits = randomDigits(digitPlay))
    }

    /**
     * 软控均衡法：先均匀随机生成大量候选，再用宽松的奇偶、大小、区间和重叠评分
     * 从高分候选中随机抽取。评分是偏好而不是硬限制，因此每次点击都会重新随机。
     */
    fun softBalancedPicks(
        game: LotteryGame,
        playCount: Int,
        mode: TicketMode,
        targetPrimaryCount: Int,
        targetSecondaryCount: Int,
        digitPlay: DigitPlay,
        batchSize: Int,
        avoidPicks: List<GeneratedPick> = emptyList()
    ): List<GeneratedPick> {
        require(batchSize in 1..5)
        val results = mutableListOf<GeneratedPick>()
        val blocked = avoidPicks.map { pickSignature(game, digitPlay, it) }.toMutableSet()
        var attempts = 0
        while (results.size < batchSize && attempts < 800) {
            attempts++
            val pick = softBalancedPick(
                game = game,
                playCount = playCount,
                mode = mode,
                targetPrimaryCount = targetPrimaryCount,
                targetSecondaryCount = targetSecondaryCount,
                digitPlay = digitPlay,
                previousPicks = results
            )
            val signature = pickSignature(game, digitPlay, pick)
            if (signature !in blocked) {
                results += pick
                blocked += signature
            }
        }
        // 极小号码空间或连续重复时，放宽“避开上一批”，但仍保证本批不重复。
        while (results.size < batchSize && attempts < 1600) {
            attempts++
            val pick = softBalancedPick(
                game = game,
                playCount = playCount,
                mode = mode,
                targetPrimaryCount = targetPrimaryCount,
                targetSecondaryCount = targetSecondaryCount,
                digitPlay = digitPlay,
                previousPicks = results
            )
            val signature = pickSignature(game, digitPlay, pick)
            if (results.none { pickSignature(game, digitPlay, it) == signature }) results += pick
        }
        return results
    }

    fun pickSignature(game: LotteryGame, digitPlay: DigitPlay, pick: GeneratedPick): String = when (game) {
        LotteryGame.HAPPY8 -> if (pick.primaryBankers.isNotEmpty() || pick.primaryDrags.isNotEmpty()) {
            "B:${pick.primaryBankers.sorted().joinToString(",")}|D:${pick.primaryDrags.sorted().joinToString(",")}"
        } else {
            pick.primaryNumbers.sorted().joinToString(",")
        }
        LotteryGame.DOUBLE_COLOR_BALL, LotteryGame.SUPER_LOTTO ->
            "P:${pick.primaryNumbers.sorted().joinToString(",")}|S:${pick.secondaryNumbers.sorted().joinToString(",")}"
        LotteryGame.FC3D, LotteryGame.PL3 -> {
            val digits = if (digitPlay == DigitPlay.DIRECT) pick.digits else pick.digits.sorted()
            digits.joinToString("")
        }
    }

    /**
     * 娱乐型“三角定位”：把1—80排成8行×10列，以上期首球和末球为定位点，
     * 每个定位点取自身与相邻一行的左、中、右三个号码。
     */
    fun triangleCandidates(drawNumbersInOrder: List<Int>, downward: Boolean = true): List<Int> {
        if (drawNumbersInOrder.isEmpty()) return emptyList()
        val anchors = listOf(drawNumbersInOrder.first(), drawNumbersInOrder.last()).distinct()
        val result = linkedSetOf<Int>()
        anchors.forEach { anchor ->
            result += anchor
            val zero = anchor - 1
            val row = zero / 10
            val col = zero % 10
            val targetRow = if (downward) row + 1 else row - 1
            val usableRow = if (targetRow in 0..7) targetRow else if (downward) row - 1 else row + 1
            if (usableRow in 0..7) {
                for (targetCol in (col - 1)..(col + 1)) {
                    if (targetCol in 0..9) result += usableRow * 10 + targetCol + 1
                }
            }
        }
        return result.toList()
    }

    fun triangleNumbers(
        drawNumbersInOrder: List<Int>,
        count: Int,
        downward: Boolean = true
    ): List<Int> {
        val candidates = triangleCandidates(drawNumbersInOrder, downward).distinct().shuffled()
        if (count <= 0) return emptyList()
        val maxCandidateUse = minOf(count, candidates.size)
        val candidateUse = when {
            maxCandidateUse <= 1 -> maxCandidateUse
            candidates.size >= count && count >= 3 -> count - 1
            else -> maxCandidateUse
        }
        return completeToCount(candidates.take(candidateUse), count)
    }

    fun completeToCount(seed: List<Int>, count: Int, range: IntRange = 1..80): List<Int> {
        val unique = seed.filter { it in range }.distinct().shuffled().take(count).toMutableList()
        if (unique.size < count) unique += randomFromRange(range, count - unique.size, unique.toSet())
        return unique.sorted()
    }

    /**
     * 热冷号法：近15期的热号池中随机取2个热号，排除极冷号，其余按分区、
     * 奇偶与活跃度随机加权补齐。每次点击都会重新抽取，不固定同一组号码。
     */
    fun hotColdNumbers(draws: List<DrawResult>, count: Int): List<Int> {
        if (count <= 0) return emptyList()
        val stats = happy8Stats(draws)
        if (stats.drawCount == 0) return randomNumbers(count)
        val hotOrder = (1..80).sortedWith(
            compareByDescending<Int> { stats.frequency[it] }
                .thenBy { stats.lastSeen[it] }
                .thenBy { it }
        )
        val hotPool = hotOrder.take(10.coerceAtMost(hotOrder.size))
        val firstHot = weightedRandom(hotPool) { number ->
            1.0 + stats.frequency[number] * 2.0 + recencyScore(stats.lastSeen[number]) * 0.4
        }
        val secondPool = hotPool.filter { it != firstHot }
        val differentZonePool = secondPool.filter { zone(it) != zone(firstHot) }
        val secondHot = weightedRandom(
            if (differentZonePool.isNotEmpty()) differentZonePool else secondPool
        ) { number ->
            1.0 + stats.frequency[number] * 2.0 + recencyScore(stats.lastSeen[number]) * 0.4
        }
        val seed = listOf(firstHot, secondHot).distinct().take(count)
        val otherHotNumbers = hotPool.toSet() - seed.toSet()
        return balancedFill(seed, count, stats, forbidden = otherHotNumbers)
    }

    /**
     * 连号法：近15期只判断最活跃的两个十位区间；每个区间再随机加权挑一组
     * 相邻号码，具体连号不要求历史上曾经同时开出，最后用平衡号码补齐。
     */
    fun consecutiveNumbers(draws: List<DrawResult>, count: Int): List<Int> {
        if (count <= 0) return emptyList()
        val recent = draws.filter { it.game == LotteryGame.HAPPY8 }.take(15)
        if (recent.isEmpty()) return randomNumbers(count)
        val stats = happy8Stats(recent)
        val zoneScores = IntArray(8)
        val historicalPairs = mutableSetOf<Pair<Int, Int>>()
        recent.forEach { draw ->
            val sorted = draw.primaryNumbers.distinct().sorted()
            sorted.zipWithNext().forEach { (a, b) ->
                if (b == a + 1 && zone(a) == zone(b)) {
                    zoneScores[zone(a)]++
                    historicalPairs += a to b
                }
            }
        }
        val zoneRanking = (0..7).shuffled().sortedByDescending { zoneScores[it] }
        val selectedZones = zoneRanking.take(2)
        val seed = mutableListOf<Int>()
        selectedZones.forEach { z ->
            val start = z * 10 + 1
            val pairs = (start until start + 9).map { it to (it + 1) }
            val pair = weightedRandom(pairs) { (a, b) ->
                val unseenBonus = if ((a to b) !in historicalPairs) 3.0 else 0.0
                1.0 + stats.frequency[a] * 1.8 + stats.frequency[b] * 1.8 +
                    recencyScore(stats.lastSeen[a]) * 0.35 +
                    recencyScore(stats.lastSeen[b]) * 0.35 + unseenBonus
            }
            seed += pair.first
            seed += pair.second
        }
        return balancedFill(seed.distinct(), count, stats)
    }

    private fun softBalancedPick(
        game: LotteryGame,
        playCount: Int,
        mode: TicketMode,
        targetPrimaryCount: Int,
        targetSecondaryCount: Int,
        digitPlay: DigitPlay,
        previousPicks: List<GeneratedPick>
    ): GeneratedPick = when (game) {
        LotteryGame.HAPPY8 -> when (mode) {
            TicketMode.SINGLE, TicketMode.COMPOUND -> GeneratedPick(
                primaryNumbers = softBalancedNumbers(
                    range = 1..80,
                    count = targetPrimaryCount,
                    previousSelections = previousPicks.map { it.primaryNumbers }
                )
            )
            TicketMode.DANTUO -> {
                val bankerCount = happy8BankerCount(playCount)
                val dragCount = happy8DragCount(playCount, bankerCount)
                val combined = softBalancedNumbers(
                    range = 1..80,
                    count = bankerCount + dragCount,
                    previousSelections = previousPicks.map { it.primaryBankers + it.primaryDrags }
                ).shuffled()
                GeneratedPick(
                    primaryBankers = combined.take(bankerCount).sorted(),
                    primaryDrags = combined.drop(bankerCount).sorted()
                )
            }
        }
        LotteryGame.DOUBLE_COLOR_BALL -> GeneratedPick(
            primaryNumbers = softBalancedNumbers(
                1..33,
                targetPrimaryCount,
                previousPicks.map { it.primaryNumbers }
            ),
            secondaryNumbers = softBalancedNumbers(
                1..16,
                targetSecondaryCount,
                previousPicks.map { it.secondaryNumbers }
            )
        )
        LotteryGame.SUPER_LOTTO -> GeneratedPick(
            primaryNumbers = softBalancedNumbers(
                1..35,
                targetPrimaryCount,
                previousPicks.map { it.primaryNumbers }
            ),
            secondaryNumbers = softBalancedNumbers(
                1..12,
                targetSecondaryCount,
                previousPicks.map { it.secondaryNumbers }
            )
        )
        LotteryGame.FC3D, LotteryGame.PL3 -> GeneratedPick(
            digits = softBalancedDigits(digitPlay, previousPicks.map { it.digits })
        )
    }

    private fun softBalancedNumbers(
        range: IntRange,
        count: Int,
        previousSelections: List<List<Int>> = emptyList()
    ): List<Int> {
        if (count <= 0) return emptyList()
        val candidateCount = if (count <= 3) 180 else 260
        val candidates = LinkedHashMap<String, Pair<List<Int>, Double>>()
        repeat(candidateCount) {
            val candidate = randomFromRange(range, count)
            val key = candidate.joinToString(",")
            val score = balancedScore(candidate, range, previousSelections)
            val existing = candidates[key]
            if (existing == null || score > existing.second) candidates[key] = candidate to score
        }
        val ranked = candidates.values.sortedByDescending { it.second }
        val broad = Random.nextDouble() < 0.16
        val topCount = minOf(if (broad) 40 else 12, ranked.size).coerceAtLeast(1)
        return weightedRandom(ranked.take(topCount)) { (_, score) ->
            val floor = ranked.take(topCount).last().second
            (score - floor + 1.0).coerceAtLeast(0.1)
        }.first
    }

    private fun balancedScore(
        numbers: List<Int>,
        range: IntRange,
        previousSelections: List<List<Int>>
    ): Double {
        if (numbers.isEmpty()) return 0.0
        val sorted = numbers.sorted()
        val count = sorted.size
        var score = 0.0

        val odd = sorted.count { it % 2 == 1 }
        val even = count - odd
        val idealDifference = count % 2
        score -= abs(abs(odd - even) - idealDifference) * 7.0

        val midpoint = (range.first + range.last) / 2.0
        val low = sorted.count { it <= midpoint }
        val high = count - low
        score -= abs(abs(low - high) - idealDifference) * 6.0

        val rangeSize = range.last - range.first + 1
        val zoneCount = minOf(4, rangeSize)
        val zones = sorted.map { number ->
            (((number - range.first) * zoneCount) / rangeSize).coerceIn(0, zoneCount - 1)
        }.distinct().size
        val desiredZones = minOf(count, zoneCount)
        score -= (desiredZones - zones).coerceAtLeast(0) * 4.5

        val consecutivePairs = sorted.zipWithNext().count { (a, b) -> b == a + 1 }
        score += if (consecutivePairs <= 1) 1.5 else -(consecutivePairs - 1) * 3.5

        val maxSameTail = sorted.groupingBy { it % 10 }.eachCount().values.maxOrNull() ?: 1
        score -= (maxSameTail - 2).coerceAtLeast(0) * 4.0

        if (count > 1 && rangeSize > 1) {
            score += (sorted.last() - sorted.first()).toDouble() / (rangeSize - 1) * 4.0
        }

        val usage = previousSelections.flatten().groupingBy { it }.eachCount()
        score -= sorted.sumOf { usage[it]?.toDouble() ?: 0.0 } * 2.8
        val maxOverlap = previousSelections.maxOfOrNull { previous ->
            sorted.toSet().intersect(previous.toSet()).size
        } ?: 0
        score -= maxOverlap * 3.8

        // 小幅随机扰动确保相同结构下不会总是返回同一组。
        return score + Random.nextDouble(-1.2, 1.2)
    }

    private fun softBalancedDigits(
        play: DigitPlay,
        previousSelections: List<List<Int>>
    ): List<Int> {
        val candidates = LinkedHashMap<String, Pair<List<Int>, Double>>()
        repeat(220) {
            val digits = randomDigits(play)
            val signature = if (play == DigitPlay.DIRECT) digits.joinToString("")
            else digits.sorted().joinToString("")
            val odd = digits.count { it % 2 == 1 }
            val low = digits.count { it <= 4 }
            val idealDifference = 1
            var score = 0.0
            score -= abs(abs(odd - (3 - odd)) - idealDifference) * 5.5
            score -= abs(abs(low - (3 - low)) - idealDifference) * 5.0
            score -= abs(digits.sum() - 13.5) * 0.22
            score += (digits.maxOrNull()!! - digits.minOrNull()!!) * 0.35
            val normalized = if (play == DigitPlay.DIRECT) digits else digits.sorted()
            val usage = previousSelections.flatten().groupingBy { it }.eachCount()
            score -= digits.sumOf { usage[it]?.toDouble() ?: 0.0 } * 1.2
            score -= previousSelections.count { previous ->
                val p = if (play == DigitPlay.DIRECT) previous else previous.sorted()
                p == normalized
            } * 20.0
            score += Random.nextDouble(-1.0, 1.0)
            val existing = candidates[signature]
            if (existing == null || score > existing.second) candidates[signature] = digits to score
        }
        val ranked = candidates.values.sortedByDescending { it.second }
        val topCount = minOf(if (Random.nextDouble() < 0.18) 30 else 10, ranked.size).coerceAtLeast(1)
        return weightedRandom(ranked.take(topCount)) { (_, score) ->
            val floor = ranked.take(topCount).last().second
            (score - floor + 1.0).coerceAtLeast(0.1)
        }.first
    }

    private data class Happy8Stats(
        val frequency: IntArray,
        val lastSeen: IntArray,
        val drawCount: Int
    )

    private fun happy8Stats(draws: List<DrawResult>): Happy8Stats {
        val recent = draws.filter { it.game == LotteryGame.HAPPY8 }.take(15)
        val frequency = IntArray(81)
        val lastSeen = IntArray(81) { 99 }
        recent.forEachIndexed { index, draw ->
            draw.primaryNumbers.distinct().forEach { number ->
                if (number in 1..80) {
                    frequency[number]++
                    lastSeen[number] = min(lastSeen[number], index)
                }
            }
        }
        return Happy8Stats(frequency, lastSeen, recent.size)
    }

    private fun balancedFill(
        seed: List<Int>,
        count: Int,
        stats: Happy8Stats,
        forbidden: Set<Int> = emptySet()
    ): List<Int> {
        val result = seed.filter { it in 1..80 }.distinct().take(count).toMutableList()
        while (result.size < count) {
            val oddCount = result.count { it % 2 == 1 }
            val evenCount = result.size - oddCount
            val zoneCounts = IntArray(8).also { counts -> result.forEach { counts[zone(it)]++ } }
            val candidates = (1..80)
                .asSequence()
                .filterNot { it in result || it in forbidden }
                .filterNot { stats.frequency[it] <= 1 && stats.lastSeen[it] >= 8 }
                .map { number ->
                    val parityBonus = when {
                        oddCount > evenCount && number % 2 == 0 -> 8.0
                        evenCount > oddCount && number % 2 == 1 -> 8.0
                        else -> 0.0
                    }
                    val score = stats.frequency[number] * 12.0 +
                        recencyScore(stats.lastSeen[number]) + parityBonus -
                        zoneCounts[zone(number)] * 9.0 + Random.nextDouble(-4.0, 4.0)
                    number to score
                }
                .sortedByDescending { it.second }
                .take(12)
                .toList()
            val candidate = if (candidates.isNotEmpty()) {
                weightedRandom(candidates) { (_, score) ->
                    val floor = candidates.last().second
                    (score - floor + 1.0).coerceAtLeast(0.1)
                }.first
            } else {
                (1..80).filterNot { it in result || it in forbidden }.random()
            }
            result += candidate
        }
        return result.sorted()
    }

    private fun happy8BankerCount(playCount: Int): Int =
        (playCount - 2).coerceAtLeast(1).coerceAtMost((playCount - 1).coerceAtLeast(1))

    private fun happy8DragCount(playCount: Int, bankerCount: Int): Int =
        (playCount - bankerCount + 2).coerceAtLeast(3)

    private fun <T> weightedRandom(items: List<T>, weight: (T) -> Double): T {
        require(items.isNotEmpty())
        val weights = items.map { weight(it).coerceAtLeast(0.001) }
        val total = weights.sum()
        var cursor = Random.nextDouble() * total
        items.forEachIndexed { index, item ->
            cursor -= weights[index]
            if (cursor <= 0.0) return item
        }
        return items.last()
    }

    private fun recencyScore(lastSeen: Int): Int = (10 - lastSeen.coerceAtMost(10)).coerceAtLeast(0)
    private fun zone(number: Int): Int = ((number - 1) / 10).coerceIn(0, 7)
}
