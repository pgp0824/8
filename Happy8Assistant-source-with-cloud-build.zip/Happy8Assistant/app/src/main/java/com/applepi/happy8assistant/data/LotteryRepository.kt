package com.applepi.happy8assistant.data

import android.content.Context
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OfficialDrawApi {
    private const val BASE_ENDPOINT =
        "https://www.cwl.gov.cn/cwl_admin/front/cwlkj/search/kjxx/findDrawNotice"

    fun fetchLatest(): List<DrawResult> = fetchPage(pageNo = 1, pageSize = 50)

    fun fetchAllHistory(maxPages: Int = 80): List<DrawResult> {
        val all = mutableListOf<DrawResult>()
        val seenIssues = mutableSetOf<String>()
        for (page in 1..maxPages) {
            val pageData = fetchPage(pageNo = page, pageSize = 100)
            if (pageData.isEmpty()) break
            val unseen = pageData.filter { seenIssues.add(it.issue) }
            if (unseen.isEmpty()) break
            all += unseen
        }
        return all.sortedByDescending { it.issue.toIntOrNull() ?: 0 }
    }

    private fun fetchPage(pageNo: Int, pageSize: Int): List<DrawResult> {
        val endpoint = BASE_ENDPOINT +
            "?name=kl8&issueCount=&issueStart=&issueEnd=&dayStart=&dayEnd=" +
            "&pageNo=$pageNo&pageSize=$pageSize&week=&systemType=PC"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36"
            )
            setRequestProperty("Accept", "application/json,text/plain,*/*")
            setRequestProperty("Referer", "https://www.cwl.gov.cn/")
            setRequestProperty("Connection", "close")
        }

        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (code !in 200..299) error("开奖接口返回 HTTP $code")

            val root = JSONObject(body)
            val array = root.optJSONArray("result") ?: JSONArray()
            return buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val issue = item.optString("issue").trim()
                    val rawNumbers = item.optString("red").ifBlank {
                        item.optString("number")
                    }
                    val numbers = Regex("\\d{1,2}")
                        .findAll(rawNumbers)
                        .mapNotNull { it.value.toIntOrNull() }
                        .filter { it in 1..80 }
                        .toList()
                    if (issue.isNotBlank() && numbers.size == 20) {
                        add(
                            DrawResult(
                                issue = issue,
                                date = item.optString("date"),
                                numbers = numbers,
                                source = "中国福利彩票官网"
                            )
                        )
                    }
                }
            }.distinctBy { it.issue }.sortedByDescending { it.issue.toIntOrNull() ?: 0 }
        } finally {
            connection.disconnect()
        }
    }
}

class LotteryRepository private constructor(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun loadDraws(): List<DrawResult> {
        val raw = preferences.getString(KEY_DRAWS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val numbersArray = item.getJSONArray("numbers")
                    add(
                        DrawResult(
                            issue = item.getString("issue"),
                            date = item.optString("date"),
                            numbers = List(numbersArray.length()) { numbersArray.getInt(it) },
                            source = item.optString("source", "中国福利彩票官网")
                        )
                    )
                }
            }.sortedByDescending { it.issue.toIntOrNull() ?: 0 }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun loadTickets(): List<SavedTicket> {
        val raw = preferences.getString(KEY_TICKETS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        SavedTicket(
                            id = item.getString("id"),
                            issue = item.getString("issue"),
                            playCount = item.getInt("playCount"),
                            mode = TicketMode.valueOf(item.getString("mode")),
                            numbers = item.optJSONArray("numbers").toIntList(),
                            bankers = item.optJSONArray("bankers").toIntList(),
                            drags = item.optJSONArray("drags").toIntList(),
                            createdAt = item.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun saveTicket(ticket: SavedTicket) {
        val updated = (loadTickets().filterNot { it.id == ticket.id } + ticket)
            .sortedByDescending { it.createdAt }
        saveTickets(updated)
    }

    @Synchronized
    fun deleteTicket(id: String) {
        saveTickets(loadTickets().filterNot { it.id == id })
        val notified = loadNotifiedIds().toMutableSet().apply { remove(id) }
        preferences.edit().putStringSet(KEY_NOTIFIED, notified).apply()
    }

    fun syncDraws(): List<DrawResult> {
        val remote = OfficialDrawApi.fetchLatest()
        val merged = (remote + loadDraws())
            .distinctBy { it.issue }
            .sortedByDescending { it.issue.toIntOrNull() ?: 0 }
        saveDraws(merged)
        return merged
    }

    fun syncFullHistory(): List<DrawResult> {
        val history = OfficialDrawApi.fetchAllHistory()
        val merged = (history + loadDraws())
            .distinctBy { it.issue }
            .sortedByDescending { it.issue.toIntOrNull() ?: 0 }
        saveDraws(merged)
        return merged
    }

    fun isNotified(ticketId: String): Boolean = ticketId in loadNotifiedIds()

    fun markNotified(ticketId: String) {
        val ids = loadNotifiedIds().toMutableSet().apply { add(ticketId) }
        preferences.edit().putStringSet(KEY_NOTIFIED, ids).apply()
    }

    private fun loadNotifiedIds(): Set<String> =
        preferences.getStringSet(KEY_NOTIFIED, emptySet())?.toSet().orEmpty()

    private fun saveDraws(draws: List<DrawResult>) {
        val array = JSONArray()
        draws.forEach { draw ->
            array.put(
                JSONObject()
                    .put("issue", draw.issue)
                    .put("date", draw.date)
                    .put("numbers", JSONArray(draw.numbers))
                    .put("source", draw.source)
            )
        }
        preferences.edit().putString(KEY_DRAWS, array.toString()).apply()
    }

    private fun saveTickets(tickets: List<SavedTicket>) {
        val array = JSONArray()
        tickets.forEach { ticket ->
            array.put(
                JSONObject()
                    .put("id", ticket.id)
                    .put("issue", ticket.issue)
                    .put("playCount", ticket.playCount)
                    .put("mode", ticket.mode.name)
                    .put("numbers", JSONArray(ticket.numbers))
                    .put("bankers", JSONArray(ticket.bankers))
                    .put("drags", JSONArray(ticket.drags))
                    .put("createdAt", ticket.createdAt)
            )
        }
        preferences.edit().putString(KEY_TICKETS, array.toString()).apply()
    }

    companion object {
        private const val PREFS = "happy8_data"
        private const val KEY_DRAWS = "draws"
        private const val KEY_TICKETS = "tickets"
        private const val KEY_NOTIFIED = "notified"

        @Volatile
        private var instance: LotteryRepository? = null

        fun get(context: Context): LotteryRepository = instance ?: synchronized(this) {
            instance ?: LotteryRepository(context).also { instance = it }
        }
    }
}

private fun JSONArray?.toIntList(): List<Int> {
    if (this == null) return emptyList()
    return List(length()) { getInt(it) }
}
