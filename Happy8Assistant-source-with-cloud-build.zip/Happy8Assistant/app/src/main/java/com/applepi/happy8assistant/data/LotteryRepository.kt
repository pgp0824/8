package com.applepi.happy8assistant.data

import android.content.Context
import com.applepi.happy8assistant.model.DigitPlay
import com.applepi.happy8assistant.model.DrawResult
import com.applepi.happy8assistant.model.LotteryGame
import com.applepi.happy8assistant.model.SavedTicket
import com.applepi.happy8assistant.model.TicketMode
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object OfficialDrawApi {
    private const val CWL_ENDPOINT =
        "https://www.cwl.gov.cn/cwl_admin/front/cwlkj/search/kjxx/findDrawNotice"
    private const val SPORTTERY_ENDPOINT =
        "https://webapi.sporttery.cn/gateway/lottery/getHistoryPageListV1.qry"

    fun fetchLatest(game: LotteryGame): List<DrawResult> = when (game) {
        LotteryGame.HAPPY8, LotteryGame.DOUBLE_COLOR_BALL, LotteryGame.FC3D ->
            fetchCwlPage(game, pageNo = 1, pageSize = 50)
        LotteryGame.SUPER_LOTTO, LotteryGame.PL3 ->
            fetchSportteryPage(game, pageNo = 1, pageSize = 50)
    }

    fun fetchHistory(game: LotteryGame, maxPages: Int = 80): List<DrawResult> {
        val all = mutableListOf<DrawResult>()
        val seenIssues = mutableSetOf<String>()
        for (page in 1..maxPages) {
            val pageData = when (game) {
                LotteryGame.HAPPY8, LotteryGame.DOUBLE_COLOR_BALL, LotteryGame.FC3D ->
                    fetchCwlPage(game, pageNo = page, pageSize = 100)
                LotteryGame.SUPER_LOTTO, LotteryGame.PL3 ->
                    fetchSportteryPage(game, pageNo = page, pageSize = 100)
            }
            if (pageData.isEmpty()) break
            val unseen = pageData.filter { seenIssues.add(it.issue) }
            if (unseen.isEmpty()) break
            all += unseen
        }
        return all.sortedWith(drawComparator())
    }

    private fun fetchCwlPage(game: LotteryGame, pageNo: Int, pageSize: Int): List<DrawResult> {
        val name = when (game) {
            LotteryGame.HAPPY8 -> "kl8"
            LotteryGame.DOUBLE_COLOR_BALL -> "ssq"
            LotteryGame.FC3D -> "3d"
            else -> error("该彩种不使用福彩接口")
        }
        val endpoint = CWL_ENDPOINT +
            "?name=$name&issueCount=&issueStart=&issueEnd=&dayStart=&dayEnd=" +
            "&pageNo=$pageNo&pageSize=$pageSize&week=&systemType=PC"
        val root = requestJson(endpoint, referer = "https://www.cwl.gov.cn/")
        val array = root.optJSONArray("result") ?: JSONArray()
        val parsed = buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val issue = item.optString("issue").ifBlank { item.optString("code") }.trim()
                val red = parseNumbers(item.optString("red").ifBlank { item.optString("number") })
                val blue = parseNumbers(item.optString("blue"))
                val draw = when (game) {
                    LotteryGame.HAPPY8 -> if (red.size >= 20) DrawResult(
                        game = game,
                        issue = issue,
                        date = item.optString("date"),
                        primaryNumbers = red.take(20),
                        source = game.sourceLabel
                    ) else null
                    LotteryGame.DOUBLE_COLOR_BALL -> if (red.size >= 6 && blue.isNotEmpty()) DrawResult(
                        game = game,
                        issue = issue,
                        date = item.optString("date"),
                        primaryNumbers = red.take(6),
                        secondaryNumbers = blue.take(1),
                        source = game.sourceLabel,
                        jackpot = parseLong(item, "poolmoney", "poolMoney", "poolBalanceAfterdraw")
                    ) else null
                    LotteryGame.FC3D -> if (red.size >= 3) DrawResult(
                        game = game,
                        issue = issue,
                        date = item.optString("date"),
                        primaryNumbers = red.take(3),
                        source = game.sourceLabel
                    ) else null
                    else -> null
                }
                if (issue.isNotBlank() && draw != null) add(draw)
            }
        }.distinctBy { it.issue }.sortedWith(drawComparator())
        if (parsed.isEmpty()) {
            val message = root.optString("message").ifBlank { "接口返回为空或字段格式已变化" }
            error("${game.label}官网已连接，但未取得开奖数据：$message")
        }
        return parsed
    }

    private fun fetchSportteryPage(game: LotteryGame, pageNo: Int, pageSize: Int): List<DrawResult> {
        val gameNo = when (game) {
            LotteryGame.SUPER_LOTTO -> "85"
            LotteryGame.PL3 -> "350133"
            else -> error("该彩种不使用体彩接口")
        }
        val endpoint = "$SPORTTERY_ENDPOINT?gameNo=$gameNo&provinceId=0" +
            "&pageSize=$pageSize&isVerify=1&pageNo=$pageNo"
        val root = requestJson(endpoint, referer = "https://www.sporttery.cn/")
        val array = root.optJSONObject("value")?.optJSONArray("list") ?: JSONArray()
        val parsed = buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val issue = item.optString("lotteryDrawNum").trim()
                val numbers = parseNumbers(item.optString("lotteryDrawResult"))
                val draw = when (game) {
                    LotteryGame.SUPER_LOTTO -> if (numbers.size >= 7) DrawResult(
                        game = game,
                        issue = issue,
                        date = item.optString("lotteryDrawTime"),
                        primaryNumbers = numbers.take(5),
                        secondaryNumbers = numbers.drop(5).take(2),
                        source = game.sourceLabel,
                        jackpot = parseLong(
                            item,
                            "poolBalanceAfterdraw",
                            "poolBalanceAfterDraw",
                            "poolBalance"
                        )
                    ) else null
                    LotteryGame.PL3 -> if (numbers.size >= 3) DrawResult(
                        game = game,
                        issue = issue,
                        date = item.optString("lotteryDrawTime"),
                        primaryNumbers = numbers.take(3),
                        source = game.sourceLabel
                    ) else null
                    else -> null
                }
                if (issue.isNotBlank() && draw != null) add(draw)
            }
        }.distinctBy { it.issue }.sortedWith(drawComparator())
        if (parsed.isEmpty()) error("${game.label}官网已连接，但未取得开奖数据")
        return parsed
    }

    private fun requestJson(endpoint: String, referer: String): JSONObject {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36"
            )
            setRequestProperty("Accept", "application/json,text/plain,*/*")
            setRequestProperty("Referer", referer)
            setRequestProperty("Connection", "close")
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("开奖接口返回 HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseNumbers(raw: String): List<Int> = Regex("\\d{1,2}")
        .findAll(raw)
        .mapNotNull { it.value.toIntOrNull() }
        .toList()

    private fun parseLong(item: JSONObject, vararg keys: String): Long? {
        keys.forEach { key ->
            val raw = item.optString(key).replace(Regex("[^0-9.]"), "")
            raw.toDoubleOrNull()?.toLong()?.let { return it }
        }
        return null
    }

    private fun drawComparator(): Comparator<DrawResult> =
        compareByDescending<DrawResult> { it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L }
}

class LotteryRepository private constructor(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun loadDraws(): List<DrawResult> {
        val raw = preferences.getString(KEY_DRAWS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val game = item.optString("game").toEnumOrNull<LotteryGame>() ?: LotteryGame.HAPPY8
                    val primary = item.optJSONArray("primaryNumbers")?.toIntList()
                        ?: item.optJSONArray("numbers").toIntList()
                    add(
                        DrawResult(
                            game = game,
                            issue = item.getString("issue"),
                            date = item.optString("date"),
                            primaryNumbers = primary,
                            secondaryNumbers = item.optJSONArray("secondaryNumbers").toIntList(),
                            source = item.optString("source", game.sourceLabel),
                            jackpot = item.optLongOrNull("jackpot")
                        )
                    )
                }
            }.sortedWith(compareBy<DrawResult> { it.game.ordinal }.thenByDescending {
                it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L
            })
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun loadTickets(): List<SavedTicket> {
        val raw = preferences.getString(KEY_TICKETS, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val game = item.optString("game").toEnumOrNull<LotteryGame>() ?: LotteryGame.HAPPY8
                    add(
                        SavedTicket(
                            id = item.getString("id"),
                            game = game,
                            issue = item.getString("issue"),
                            playCount = item.optInt("playCount", 0),
                            mode = item.optString("mode").toEnumOrNull<TicketMode>() ?: TicketMode.SINGLE,
                            primaryNumbers = item.optJSONArray("primaryNumbers")?.toIntList()
                                ?: item.optJSONArray("numbers").toIntList(),
                            secondaryNumbers = item.optJSONArray("secondaryNumbers").toIntList(),
                            primaryBankers = item.optJSONArray("primaryBankers")?.toIntList()
                                ?: item.optJSONArray("bankers").toIntList(),
                            primaryDrags = item.optJSONArray("primaryDrags")?.toIntList()
                                ?: item.optJSONArray("drags").toIntList(),
                            secondaryBankers = item.optJSONArray("secondaryBankers").toIntList(),
                            secondaryDrags = item.optJSONArray("secondaryDrags").toIntList(),
                            digitPlay = item.optString("digitPlay").toEnumOrNull<DigitPlay>(),
                            digits = item.optJSONArray("digits").toIntList(),
                            multiplier = game.normalizeMultiplier(item.optInt("multiplier", 1)),
                            createdAt = item.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }.sortedByDescending { it.createdAt }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun saveTicket(ticket: SavedTicket) {
        val updated = (loadTickets().filterNot { it.id == ticket.id } + ticket)
            .sortedByDescending { it.createdAt }
        saveTickets(updated)
    }

    @Synchronized
    fun deleteTicket(id: String) {
        saveTickets(loadTickets().filterNot { it.id == id })
        val notified = loadNotifiedIds().toMutableSet().apply { remove(id) }
        preferences.edit().putStringSet(KEY_NOTIFIED, notified).apply()
    }

    fun syncDraws(games: Set<LotteryGame> = LotteryGame.entries.toSet()): List<DrawResult> {
        val fetched = mutableListOf<DrawResult>()
        val errors = mutableListOf<String>()
        games.forEach { game ->
            runCatching { OfficialDrawApi.fetchLatest(game) }
                .onSuccess { fetched += it }
                .onFailure { errors += "${game.shortLabel}：${it.message ?: "更新失败"}" }
        }
        if (fetched.isEmpty()) error(errors.joinToString("；").ifBlank { "所有开奖接口均无数据" })
        val merged = (fetched + loadDraws())
            .distinctBy { it.game to it.issue }
            .sortedWith(compareBy<DrawResult> { it.game.ordinal }.thenByDescending {
                it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L
            })
        saveDraws(merged)
        return merged
    }

    fun syncFullHistory(game: LotteryGame): List<DrawResult> {
        val history = OfficialDrawApi.fetchHistory(game)
        val merged = (history + loadDraws())
            .distinctBy { it.game to it.issue }
            .sortedWith(compareBy<DrawResult> { it.game.ordinal }.thenByDescending {
                it.issue.filter(Char::isDigit).toLongOrNull() ?: 0L
            })
        saveDraws(merged)
        return merged
    }

    fun isNotified(ticketId: String): Boolean = ticketId in loadNotifiedIds()

    fun markNotified(ticketId: String) {
        val ids = loadNotifiedIds().toMutableSet().apply { add(ticketId) }
        preferences.edit().putStringSet(KEY_NOTIFIED, ids).apply()
    }

    private fun loadNotifiedIds(): Set<String> =
        preferences.getStringSet(KEY_NOTIFIED, emptySet())?.toSet().orEmpty()

    private fun saveDraws(draws: List<DrawResult>) {
        val array = JSONArray()
        draws.forEach { draw ->
            array.put(
                JSONObject()
                    .put("game", draw.game.name)
                    .put("issue", draw.issue)
                    .put("date", draw.date)
                    .put("primaryNumbers", JSONArray(draw.primaryNumbers))
                    .put("secondaryNumbers", JSONArray(draw.secondaryNumbers))
                    .put("source", draw.source)
                    .put("jackpot", draw.jackpot ?: JSONObject.NULL)
            )
        }
        preferences.edit().putString(KEY_DRAWS, array.toString()).apply()
    }

    private fun saveTickets(tickets: List<SavedTicket>) {
        val array = JSONArray()
        tickets.forEach { ticket ->
            array.put(
                JSONObject()
                    .put("id", ticket.id)
                    .put("game", ticket.game.name)
                    .put("issue", ticket.issue)
                    .put("playCount", ticket.playCount)
                    .put("mode", ticket.mode.name)
                    .put("primaryNumbers", JSONArray(ticket.primaryNumbers))
                    .put("secondaryNumbers", JSONArray(ticket.secondaryNumbers))
                    .put("primaryBankers", JSONArray(ticket.primaryBankers))
                    .put("primaryDrags", JSONArray(ticket.primaryDrags))
                    .put("secondaryBankers", JSONArray(ticket.secondaryBankers))
                    .put("secondaryDrags", JSONArray(ticket.secondaryDrags))
                    .put("digitPlay", ticket.digitPlay?.name ?: JSONObject.NULL)
                    .put("digits", JSONArray(ticket.digits))
                    .put("multiplier", ticket.game.normalizeMultiplier(ticket.multiplier))
                    .put("createdAt", ticket.createdAt)
            )
        }
        preferences.edit().putString(KEY_TICKETS, array.toString()).apply()
    }

    companion object {
        private const val PREFS = "happy8_data"
        private const val KEY_DRAWS = "draws"
        private const val KEY_TICKETS = "tickets"
        private const val KEY_NOTIFIED = "notified"

        @Volatile
        private var instance: LotteryRepository? = null

        fun get(context: Context): LotteryRepository = instance ?: synchronized(this) {
            instance ?: LotteryRepository(context).also { instance = it }
        }
    }
}

private fun JSONArray?.toIntList(): List<Int> {
    if (this == null) return emptyList()
    return List(length()) { getInt(it) }
}

private inline fun <reified T : Enum<T>> String.toEnumOrNull(): T? =
    runCatching { enumValueOf<T>(this) }.getOrNull()

private fun JSONObject.optLongOrNull(key: String): Long? =
    if (has(key) && !isNull(key)) optLong(key) else null
