# MVP keeps release code unobfuscated for easier inspection.
