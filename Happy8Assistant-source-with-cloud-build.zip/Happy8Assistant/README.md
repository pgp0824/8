# 乐8助手（Android）

一个用于中国福利彩票快乐8号码记录、历史开奖查询和自动验奖的 Android 原生 App。项目不提供彩票销售、支付、代购或任何“提高中奖率”的承诺。

## 已实现功能

- 选一到选十
- 单式、复式、胆拖选号
- 01–80 手动选号
- 随机机选
- 三角定位选号（娱乐型算法，可切换上三角/下三角）
- 保存购买期号与号码
- 自动获取快乐8开奖结果并本地缓存
- 一键补全历史开奖
- 按实际组合逐注验奖，不只是简单统计命中号码数
- 适配 2025 年第 2025350 期前后两套奖金规则
- App 打开时刷新，后台约每小时检查一次
- 已中奖和未中奖都会发送验奖通知
- 断网时保留已缓存开奖和号码记录

## 三角定位规则

当前版本把 1–80 排成 8 行 × 10 列，以上一期按开奖顺序的首球与末球为两个定位点。每个定位点取自身，以及相邻一行的左、中、右三个号码，形成两个小三角；边界位置自动向反方向取值。生成结果仅作为娱乐型候选号码，不改变随机概率。

## 开奖数据

开奖数据通过中福彩官网公开查询接口获取。接口代码集中在：

`app/src/main/java/com/applepi/happy8assistant/data/LotteryRepository.kt`

如果官网以后调整接口，只需替换 `OfficialDrawApi`，选号、保存和验奖模块无需重写。

## 构建方法

1. 安装最新版 Android Studio，并安装 Android SDK 36。
2. 用 Android Studio 打开项目根目录 `Happy8Assistant`。
3. 选择 JDK 17。
4. 等待 Gradle 同步完成。
5. 连接安卓手机并点击 Run，或使用：

```bash
./gradlew assembleDebug
```

生成的调试 APK 位于：

`app/build/outputs/apk/debug/app-debug.apk`

> 工程未内置二进制 `gradle-wrapper.jar`。首次执行 `gradlew` 时，启动脚本会从 Gradle 官方 GitHub 仓库下载 Gradle 8.13 Wrapper；Android Studio 也可以重新生成 Wrapper。

## 技术栈

- Kotlin 2.1.20
- Jetpack Compose / Material 3
- Android SDK 36，最低 Android 8.0（API 26）
- WorkManager 后台验奖
- SharedPreferences + JSON 本地存储
- 无广告 SDK、无支付 SDK、无账号系统

## 验奖说明

复式和胆拖会根据组合数学展开各类命中注数，再套用对应期号的奖级表。选九、选十的浮动奖只显示中奖注数和“以官方公告为准”，不会虚构具体奖金。

## 素材与版权

界面使用 Material 图标和项目自制矢量图标，没有嵌入福彩官方 Logo、彩票票面或来源不明的网络图片。代码采用 MIT License；开奖数据及相关规则的权利归其发布机构所有。

## 注意事项

- 后台任务会受到手机厂商省电策略影响，可能晚于设定时间执行；打开 App 会立即尝试刷新。
- 官网接口异常或调整时，自动开奖同步可能暂时不可用，但已保存号码和缓存数据不会丢失。
- 最终中奖结果、奖金和兑奖资格均以官方票面及开奖公告为准。

## 云端生成 APK

项目已内置 `.github/workflows/build-apk.yml`。将工程上传到 GitHub 后，可在 Actions 页面手动运行“构建乐8助手 APK”，无需本地安装 Android Studio。详细步骤见 `云端生成APK说明.md`。
