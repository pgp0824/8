# 云端生成 APK（无需安装 Android Studio）

工程已内置 GitHub Actions：`.github/workflows/build-apk.yml`。

## 推荐上传方式

1. 解压源码 ZIP。
2. 在 GitHub 仓库根目录上传解压后的全部文件和文件夹，确保根目录能直接看到 `settings.gradle.kts`、`app`、`gradle` 和 `.github`。
3. `.github` 是隐藏目录，上传时不要遗漏。
4. 不要只把源码 ZIP 当作一个普通文件放进仓库；当前内置工作流直接编译仓库根目录中的 Android 工程。

## 生成 APK

1. 打开仓库顶部 **Actions**。
2. 选择左侧 **构建乐彩助手固定签名 APK**。
3. 点击 **Run workflow**，选择 `main` 或当前默认分支，再次确认运行。
4. 等待黄色圆点变成绿色对勾。
5. 打开成功记录，在页面底部 **Artifacts** 下载 **乐彩助手-固定签名-APK**。
6. 解压后得到 `乐彩助手-v2.4.1-release.apk`，点击安装。

工作流会使用 JDK 17、Android SDK 36 和 Gradle 8.13，先生成并校验官方 Gradle Wrapper，再运行单元测试和 APK 构建。

## 更新旧仓库

把新版源码解压后覆盖上传到原仓库，至少要更新 `app`、`gradle`、`gradlew`、`gradlew.bat`、根目录构建文件和 `.github/workflows/build-apk.yml`。提交完成后重新运行 Actions。

## 覆盖安装

版本号已升级为 2.3.7。若新旧 APK 使用同一签名，可直接更新并保留本地记录；若提示签名冲突，需要先卸载旧版再安装，卸载会清空旧版本地数据。

## 安装提示

这是你自己仓库使用固定签名构建的 Release APK。安卓可能提示“未知来源应用”，确认文件来自自己的绿色对勾构建记录后，再允许浏览器或文件管理器安装。
