# 乐彩助手 v2.4.0：竞彩足球手机同步

新增底部「竞彩」页：

1. 手机直接访问中国体育彩票公开 `getMatchCalculatorV1.qry`；
2. 成功后把官方原始 JSON 发给 Phase18E `/api/sporttery/sync`；
3. Phase18E 写入当天竞彩白名单与官方 SP；
4. Phase18E 立即用最近一份已授权采集的球速数据重新执行竞彩 ↔ 球速匹配；
5. App 可查看 `officialActiveMatches / qstyLinkedMatches / lastQstyCapture`。

安全约束：
- 不绕过竞彩网 403/567/WAF；
- App 只允许配置 `https://` 服务器；
- Phase18E Token 只保存到 Android 私有 SharedPreferences，不打印到日志；
- 球速 Sign/Cookie/Timestamp 仍由服务器上的球速网页正常生成，本 App 不生成或伪造。

## 构建
保持原 `applicationId = com.applepi.happy8assistant`，版本升级到：
- versionCode 15
- versionName 2.4.0

`.github/workflows/build-apk.yml` 继续使用仓库原有固定签名 Secrets，因此在原仓库构建可保持升级签名一致。
